/**
 * Authentic Glicko-2 Rating System Implementation
 * Reference: Professor Mark E. Glickman (Boston University)
 * Scale constant: 173.7178
 */

export interface Glicko2Player {
  rating: number; // R (default 1500)
  rd: number;     // Rating Deviation RD (default 350 for unrated, ~60-110 active)
  vol: number;    // Volatility sigma (default 0.06)
}

export interface Glicko2Result {
  rating: number;
  rd: number;
  vol: number;
  delta: number;
  expectedScore: number;
}

const SCALE = 173.7178;
const TAU = 0.5; // System constant constraining volatility change
const EPSILON = 0.000001;

function toGlicko2Scale(rating: number, rd: number) {
  return {
    mu: (rating - 1500) / SCALE,
    phi: rd / SCALE,
  };
}

function fromGlicko2Scale(mu: number, phi: number) {
  return {
    rating: Math.round(SCALE * mu + 1500),
    rd: Math.max(30, Math.min(350, Number((SCALE * phi).toFixed(2)))),
  };
}

function g(phi: number): number {
  return 1 / Math.sqrt(1 + (3 * phi * phi) / (Math.PI * Math.PI));
}

function E(mu: number, muJ: number, phiJ: number): number {
  return 1 / (1 + Math.exp(-g(phiJ) * (mu - muJ)));
}

/**
 * Calculates updated Glicko-2 rating after a single match.
 * @param player Current player's Glicko-2 parameters
 * @param opponent Opponent's Glicko-2 parameters
 * @param score 1.0 for win, 0.5 for draw, 0.0 for loss
 */
export function calculateGlicko2Update(
  player: Glicko2Player,
  opponent: Glicko2Player,
  score: 1 | 0.5 | 0
): Glicko2Result {
  const { mu, phi } = toGlicko2Scale(player.rating, player.rd);
  const { mu: muJ, phi: phiJ } = toGlicko2Scale(opponent.rating, opponent.rd);
  const sigma = player.vol || 0.06;

  const gPhiJ = g(phiJ);
  const eVal = E(mu, muJ, phiJ);

  // Step 3: Compute estimated variance v
  const v = 1 / (gPhiJ * gPhiJ * eVal * (1 - eVal));

  // Step 4: Compute estimated improvement delta
  const delta = v * gPhiJ * (score - eVal);

  // Step 5: Determine new volatility sigma' via Illinois iterative algorithm
  const a = Math.log(sigma * sigma);
  const f = (x: number) => {
    const ex = Math.exp(x);
    const num1 = ex * (delta * delta - phi * phi - v - ex);
    const den1 = 2 * Math.pow(phi * phi + v + ex, 2);
    return num1 / den1 - (x - a) / (TAU * TAU);
  };

  let A = a;
  let B: number;
  if (delta * delta > phi * phi + v) {
    B = Math.log(delta * delta - phi * phi - v);
  } else {
    let k = 1;
    while (f(a - k * TAU) < 0 && k < 50) {
      k++;
    }
    B = a - k * TAU;
  }

  let fA = f(A);
  let fB = f(B);
  let iterations = 0;

  while (Math.abs(B - A) > EPSILON && iterations < 100) {
    const C = A + ((A - B) * fA) / (fB - fA);
    const fC = f(C);
    if (fC * fB <= 0) {
      A = B;
      fA = fB;
    } else {
      fA = fA / 2;
    }
    B = C;
    fB = fC;
    iterations++;
  }

  const newSigma = Math.exp(A / 2);

  // Step 6: Update rating deviation to new pre-rating period value phi*
  const phiStar = Math.sqrt(phi * phi + newSigma * newSigma);

  // Step 7: Update rating and RD to new values
  const newPhi = 1 / Math.sqrt(1 / (phiStar * phiStar) + 1 / v);
  const newMu = mu + newPhi * newPhi * gPhiJ * (score - eVal);

  const converted = fromGlicko2Scale(newMu, newPhi);

  return {
    rating: converted.rating,
    rd: converted.rd,
    vol: Number(newSigma.toFixed(5)),
    delta: converted.rating - player.rating,
    expectedScore: Number((eVal * 100).toFixed(1)),
  };
}

/**
 * Computes Matchmaking Compatibility Score (0 - 100) between two players
 * factoring in Glicko-2 Rating difference, RD overlap, and wait time expansion.
 */
export function calculateMatchQuality(
  p1: Glicko2Player,
  p2: Glicko2Player,
  waitSeconds = 0
): { compatible: boolean; qualityPercent: number; winProbWhite: number } {
  const diff = Math.abs(p1.rating - p2.rating);
  const combinedRd = p1.rd + p2.rd;
  const maxAllowedDiff = 150 + combinedRd * 0.75 + waitSeconds * 15;

  const { mu: mu1 } = toGlicko2Scale(p1.rating, p1.rd);
  const { mu: mu2, phi: phi2 } = toGlicko2Scale(p2.rating, p2.rd);
  const winProb = E(mu1, mu2, phi2);

  const quality = Math.max(
    10,
    Math.round(100 * Math.exp(-Math.pow(diff / 220, 2)))
  );

  return {
    compatible: diff <= maxAllowedDiff,
    qualityPercent: quality,
    winProbWhite: Number((winProb * 100).toFixed(1)),
  };
}
