"use client";

/**
 * Offline data layer (localStorage-backed).
 *
 * Modelled on how professional chess apps split features:
 *  - WORKS OFFLINE: play vs computer, pre-downloaded puzzle pack,
 *    local engine analysis / game review, saved (cached) games & profile.
 *  - ONLINE ONLY:   live matchmaking vs people, in-game chat,
 *    challenges/friends, leaderboard + rating sync.
 *
 * Everything the offline features need is snapshotted here while online,
 * then re-hydrated when the network (or the preview server) is unreachable.
 * Finished offline games are queued and synced to the archive on reconnect.
 */

const KEYS = {
  snapshot: "obsidian_offline_snapshot_v2",
  puzzlePack: "obsidian_puzzle_pack_v2",
  offlineGames: "obsidian_offline_games_v2",
  settings: "obsidian_settings_v2",
  pendingPuzzleResults: "obsidian_pending_puzzle_results_v2",
} as const;

function safeParse<T>(raw: string | null, fallback: T): T {
  if (!raw) return fallback;
  try {
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function lsGet(key: string): string | null {
  if (typeof window === "undefined") return null;
  try {
    return window.localStorage.getItem(key);
  } catch {
    return null;
  }
}

function lsSet(key: string, value: string): boolean {
  if (typeof window === "undefined") return false;
  try {
    window.localStorage.setItem(key, value);
    return true;
  } catch {
    return false; // storage full / private mode — offline simply degrades
  }
}

/* ------------------------------------------------------------------ */
/* Overview snapshot (users / games / challenges / friendships)        */
/* ------------------------------------------------------------------ */

export interface OfflineSnapshot {
  savedAt: number;
  userId: string;
  users: unknown[];
  games: unknown[];
  challenges: unknown[];
  friendships: unknown[];
}

export function saveSnapshot(snap: Omit<OfflineSnapshot, "savedAt">) {
  lsSet(KEYS.snapshot, JSON.stringify({ ...snap, savedAt: Date.now() }));
}

export function loadSnapshot(): OfflineSnapshot | null {
  const snap = safeParse<OfflineSnapshot | null>(lsGet(KEYS.snapshot), null);
  if (!snap || !Array.isArray(snap.users) || snap.users.length === 0) return null;
  return snap;
}

/* ------------------------------------------------------------------ */
/* Downloaded puzzle pack                                              */
/* ------------------------------------------------------------------ */

export interface PuzzlePack {
  savedAt: number;
  puzzles: unknown[];
}

export function savePuzzlePack(puzzles: unknown[]) {
  const pack: PuzzlePack = { savedAt: Date.now(), puzzles };
  lsSet(KEYS.puzzlePack, JSON.stringify(pack));
}

export function loadPuzzlePack(): PuzzlePack | null {
  const pack = safeParse<PuzzlePack | null>(lsGet(KEYS.puzzlePack), null);
  if (!pack || !Array.isArray(pack.puzzles) || pack.puzzles.length === 0) return null;
  return pack;
}

/* ------------------------------------------------------------------ */
/* Offline (vs computer) games — saved locally, synced when online     */
/* ------------------------------------------------------------------ */

export interface OfflineSavedGame {
  id: string;
  pgn: string;
  fen: string;
  result: string;
  termination: string;
  opponentName: string;
  opponentRating: number;
  playerColor: "w" | "b";
  timeControlLabel: string;
  createdAt: number;
  synced: boolean;
}

export function loadOfflineGames(): OfflineSavedGame[] {
  return safeParse<OfflineSavedGame[]>(lsGet(KEYS.offlineGames), []);
}

export function saveOfflineGame(game: OfflineSavedGame) {
  const all = loadOfflineGames();
  const next = [game, ...all.filter((g) => g.id !== game.id)].slice(0, 40);
  lsSet(KEYS.offlineGames, JSON.stringify(next));
}

export function markOfflineGamesSynced(ids: string[]) {
  const all = loadOfflineGames().map((g) =>
    ids.includes(g.id) ? { ...g, synced: true } : g
  );
  lsSet(KEYS.offlineGames, JSON.stringify(all));
}

export function unsyncedOfflineGames(): OfflineSavedGame[] {
  return loadOfflineGames().filter((g) => !g.synced && g.pgn.trim().length > 0);
}

/* ------------------------------------------------------------------ */
/* Puzzle results solved offline (rating sync is online-only)          */
/* ------------------------------------------------------------------ */

export interface PendingPuzzleResult {
  puzzleId: string;
  solved: boolean;
  timeTakenMs: number;
  at: number;
}

export function queuePuzzleResult(r: PendingPuzzleResult) {
  const all = safeParse<PendingPuzzleResult[]>(
    lsGet(KEYS.pendingPuzzleResults),
    []
  );
  lsSet(KEYS.pendingPuzzleResults, JSON.stringify([...all, r].slice(-50)));
}

export function loadPendingPuzzleResults(): PendingPuzzleResult[] {
  return safeParse<PendingPuzzleResult[]>(lsGet(KEYS.pendingPuzzleResults), []);
}

export function clearPendingPuzzleResults() {
  lsSet(KEYS.pendingPuzzleResults, "[]");
}

/* ------------------------------------------------------------------ */
/* Settings (theme / sound / simulated offline)                        */
/* ------------------------------------------------------------------ */

export interface AppSettings {
  boardTheme?: string;
  soundOn?: boolean;
  forceOffline?: boolean;
}

export function loadSettings(): AppSettings {
  return safeParse<AppSettings>(lsGet(KEYS.settings), {});
}

export function saveSettings(patch: AppSettings) {
  lsSet(KEYS.settings, JSON.stringify({ ...loadSettings(), ...patch }));
}

/* ------------------------------------------------------------------ */
/* Human-readable offline capability matrix (shown on Home)            */
/* ------------------------------------------------------------------ */

export const OFFLINE_CAPABILITIES = {
  offline: [
    "Play vs Computer (8 coach levels, hints & takebacks)",
    "Downloaded puzzle pack + Puzzle Rush",
    "Engine analysis board & Game Review",
    "Opening explorer & PGN / FEN import",
    "Saved games, profile & cached leaderboards",
  ],
  onlineOnly: [
    "Live matchmaking vs real players",
    "Rated Glicko-2 points & leaderboard sync",
    "In-game chat & emoji reactions",
    "1v1 challenges & friend requests",
  ],
} as const;

export function timeAgo(ts: number): string {
  const s = Math.max(1, Math.floor((Date.now() - ts) / 1000));
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
