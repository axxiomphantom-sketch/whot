"use client";

import React, { useState } from "react";
import { calculateGlicko2Update } from "@/lib/glicko2";
import { WsEventLogEntry } from "@/lib/redisStore";
import {
  Database,
  Radio,
  Calculator,
  Copy,
  Check,
  RefreshCw,
  Server,
  Cpu,
} from "lucide-react";

interface ArchitectureWorkspaceProps {
  wsLogs: WsEventLogEntry[];
  activeLiveGamesCount: number;
  onRefreshLogs: () => void;
}

const PRISMA_POSTGRES_SCHEMA = `// Production PostgreSQL + Prisma ORM Schema
datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

model User {
  id           String   @id @default(uuid()) @db.Uuid
  username     String   @unique @db.VarChar(32)
  email        String   @unique @db.VarChar(255)
  passwordHash String   @db.Text
  title        String?  @db.VarChar(8) // GM, IM, FM, WGM, NM, CM
  ratings      Json     @default("{\\"bullet\\":{\\"rating\\":1500,\\"rd\\":110,\\"vol\\":0.06},\\"blitz\\":{\\"rating\\":1500,\\"rd\\":95,\\"vol\\":0.06},\\"rapid\\":{\\"rating\\":1500,\\"rd\\":85,\\"vol\\":0.06},\\"puzzle\\":{\\"rating\\":1650,\\"rd\\":75}}") @db.JsonB
  createdAt    DateTime @default(now()) @db.Timestamptz(6)

  whiteGames   Game[]   @relation("WhiteGames")
  blackGames   Game[]   @relation("BlackGames")
}

model Game {
  id            String   @id @default(uuid()) @db.Uuid
  whitePlayerId String   @db.Uuid
  blackPlayerId String   @db.Uuid
  pgn           String   @db.Text
  fen           String   @db.VarChar(128)
  result        String   @db.VarChar(12) // "1-0" | "0-1" | "1/2-1/2" | "*"
  timeControl   String   @db.VarChar(24) // "1+0" | "3+2" | "10+0" | "15+10" | "daily"
  rated         Boolean  @default(true)
  createdAt     DateTime @default(now()) @db.Timestamptz(6)

  whitePlayer   User     @relation("WhiteGames", fields: [whitePlayerId], references: [id])
  blackPlayer   User     @relation("BlackGames", fields: [blackPlayerId], references: [id])

  @@index([whitePlayerId, createdAt(sort: Desc)])
  @@index([blackPlayerId, createdAt(sort: Desc)])
}

model Puzzle {
  id     String   @id @default(uuid()) @db.Uuid
  fen    String   @db.VarChar(128)
  moves  String[] // UCI or SAN forced tactical sequence
  rating Int      @default(1600)
  themes String[] // ["Fork", "Pin", "Skewer", "Mating Net", "Sacrifice"]

  @@index([rating])
}`;

const WEBSOCKET_CONTRACTS_TS = `// Strict TypeScript WebSocket Event Contracts (Socket.io Real-Time Layer)
export interface ClientToServerEvents {
  "game:join": (payload: { gameId: string; userId: string }) => void;
  "game:move": (payload: {
    gameId: string;
    from: string;
    to: string;
    promotion?: "q" | "r" | "b" | "n";
  }) => void;
  "game:premove": (payload: {
    gameId: string;
    color: "w" | "b";
    premove: { from: string; to: string; promotion?: string } | null;
  }) => void;
  "game:resign": (payload: { gameId: string; color: "w" | "b" }) => void;
  "game:draw_offer": (payload: {
    gameId: string;
    color: "w" | "b";
    action: "offer" | "accept" | "decline";
  }) => void;
  "chat:message": (payload: {
    gameId: string;
    senderId: string;
    senderName: string;
    text: string;
  }) => void;
  "matchmaking:join": (payload: {
    userId: string;
    timeControl: string;
    rated: boolean;
    colorPref?: "random" | "white" | "black";
  }) => void;
}

export interface ServerToClientEvents {
  "game:state_sync": (state: LiveGameState) => void;
  "game:error": (err: { message: string }) => void;
  "matchmaking:matched": (state: LiveGameState) => void;
  "chat:message": (msg: ChatMessageDTO) => void;
}`;

export const ArchitectureWorkspace: React.FC<ArchitectureWorkspaceProps> = ({
  wsLogs,
  activeLiveGamesCount,
  onRefreshLogs,
}) => {
  const [copiedBlock, setCopiedBlock] = useState<string | null>(null);

  // Interactive Glicko-2 Sandbox State
  const [pRating, setPRating] = useState(2418);
  const [pRd, setPRd] = useState(48.5);
  const [pVol, setPVol] = useState(0.056);
  const [oppRating, setOppRating] = useState(2595);
  const [oppRd, setOppRd] = useState(45.0);
  const [matchScore, setMatchScore] = useState<1 | 0.5 | 0>(1);

  const glickoSim = calculateGlicko2Update(
    { rating: pRating, rd: pRd, vol: pVol },
    { rating: oppRating, rd: oppRd, vol: 0.06 },
    matchScore
  );

  const copyCode = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedBlock(key);
    setTimeout(() => setCopiedBlock(null), 1800);
  };

  return (
    <div className="space-y-5">
      {/* Top System Telemetry Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-[#2B2825] border border-[#3A3733] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Radio className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-mono uppercase text-slate-400">
              WebSocket Layer
            </div>
            <div className="font-mono text-sm font-bold text-emerald-400">
              Socket.io v4.8 Active
            </div>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#2B2825] border border-[#3A3733] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-sky-500/15 border border-sky-500/30 flex items-center justify-center text-sky-400">
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-mono uppercase text-slate-400">
              ORM & Persistence
            </div>
            <div className="font-mono text-sm font-bold text-slate-100">
              Prisma + Redis State
            </div>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#2B2825] border border-[#3A3733] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center text-amber-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-mono uppercase text-slate-400">
              Analysis Engine
            </div>
            <div className="font-mono text-sm font-bold text-slate-100">
              Multi-PV AlphaBeta + CAPS
            </div>
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-[#2B2825] border border-[#3A3733] flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/15 border border-purple-500/30 flex items-center justify-center text-purple-400">
            <Server className="w-5 h-5" />
          </div>
          <div>
            <div className="text-[10px] font-mono uppercase text-slate-400">
              Live Game Rooms
            </div>
            <div className="font-mono text-sm font-bold text-slate-100">
              {activeLiveGamesCount} Active in Memory
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Live WebSocket Event Telemetry Stream */}
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
              <Radio className="w-4 h-4 text-emerald-400" />
              Live WebSocket Event Stream (`socket.io`)
            </h3>
            <button
              onClick={onRefreshLogs}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#201D1B] hover:bg-[#35312C] border border-[#3A3733] text-xs font-mono text-slate-300"
            >
              <RefreshCw className="w-3 h-3" /> Refresh
            </button>
          </div>

          <div className="space-y-1.5 max-h-64 overflow-y-auto font-mono text-xs bg-[#201D1B] p-3 rounded-xl border border-[#3A3733]">
            {wsLogs.length === 0 ? (
              <div className="text-slate-500 py-6 text-center">
                Play a move or join a match to watch real-time WebSocket frames flow here.
              </div>
            ) : (
              wsLogs.map((log) => (
                <div
                  key={log.id}
                  className="flex items-start gap-2 py-1 border-b border-[#35312C] last:border-0"
                >
                  <span className="text-[10px] text-slate-500 shrink-0">
                    {log.timestamp}
                  </span>
                  <span
                    className={`px-1.5 py-0.2 rounded text-[10px] font-bold shrink-0 ${
                      log.direction === "IN"
                        ? "bg-sky-500/20 text-sky-300"
                        : "bg-emerald-500/20 text-emerald-300"
                    }`}
                  >
                    {log.direction}
                  </span>
                  <span className="text-amber-300 font-bold shrink-0">
                    {log.event}
                  </span>
                  <span className="text-slate-400 truncate">
                    {log.payloadSummary}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Interactive Glicko-2 Rating Calculator Sandbox */}
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
          <h3 className="font-display font-bold text-sm text-slate-100 flex items-center gap-2">
            <Calculator className="w-4 h-4 text-amber-400" />
            Interactive Glicko-2 Rating Engine Sandbox
          </h3>

          <div className="grid grid-cols-3 gap-2.5">
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                Player Rating (R)
              </label>
              <input
                type="number"
                value={pRating}
                onChange={(e) => setPRating(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                Player RD (φ)
              </label>
              <input
                type="number"
                value={pRd}
                onChange={(e) => setPRd(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                Volatility (σ)
              </label>
              <input
                type="number"
                step="0.005"
                value={pVol}
                onChange={(e) => setPVol(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-2.5">
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                Opponent Rating
              </label>
              <input
                type="number"
                value={oppRating}
                onChange={(e) => setOppRating(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                Opponent RD
              </label>
              <input
                type="number"
                value={oppRd}
                onChange={(e) => setOppRd(Number(e.target.value))}
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
              />
            </div>
            <div>
              <label className="block text-[11px] font-mono text-slate-400 mb-1">
                Match Outcome
              </label>
              <select
                value={matchScore}
                onChange={(e) =>
                  setMatchScore(Number(e.target.value) as 1 | 0.5 | 0)
                }
                className="w-full px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-emerald-300"
              >
                <option value={1}>Win (1.0)</option>
                <option value={0.5}>Draw (0.5)</option>
                <option value={0}>Loss (0.0)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 p-3 rounded-xl bg-[#201D1B] border border-[#3A3733] text-center">
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-400">
                New Rating
              </div>
              <div className="font-mono text-lg font-extrabold text-emerald-400">
                {glickoSim.rating}
              </div>
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-400">
                Delta (Δ)
              </div>
              <div
                className={`font-mono text-lg font-extrabold ${
                  glickoSim.delta >= 0 ? "text-emerald-400" : "text-rose-400"
                }`}
              >
                {glickoSim.delta >= 0
                  ? `+${glickoSim.delta}`
                  : glickoSim.delta}
              </div>
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-400">
                New RD (φ&apos;)
              </div>
              <div className="font-mono text-lg font-bold text-slate-200">
                ±{glickoSim.rd}
              </div>
            </div>
            <div>
              <div className="text-[10px] font-mono uppercase text-slate-400">
                Win Expectancy
              </div>
              <div className="font-mono text-lg font-bold text-amber-400">
                {glickoSim.expectedScore}%
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Schema & WebSocket Contracts Code Blocks */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-display font-bold text-sm text-slate-100">
              PostgreSQL / Prisma Schema (`schema.prisma`)
            </span>
            <button
              onClick={() => copyCode("prisma", PRISMA_POSTGRES_SCHEMA)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs font-mono text-slate-300"
            >
              {copiedBlock === "prisma" ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" /> Copy Schema
                </>
              )}
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733] font-mono text-[11px] text-slate-300 overflow-x-auto max-h-80">
            {PRISMA_POSTGRES_SCHEMA}
          </pre>
        </div>

        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-display font-bold text-sm text-slate-100">
              WebSocket Event Contracts (`game:*`)
            </span>
            <button
              onClick={() => copyCode("ws", WEBSOCKET_CONTRACTS_TS)}
              className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs font-mono text-slate-300"
            >
              {copiedBlock === "ws" ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" /> Copied
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" /> Copy Contracts
                </>
              )}
            </button>
          </div>
          <pre className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733] font-mono text-[11px] text-emerald-300/90 overflow-x-auto max-h-80">
            {WEBSOCKET_CONTRACTS_TS}
          </pre>
        </div>
      </div>
    </div>
  );
};
