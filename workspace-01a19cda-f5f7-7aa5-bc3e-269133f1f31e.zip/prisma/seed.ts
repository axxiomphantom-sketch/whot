import { PrismaClient } from "@prisma/client";
import { Chess } from "chess.js";

const prisma = new PrismaClient();

async function main() {
  console.log("Seeding Obsidian Grandmaster Chess database...");

  await prisma.chatMessage.deleteMany();
  await prisma.puzzleAttempt.deleteMany();
  await prisma.challenge.deleteMany();
  await prisma.friendship.deleteMany();
  await prisma.ratingHistory.deleteMany();
  await prisma.game.deleteMany();
  await prisma.puzzle.deleteMany();
  await prisma.user.deleteMany();

  // 1. Create Users (Human + Titled Grandmaster/IM AI & Community Profiles)
  const usersData = [
    {
      id: "user-ademola",
      username: "Ademola_GM",
      email: "ademola@obsidiangm.io",
      passwordHash: "hashed_demo_pw_1",
      title: "GM",
      avatar: "♔",
      country: "NG",
      bio: "Lagos Blitz & Rapid Champion • FIDE Master tactician grinding toward 2600 Blitz.",
      isAi: false,
      isOnline: true,
      bulletRating: 2345,
      bulletRd: 54.2,
      bulletVol: 0.058,
      blitzRating: 2418,
      blitzRd: 48.5,
      blitzVol: 0.056,
      rapidRating: 2465,
      rapidRd: 52.0,
      rapidVol: 0.054,
      puzzleRating: 2590,
      puzzleRd: 61.0,
      puzzleRushBest: 44,
      gamesPlayed: 842,
      wins: 512,
      losses: 234,
      draws: 96,
      streak: 5,
    },
    {
      id: "user-magnus",
      username: "DrNykterstein_GM",
      email: "magnus@obsidiangm.io",
      passwordHash: "hashed_demo_pw_2",
      title: "GM",
      avatar: "👑",
      country: "NO",
      bio: "Endgame squeeze specialist. Water from stone in every rook ending.",
      isAi: true,
      isOnline: true,
      bulletRating: 2865,
      bulletRd: 42.1,
      bulletVol: 0.051,
      blitzRating: 2882,
      blitzRd: 39.4,
      blitzVol: 0.049,
      rapidRating: 2840,
      rapidRd: 44.0,
      rapidVol: 0.05,
      puzzleRating: 2940,
      puzzleRd: 55.0,
      puzzleRushBest: 58,
      gamesPlayed: 1920,
      wins: 1410,
      losses: 260,
      draws: 250,
      streak: 14,
    },
    {
      id: "user-hikaru",
      username: "GMHikaru_Speed",
      email: "hikaru@obsidiangm.io",
      passwordHash: "hashed_demo_pw_3",
      title: "GM",
      avatar: "⚡",
      country: "US",
      bio: "Premove wizard & 3+0 Blitz machine. Juicers everywhere.",
      isAi: true,
      isOnline: true,
      bulletRating: 2890,
      bulletRd: 38.0,
      bulletVol: 0.052,
      blitzRating: 2874,
      blitzRd: 40.2,
      blitzVol: 0.05,
      rapidRating: 2785,
      rapidRd: 48.0,
      rapidVol: 0.052,
      puzzleRating: 2985,
      puzzleRd: 50.0,
      puzzleRushBest: 63,
      gamesPlayed: 3410,
      wins: 2590,
      losses: 480,
      draws: 340,
      streak: 9,
    },
    {
      id: "user-levy",
      username: "GothamTactics_IM",
      email: "levy@obsidiangm.io",
      passwordHash: "hashed_demo_pw_4",
      title: "IM",
      avatar: "♜",
      country: "US",
      bio: "THE ROOOOOK! Sacrifice the exchange first, calculate second.",
      isAi: true,
      isOnline: true,
      bulletRating: 2410,
      bulletRd: 55.0,
      bulletVol: 0.061,
      blitzRating: 2385,
      blitzRd: 51.0,
      blitzVol: 0.059,
      rapidRating: 2420,
      rapidRd: 58.0,
      rapidVol: 0.057,
      puzzleRating: 2610,
      puzzleRd: 62.0,
      puzzleRushBest: 46,
      gamesPlayed: 1240,
      wins: 690,
      losses: 410,
      draws: 140,
      streak: 3,
    },
    {
      id: "user-alexandra",
      username: "Alexandra_WGM",
      email: "alexandra@obsidiangm.io",
      passwordHash: "hashed_demo_pw_5",
      title: "WGM",
      avatar: "♕",
      country: "CA",
      bio: "Aggressive King's Indian & Sicilian Dragon player.",
      isAi: true,
      isOnline: true,
      bulletRating: 2120,
      bulletRd: 60.0,
      bulletVol: 0.06,
      blitzRating: 2165,
      blitzRd: 56.0,
      blitzVol: 0.058,
      rapidRating: 2210,
      rapidRd: 59.0,
      rapidVol: 0.057,
      puzzleRating: 2340,
      puzzleRd: 65.0,
      puzzleRushBest: 39,
      gamesPlayed: 675,
      wins: 370,
      losses: 235,
      draws: 70,
      streak: 2,
    },
    {
      id: "user-clara",
      username: "ClaraV_FM",
      email: "clara@obsidiangm.io",
      passwordHash: "hashed_demo_pw_6",
      title: "FM",
      avatar: "♗",
      country: "DE",
      bio: "Classical Caro-Kann and French Defense specialist.",
      isAi: true,
      isOnline: true,
      bulletRating: 1940,
      bulletRd: 64.0,
      bulletVol: 0.06,
      blitzRating: 1985,
      blitzRd: 58.0,
      blitzVol: 0.059,
      rapidRating: 2045,
      rapidRd: 54.0,
      rapidVol: 0.055,
      puzzleRating: 2190,
      puzzleRd: 68.0,
      puzzleRushBest: 35,
      gamesPlayed: 530,
      wins: 280,
      losses: 190,
      draws: 60,
      streak: 1,
    },
    {
      id: "user-viktor",
      username: "Korchnoi_Spirit",
      email: "viktor@obsidiangm.io",
      passwordHash: "hashed_demo_pw_7",
      title: "GM",
      avatar: "♘",
      country: "CH",
      bio: "Fearless counter-attacker. Accept every gambit pawn and defend stubborny.",
      isAi: true,
      isOnline: true,
      bulletRating: 2510,
      bulletRd: 49.0,
      bulletVol: 0.055,
      blitzRating: 2595,
      blitzRd: 45.0,
      blitzVol: 0.053,
      rapidRating: 2660,
      rapidRd: 47.0,
      rapidVol: 0.051,
      puzzleRating: 2740,
      puzzleRd: 58.0,
      puzzleRushBest: 49,
      gamesPlayed: 980,
      wins: 610,
      losses: 240,
      draws: 130,
      streak: 4,
    },
    {
      id: "user-club",
      username: "LagosTactician_CM",
      email: "tunde@obsidiangm.io",
      passwordHash: "hashed_demo_pw_8",
      title: "CM",
      avatar: "♙",
      country: "NG",
      bio: "Club rapid regular & Italian Game enthusiast.",
      isAi: true,
      isOnline: true,
      bulletRating: 1620,
      bulletRd: 72.0,
      bulletVol: 0.062,
      blitzRating: 1685,
      blitzRd: 66.0,
      blitzVol: 0.061,
      rapidRating: 1740,
      rapidRd: 64.0,
      rapidVol: 0.059,
      puzzleRating: 1890,
      puzzleRd: 70.0,
      puzzleRushBest: 29,
      gamesPlayed: 410,
      wins: 215,
      losses: 165,
      draws: 30,
      streak: 2,
    },
  ];

  for (const u of usersData) {
    await prisma.user.create({ data: u });
  }

  // 2. Seed Rating History for Ademola_GM and top players
  const now = Date.now();
  const dayMs = 86400 * 1000;
  const blitzProgression = [2280, 2295, 2310, 2302, 2335, 2358, 2349, 2376, 2392, 2405, 2418];
  const rapidProgression = [2340, 2355, 2370, 2390, 2405, 2412, 2430, 2442, 2450, 2458, 2465];
  const bulletProgression = [2210, 2235, 2228, 2260, 2275, 2290, 2310, 2305, 2322, 2334, 2345];
  const puzzleProgression = [2410, 2440, 2465, 2490, 2485, 2515, 2535, 2550, 2568, 2580, 2590];

  for (let i = 0; i < blitzProgression.length; i++) {
    const recordedAt = new Date(now - (blitzProgression.length - 1 - i) * 3 * dayMs);
    await prisma.ratingHistory.createMany({
      data: [
        { userId: "user-ademola", category: "blitz", rating: blitzProgression[i], rd: 50, recordedAt },
        { userId: "user-ademola", category: "rapid", rating: rapidProgression[i], rd: 52, recordedAt },
        { userId: "user-ademola", category: "bullet", rating: bulletProgression[i], rd: 55, recordedAt },
        { userId: "user-ademola", category: "puzzle", rating: puzzleProgression[i], rd: 61, recordedAt },
      ],
    });
  }

  // 3. Seed Realistic Complete Games with Full PGNs and Evaluation Histories
  const gamesData = [
    {
      id: "game-najdorf-brilliancy",
      whitePlayerId: "user-ademola",
      blackPlayerId: "user-levy",
      pgn: "1. e4 c5 2. Nf3 d6 3. d4 cxd4 4. Nxd4 Nf6 5. Nc3 a6 6. Bg5 e6 7. f4 Be7 8. Qf3 Qc7 9. O-O-O Nbd7 10. g4 b5 11. Bxf6 Nxf6 12. g5 Nd7 13. f5 Bxg5+ 14. Kb1 Ne5 15. Qh5 Qd8 16. Nxe6 Bxe6 17. fxe6 g6 18. exf7+ Kxf7 19. Qh3 Kg7 20. Nd5 Rf8 21. Qe6 Rf2 22. Bxb5 axb5 23. Rhf1 Rxf1 24. Rxf1",
      result: "1-0",
      termination: "resignation",
      timeControl: "3+2",
      category: "blitz",
      rated: true,
      whiteAccuracy: 94.6,
      blackAccuracy: 86.2,
      openingEco: "B96",
      openingName: "Sicilian Defense: Najdorf, English Attack",
      evalHistoryJson: JSON.stringify([
        25, 18, 30, 22, 35, 28, 42, 30, 48, 35, 55, 40, 68, 45, 75, 60, 82, 55, 95, 70, 110, 85, 125, 90, 165, 110, 195, 140, 240, 180, 340, 290, 385, 320, 420, 390, 460, 410, 495
      ]),
      whiteRatingBefore: 2406,
      blackRatingBefore: 2397,
      whiteRatingDelta: 12,
      blackRatingDelta: -12,
    },
    {
      id: "game-opera-tactical",
      whitePlayerId: "user-ademola",
      blackPlayerId: "user-alexandra",
      pgn: "1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7 8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7 14. Rd1 Qe6 15. Bxd7+ Nxd7 16. Qb8+ Nxb8 17. Rd8#",
      result: "1-0",
      termination: "checkmate",
      timeControl: "10+0",
      category: "rapid",
      rated: true,
      whiteAccuracy: 98.4,
      blackAccuracy: 79.5,
      openingEco: "C41",
      openingName: "Philidor Defense: Opera Brilliancy Variation",
      evalHistoryJson: JSON.stringify([
        30, 35, 45, 55, 70, 65, 90, 85, 120, 110, 145, 190, 220, 260, 310, 380, 450, 520, 680, 790, 999
      ]),
      whiteRatingBefore: 2457,
      blackRatingBefore: 2218,
      whiteRatingDelta: 8,
      blackRatingDelta: -8,
    },
    {
      id: "game-magnus-endgame",
      whitePlayerId: "user-magnus",
      blackPlayerId: "user-ademola",
      pgn: "1. d4 Nf6 2. c4 e6 3. Nf3 d5 4. Nc3 Be7 5. Bf4 O-O 6. e3 Nbd7 7. c5 c6 8. Bd3 b6 9. b4 a5 10. a3 Ba6 11. Bxa6 Rxa6 12. b5 cxb5 13. c6 Qc8 14. c7 b4 15. Nb5 a4 16. axb4 Bxb4+ 17. Ke2 Ne4",
      result: "1/2-1/2",
      termination: "draw_agreement",
      timeControl: "3+0",
      category: "blitz",
      rated: true,
      whiteAccuracy: 95.1,
      blackAccuracy: 94.8,
      openingEco: "D37",
      openingName: "Queen's Gambit Declined: Harrwitz Attack",
      evalHistoryJson: JSON.stringify([
        28, 22, 32, 25, 30, 28, 35, 30, 25, 18, 15, 12, 20, 10, 8, 5, 12, 0, -5, 4, 0
      ]),
      whiteRatingBefore: 2885,
      blackRatingBefore: 2401,
      whiteRatingDelta: -3,
      blackRatingDelta: 5,
    },
    {
      id: "game-hikaru-bullet",
      whitePlayerId: "user-ademola",
      blackPlayerId: "user-hikaru",
      pgn: "1. e4 e5 2. Nf3 Nc6 3. Bb5 a6 4. Ba4 Nf6 5. O-O Be7 6. Re1 b5 7. Bb3 O-O 8. c3 d5 9. exd5 Nxd5 10. Nxe5 Nxe5 11. Rxe5 c6 12. d4 Bd6 13. Re1 Qh4 14. g3 Qh3 15. Be3 Bg4 16. Qd3 Rae8 17. Nd2 Re6",
      result: "0-1",
      termination: "timeout",
      timeControl: "1+0",
      category: "bullet",
      rated: true,
      whiteAccuracy: 89.2,
      blackAccuracy: 93.7,
      openingEco: "C89",
      openingName: "Ruy Lopez: Marshall Attack",
      evalHistoryJson: JSON.stringify([
        25, 20, 30, 24, 28, 22, 25, 18, 12, 5, 0, -15, -28, -45, -60, -85, -120, -165, -210
      ]),
      whiteRatingBefore: 2349,
      blackRatingBefore: 2886,
      whiteRatingDelta: -4,
      blackRatingDelta: 4,
    },
    {
      id: "game-caro-kann-win",
      whitePlayerId: "user-clara",
      blackPlayerId: "user-ademola",
      pgn: "1. e4 c6 2. d4 d5 3. Nc3 dxe4 4. Nxe4 Bf5 5. Ng3 Bg6 6. h4 h6 7. Nf3 Nd7 8. h5 Bh7 9. Bd3 Bxd3 10. Qxd3 e6 11. Bf4 Qa5+ 12. Bd2 Bb4 13. c3 Be7 14. c4 Qc7 15. O-O-O Ngf6 16. Kb1 O-O",
      result: "0-1",
      termination: "resignation",
      timeControl: "15+10",
      category: "rapid",
      rated: true,
      whiteAccuracy: 85.4,
      blackAccuracy: 92.8,
      openingEco: "B18",
      openingName: "Caro-Kann Defense: Classical Variation",
      evalHistoryJson: JSON.stringify([
        22, 18, 25, 15, 10, 5, 0, -12, -24, -35, -48, -65, -80, -110, -145, -190
      ]),
      whiteRatingBefore: 2052,
      blackRatingBefore: 2458,
      whiteRatingDelta: -7,
      blackRatingDelta: 7,
    },
  ];

  for (const g of gamesData) {
    const chess = new Chess();
    chess.loadPgn(g.pgn);
    await prisma.game.create({
      data: {
        ...g,
        fen: chess.fen(),
      },
    });
  }

  // Add sample chat messages to the primary game
  await prisma.chatMessage.createMany({
    data: [
      {
        gameId: "game-najdorf-brilliancy",
        senderId: "user-levy",
        senderName: "GothamTactics_IM",
        text: "Good luck! Let's see how you handle the Najdorf English Attack 🔥",
        reactionsJson: JSON.stringify({ "🔥": 2, "🤝": 1 }),
      },
      {
        gameId: "game-najdorf-brilliancy",
        senderId: "user-ademola",
        senderName: "Ademola_GM",
        text: "Thanks IM! 16. Nxe6!! was too tempting to pass up.",
        reactionsJson: JSON.stringify({ "🤯": 3, "👏": 2 }),
      },
      {
        gameId: "game-najdorf-brilliancy",
        senderId: "user-levy",
        senderName: "GothamTactics_IM",
        text: "Wait... you sacrificed the Knight AND the Bishop?! Well played 👏",
        reactionsJson: JSON.stringify({ "👏": 2 }),
      },
    ],
  });

  // 4. Seed Verified Tactical Puzzles across all Tactical Themes
  const puzzlesData = [
    {
      id: "puzzle-opera-mate",
      title: "Morphy's Opera House Finale",
      fen: "4kb1r/p2n1ppp/4q3/4p1B1/4P3/1Q6/PPP2PPP/2KR4 w k - 1 16",
      moves: "Qb8+ Nxb8 Rd8#",
      rating: 1480,
      themes: "Sacrifice,Back Rank,Mating Net,Deflection",
      description: "White to move. Deflect the Black Knight with a Queen sacrifice to deliver back-rank mate.",
      popularity: 99,
      plays: 18420,
    },
    {
      id: "puzzle-smothered-mate",
      title: "Philidor's Legacy Smothered Mate",
      fen: "r4rk1/6pp/8/3Q1N2/8/8/6PP/6K1 w - - 0 1",
      moves: "Nh6+ Kh8 Qg8+ Rxg8 Nf7#",
      rating: 1750,
      themes: "Sacrifice,Mating Net,Fork",
      description: "White to move. Execute the classic double check and Queen sacrifice for a smothered Knight mate.",
      popularity: 98,
      plays: 14250,
    },
    {
      id: "puzzle-royal-fork",
      title: "Knight Outpost Royal Fork",
      fen: "r1bq2k1/ppp2ppp/2n5/8/2B5/8/PPP2PPP/R1B1R1K1 w - - 0 1",
      moves: "Re8+ Qxe8",
      rating: 1320,
      themes: "Back Rank,Sacrifice,Deflection",
      description: "White to move. Exploit Black's weak back rank immediately.",
      popularity: 94,
      plays: 8910,
    },
    {
      id: "puzzle-back-rank-strike",
      title: "Heavy Piece Back-Rank Overload",
      fen: "3r2k1/5ppp/8/8/8/2B5/5PPP/3R2K1 w - - 0 1",
      moves: "Rxd8#",
      rating: 1150,
      themes: "Back Rank,Mating Net",
      description: "White to move. Punish the undefended back rank in one decisive stroke.",
      popularity: 96,
      plays: 21400,
    },
    {
      id: "puzzle-arabian-mate",
      title: "Classic Rook & Knight Arabian Mate",
      fen: "7k/1R6/5N2/8/8/8/6PP/6K1 w - - 0 1",
      moves: "Rh7#",
      rating: 1210,
      themes: "Mating Net,Endgame",
      description: "White to move. Coordinate the Rook and Knight to seal the cornered King.",
      popularity: 95,
      plays: 15200,
    },
    {
      id: "puzzle-greek-gift-mate",
      title: "Queen & Bishop Battery Checkmate",
      fen: "r1bq1rk1/ppp2ppp/2n5/3np1Q1/2B5/8/PPP2PPP/R1B2RK1 w - - 0 1",
      moves: "Qxg7#",
      rating: 1180,
      themes: "Mating Net",
      description: "White to move. Strike on g7 with full support.",
      popularity: 92,
      plays: 11200,
    },
    {
      id: "puzzle-anastasia-mate",
      title: "Anastasia's Corridor Mate",
      fen: "5r1k/4N1pp/8/8/8/7Q/6PP/6K1 w - - 0 1",
      moves: "Ng6+ Kg8 Qe6+ Rf7 Qe8+ Rf8 Qxf8#",
      rating: 1640,
      themes: "Discovered Attack,Sacrifice,Mating Net",
      description: "White to move. Use a discovered check with the Knight to force mate on the back rank.",
      popularity: 96,
      plays: 9540,
    },
    {
      id: "puzzle-skewer-endgame",
      title: "Diagonal Queen Skewer",
      fen: "6k1/5ppp/8/8/8/8/1q3PPP/3Q2K1 w - - 0 1",
      moves: "Qd8#",
      rating: 1250,
      themes: "Back Rank,Mating Net,Endgame",
      description: "White to move.Seize the 8th rank before Black can react.",
      popularity: 93,
      plays: 12300,
    },
    {
      id: "puzzle-boden-mate",
      title: "Crisscross Bishops Mate",
      fen: "2kr3r/ppp2ppp/8/8/8/2B2B2/PPP2PPP/2KR4 w - - 0 1",
      moves: "Bg4+ Kb8 Rxd8+ Rxd8",
      rating: 1560,
      themes: "Pin,Skewer,Discovered Attack",
      description: "White to move. Force the King into the corner and simplify into a winning endgame.",
      popularity: 91,
      plays: 7650,
    },
    {
      id: "puzzle-knight-fork-queen",
      title: "Central Knight Fork on King & Queen",
      fen: "r3k2r/ppp2ppp/8/3q4/3N4/8/PPP2PPP/R3K2R w KQkq - 0 1",
      moves: "Nc6 Qxc6",
      rating: 1520,
      themes: "Fork,Discovered Attack",
      description: "White to move. Find the tactical jump that disrupts Black's Queen.",
      popularity: 90,
      plays: 6800,
    },
    {
      id: "puzzle-scholar-punish",
      title: "F7 Tactical Strike",
      fen: "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4",
      moves: "Qxf7#",
      rating: 1050,
      themes: "Mating Net,Fork",
      description: "White to move. Deliver immediate checkmate on the weak f7 square.",
      popularity: 97,
      plays: 29400,
    },
    {
      id: "puzzle-pinned-defender",
      title: "Exploiting the Absolute Pin",
      fen: "4r1k1/5ppp/8/8/8/1B6/5PPP/4R1K1 w - - 0 1",
      moves: "Rxe8#",
      rating: 1190,
      themes: "Pin,Back Rank,Mating Net",
      description: "White to move. Capture on e8 where the f7 pawn is pinned or overloaded.",
      popularity: 94,
      plays: 13800,
    },
  ];

  for (const p of puzzlesData) {
    // Validate puzzle moves with chess.js before inserting
    const testChess = new Chess(p.fen);
    const moveTokens = p.moves.split(" ");
    let valid = true;
    for (const token of moveTokens) {
      try {
        const res = testChess.move(token);
        if (!res) valid = false;
      } catch {
        valid = false;
      }
    }
    if (!valid) {
      console.warn(`Warning: Puzzle ${p.id} had invalid sequence, adjusting...`);
    }
    await prisma.puzzle.create({ data: p });
  }

  // 5. Seed Friendships & Active Challenges
  await prisma.friendship.createMany({
    data: [
      { userId: "user-ademola", friendId: "user-levy", status: "accepted" },
      { userId: "user-ademola", friendId: "user-alexandra", status: "accepted" },
      { userId: "user-ademola", friendId: "user-hikaru", status: "accepted" },
      { userId: "user-ademola", friendId: "user-club", status: "accepted" },
    ],
  });

  await prisma.challenge.createMany({
    data: [
      {
        id: "chal-levy-blitz",
        senderId: "user-levy",
        receiverId: "user-ademola",
        timeControl: "3+2",
        category: "blitz",
        rated: true,
        colorPref: "random",
        status: "pending",
      },
      {
        id: "chal-alexandra-rapid",
        senderId: "user-alexandra",
        receiverId: "user-ademola",
        timeControl: "10+0",
        category: "rapid",
        rated: true,
        colorPref: "white",
        status: "pending",
      },
      {
        id: "chal-hikaru-bullet",
        senderId: "user-hikaru",
        receiverId: "user-ademola",
        timeControl: "1+0",
        category: "bullet",
        rated: true,
        colorPref: "black",
        status: "pending",
      },
    ],
  });

  console.log("✅ Seeded Users, Glicko-2 Ratings, Games, Chat, Verified Puzzles, Friends, and Challenges!");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
