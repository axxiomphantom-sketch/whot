const BANNED_PATTERNS = [
  /\b(idiot|stupid|loser|cheater|noob|trash|garbage|scum|hate|kill|fuck|shit|bitch|asshole|damn)\b/gi,
];

export interface ModerationResult {
  cleanText: string;
  flagged: boolean;
  reason?: string;
}

export function moderateChatMessage(rawText: string): ModerationResult {
  const trimmed = rawText.trim().slice(0, 280);
  let cleanText = trimmed;
  let flagged = false;

  for (const pattern of BANNED_PATTERNS) {
    if (pattern.test(cleanText)) {
      flagged = true;
      cleanText = cleanText.replace(pattern, (match) => "•".repeat(match.length));
    }
  }

  return {
    cleanText,
    flagged,
    reason: flagged ? "Fair-play filter sanitized unsportsmanlike language." : undefined,
  };
}

export const QUICK_REACTIONS = [
  { emoji: "🤝", label: "Good Game" },
  { emoji: "👏", label: "Well Played" },
  { emoji: "🔥", label: "Sharp Move" },
  { emoji: "🤯", label: "Brilliant!" },
  { emoji: "😅", label: "Time Trouble" },
  { emoji: "⚡", label: "Rematch?" },
];
