"use client";

import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Chess } from "chess.js";
import {
  Bot,
  Flag,
  Handshake,
  Lightbulb,
  RotateCcw,
  RefreshCw,
  FlipVertical2,
  Trophy,
  WifiOff,
  GraduationCap,
  ClipboardCopy,
  Play,
} from "lucide-react";
import { ChessboardArena, BoardArrow, BoardThemeKey } from "./ChessboardArena";
import { PlayerHudBar } from "./PlayerHudBar";
import {
  selectBotMove,
  analyzePosition,
  evaluatePositionStatic,
} from "@/lib/engine";
import { soundEngine } from "@/lib/sound";
import { saveOfflineGame } from "@/lib/offlineStore";

export interface CoachBot {
  id: string;
  name: string;
  title: string;
  rating: number;
  avatar: string;
  blurb: string;
}

/** 8 coach personalities — the offline equivalent of Lichess's 12 levels / Chess.com bots. */
export const COACH_BOTS: CoachBot[] = [
  { id: "nora", name: "Nora", title: "Beginner", rating: 400, avatar: "🌱", blurb: "Just learned how the pieces move. Forgiving and fun." },
  { id: "pablo", name: "Pablo", title: "Casual", rating: 700, avatar: "🎲", blurb: "Plays on instinct. Loves grabbing pawns." },
  { id: "Mabel", name: "Mabel", title: "Club", rating: 1000, avatar: "☕", blurb: "Solid club regular with a soft spot for gambits." },
  { id: "fabian", name: "Fabian", title: "Intermediate", rating: 1200, avatar: "🎯", blurb: "Knows the main openings and basic tactics." },
  { id: "zara", name: "Zara", title: "Advanced", rating: 1500, avatar: "⚔️", blurb: "Sharp attacker. Punishes loose pieces quickly." },
  { id: "coach", name: "Coach Leke", title: "Expert", rating: 1800, avatar: "🎓", blurb: "Positional, patient, and hard to trick." },
  { id: "vera", name: "Vera", title: "Master", rating: 2100, avatar: "👑", blurb: "Master strength. Deep calculation, few mistakes." },
  { id: "obsidian", name: "Obsidian", title: "Grandmaster", rating: 2500, avatar: "💎", blurb: "Near-engine best play. Good luck — you'll need it." },
];

const START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";
const AUTOSAVE_KEY = "obsidian_current_computer_game_v2";

const TIME_OPTIONS = [
  { id: "unlimited", label: "Unlimited", baseMs: null as number | null, incMs: 0 },
  { id: "10+5", label: "10 + 5 · Rapid", baseMs: 600_000, incMs: 5_000 },
  { id: "5+3", label: "5 + 3 · Blitz", baseMs: 300_000, incMs: 3_000 },
  { id: "3+2", label: "3 + 2 · Blitz", baseMs: 180_000, incMs: 2_000 },
  { id: "1+0", label: "1 + 0 · Bullet", baseMs: 60_000, incMs: 0 },
];

interface OfflinePlayProps {
  playerName: string;
  playerAvatar: string;
  playerTitle?: string | null;
  boardTheme: BoardThemeKey;
  isOnline: boolean;
  initialBotRating?: number;
  botPickNonce?: number;
  onReviewGame: (pgn: string, whiteName: string, blackName: string) => void;
  onToast: (msg: string) => void;
}

interface SavedProgress {
  sans: string[];
  botId: string;
  playerColor: "w" | "b";
  tcId: string;
  times: { w: number; b: number } | null;
}

function buildChess(sans: string[]): Chess {
  const c = new Chess();
  for (const s of sans) {
    try {
      c.move(s);
    } catch {
      break;
    }
  }
  return c;
}

export default function OfflinePlay({
  playerName,
  playerAvatar,
  playerTitle,
  boardTheme,
  isOnline,
  initialBotRating,
  botPickNonce,
  onReviewGame,
  onToast,
}: OfflinePlayProps) {
  const [botId, setBotId] = useState<string>("zara");
  const bot = useMemo(
    () => COACH_BOTS.find((b) => b.id === botId) || COACH_BOTS[4],
    [botId]
  );
  const [colorChoice, setColorChoice] = useState<"white" | "black" | "random">("white");
  const [playerColor, setPlayerColor] = useState<"w" | "b">("w");
  const [tcId, setTcId] = useState("unlimited");
  const tc = TIME_OPTIONS.find((t) => t.id === tcId) || TIME_OPTIONS[0];

  const [sans, setSans] = useState<string[]>([]);
  const [times, setTimes] = useState<{ w: number; b: number } | null>(null);
  const [status, setStatus] = useState<"idle" | "active" | "done">("idle");
  const [result, setResult] = useState<string>("*");
  const [termination, setTermination] = useState<string>("");
  const [flipped, setFlipped] = useState<boolean | null>(null);
  const [practice, setPractice] = useState(true);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [hintArrows, setHintArrows] = useState<BoardArrow[]>([]);
  const [hintsUsed, setHintsUsed] = useState(0);
  const [thinking, setThinking] = useState(false);
  const [savedGameId, setSavedGameId] = useState<string | null>(null);

  const chess = useMemo(() => buildChess(sans), [sans]);
  const fen = chess.fen();
  const turn = chess.turn();
  const isPlayerTurn = status === "active" && turn === playerColor;
  const evalCp = useMemo(() => evaluatePositionStatic(buildChess(sans)), [sans]);
  const boardFlipped = flipped !== null ? flipped : playerColor === "b";

  const lastMove = useMemo(() => {
    if (sans.length === 0) return null;
    const c = new Chess();
    let last: { from: string; to: string } | null = null;
    for (const s of sans) {
      try {
        const m = c.move(s);
        last = { from: m.from, to: m.to };
      } catch {
        break;
      }
    }
    return last;
  }, [sans]);

  /* ---------- restore an in-progress computer game (offline resume) ---------- */
  const restoredRef = useRef(false);
  useEffect(() => {
    if (restoredRef.current) return;
    restoredRef.current = true;
    try {
      const raw = window.localStorage.getItem(AUTOSAVE_KEY);
      if (!raw) return;
      const saved = JSON.parse(raw) as SavedProgress;
      if (saved.sans && saved.sans.length > 0) {
        const c = buildChess(saved.sans);
        if (!c.isGameOver()) {
          setBotId(saved.botId || "zara");
          setPlayerColor(saved.playerColor || "w");
          setTcId(saved.tcId || "unlimited");
          setTimes(saved.times);
          setSans(saved.sans);
          setStatus("active");
          onToast("Resumed your saved game vs the computer ♟️");
        }
      }
    } catch {
      /* ignore */
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* Home "Play a coach" cards can push a bot selection in */
  useEffect(() => {
    if (!initialBotRating) return;
    const match = [...COACH_BOTS].sort(
      (a, b) =>
        Math.abs(a.rating - initialBotRating) - Math.abs(b.rating - initialBotRating)
    )[0];
    if (match) {
      setBotId(match.id);
      // nonce 0 = initial mount: only preselect the bot, never clobber a restored game
      if (botPickNonce && botPickNonce > 0 && status !== "active") {
        startGame(match.id, playerColor, tcId);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [botPickNonce]);

  /* ---------- autosave progress ---------- */
  useEffect(() => {
    if (status !== "active") return;
    try {
      const payload: SavedProgress = { sans, botId, playerColor, tcId, times };
      window.localStorage.setItem(AUTOSAVE_KEY, JSON.stringify(payload));
    } catch {
      /* ignore */
    }
  }, [sans, status, botId, playerColor, tcId, times]);

  const finishGame = useCallback(
    (res: string, term: string, finalSans: string[]) => {
      setResult(res);
      setTermination(term);
      setStatus("done");
      soundEngine.play("game_end");
      try {
        window.localStorage.removeItem(AUTOSAVE_KEY);
      } catch {
        /* ignore */
      }
      if (finalSans.length >= 2) {
        const c = buildChess(finalSans);
        const id = `offline-${Date.now()}`;
        saveOfflineGame({
          id,
          pgn: c.pgn(),
          fen: c.fen(),
          result: res,
          termination: term,
          opponentName: `${bot.name} (${bot.rating})`,
          opponentRating: bot.rating,
          playerColor,
          timeControlLabel: tc.label,
          createdAt: Date.now(),
          synced: false,
        });
        setSavedGameId(id);
      }
    },
    [bot, playerColor, tc]
  );

  const checkEnd = useCallback(
    (c: Chess, finalSans: string[]): boolean => {
      if (c.isCheckmate()) {
        finishGame(c.turn() === "w" ? "0-1" : "1-0", "checkmate", finalSans);
        return true;
      }
      if (c.isStalemate()) { finishGame("1/2-1/2", "stalemate", finalSans); return true; }
      if (c.isThreefoldRepetition()) { finishGame("1/2-1/2", "threefold repetition", finalSans); return true; }
      if (c.isInsufficientMaterial()) { finishGame("1/2-1/2", "insufficient material", finalSans); return true; }
      if (c.isDraw()) { finishGame("1/2-1/2", "50-move rule", finalSans); return true; }
      return false;
    },
    [finishGame]
  );

  const startGame = (useBotId = botId, keepColor?: "w" | "b", useTcId = tcId) => {
    const chosenBot = COACH_BOTS.find((b) => b.id === useBotId) || bot;
    const color: "w" | "b" =
      keepColor ||
      (colorChoice === "random"
        ? Math.random() < 0.5
          ? "w"
          : "b"
        : colorChoice === "white"
        ? "w"
        : "b");
    const chosenTc = TIME_OPTIONS.find((t) => t.id === useTcId) || TIME_OPTIONS[0];
    setPlayerColor(color);
    setFlipped(null);
    setSans([]);
    setTimes(chosenTc.baseMs ? { w: chosenTc.baseMs, b: chosenTc.baseMs } : null);
    setResult("*");
    setTermination("");
    setFeedback(null);
    setHintArrows([]);
    setHintsUsed(0);
    setSavedGameId(null);
    setStatus("active");
    soundEngine.play("game_start");
    onToast(
      `New game vs ${chosenBot.avatar} ${chosenBot.name} (${chosenBot.rating}) — you play ${color === "w" ? "White" : "Black"}${isOnline ? "" : " · offline"}`
    );
  };

  /* ---------- clocks ---------- */
  const lastTickRef = useRef<number>(Date.now());
  useEffect(() => {
    lastTickRef.current = Date.now();
    if (status !== "active" || !times) return;
    const id = window.setInterval(() => {
      const now = Date.now();
      const delta = now - lastTickRef.current;
      lastTickRef.current = now;
      setTimes((prev) => {
        if (!prev) return prev;
        const side = buildChess(sans).turn();
        const next = { ...prev, [side]: Math.max(0, prev[side] - delta) };
        if (next[side] <= 0) {
          window.clearInterval(id);
          const res = side === "w" ? "0-1" : "1-0";
          setTimeout(() => finishGame(res, "timeout", sans), 0);
        }
        return next;
      });
    }, 200);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status, sans]);

  const addIncrement = (color: "w" | "b") => {
    if (!times || tc.incMs === 0) return;
    setTimes((prev) => (prev ? { ...prev, [color]: prev[color] + tc.incMs } : prev));
  };

  /* ---------- moves ---------- */
  const handleMove = (mv: { from: string; to: string; promotion?: string }) => {
    if (!isPlayerTurn || thinking) return;
    const c = buildChess(sans);
    const evalBefore = evaluatePositionStatic(buildChess(sans));
    let m;
    try {
      m = c.move({ from: mv.from, to: mv.to, promotion: mv.promotion || "q" });
    } catch {
      soundEngine.play("illegal");
      return;
    }
    soundEngine.play(
      m.san.includes("#") || m.san.includes("+")
        ? "check"
        : m.captured
        ? "capture"
        : m.san.includes("O-O")
        ? "castle"
        : "move"
    );
    const nextSans = [...sans, m.san];
    setSans(nextSans);
    setHintArrows([]);
    addIncrement(playerColor);

    if (practice) {
      const evalAfter = evaluatePositionStatic(c);
      const cpLoss =
        playerColor === "w" ? evalBefore - evalAfter : evalAfter - evalBefore;
      const label =
        cpLoss <= 15
          ? `★ Best move — ${m.san} keeps everything under control.`
          : cpLoss <= 50
          ? `✓ Good — ${m.san} is a solid, practical choice.`
          : cpLoss <= 120
          ? `?! Inaccuracy — ${m.san} gives away a little ground (${(cpLoss / 100).toFixed(1)} pawns).`
          : `?? Careful! ${m.san} loses about ${(cpLoss / 100).toFixed(1)} pawns. Use Takeback to retry it.`;
      setFeedback(label);
    } else {
      setFeedback(null);
    }
    checkEnd(c, nextSans);
  };

  /* bot reply */
  useEffect(() => {
    if (status !== "active" || turn === playerColor) return;
    setThinking(true);
    const delay = 320 + Math.random() * 550;
    const id = window.setTimeout(() => {
      const c = buildChess(sans);
      const mv = selectBotMove(c.fen(), bot.rating);
      setThinking(false);
      if (!mv) {
        checkEnd(c, sans);
        return;
      }
      soundEngine.play(
        mv.san.includes("#") || mv.san.includes("+")
          ? "check"
          : mv.captured
          ? "capture"
          : mv.san.includes("O-O")
          ? "castle"
          : "move"
      );
      const nextSans = [...sans, mv.san];
      setSans(nextSans);
      addIncrement(playerColor === "w" ? "b" : "w");
      checkEnd(buildChess(nextSans), nextSans);
    }, delay);
    return () => window.clearTimeout(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sans, status, turn, playerColor, bot]);

  const takeback = () => {
    if (sans.length === 0 || thinking) return;
    // Undo back to the player's previous turn
    let next = [...sans];
    if (buildChess(next).turn() !== playerColor) next = next.slice(0, -1);
    if (next.length > 0) next = next.slice(0, -1);
    setSans(next);
    setStatus("active");
    setResult("*");
    setTermination("");
    setFeedback("Takeback accepted — try a different idea! ↩️");
    setHintArrows([]);
    soundEngine.play("move");
  };

  const showHint = () => {
    if (!isPlayerTurn) return;
    try {
      const lines = analyzePosition(fen, 2, 1);
      const best = lines[0];
      if (best && best.from) {
        setHintArrows([{ from: best.from, to: best.to, color: "#81B64C" }]);
        setHintsUsed((h) => h + 1);
        setFeedback(
          `💡 Hint: the engine likes ${best.bestMoveSan} (${best.scoreCp >= 0 ? "+" : ""}${(best.scoreCp / 100).toFixed(1)}).`
        );
      }
    } catch {
      onToast("No hint available in this position");
    }
  };

  const offerDraw = () => {
    if (status !== "active") return;
    const playerEval = playerColor === "w" ? evalCp : -evalCp;
    if (sans.length >= 20 && Math.abs(evalCp) < 90) {
      finishGame("1/2-1/2", "draw agreement", sans);
      onToast(`${bot.name} accepts the draw 🤝`);
    } else if (playerEval < -250) {
      onToast(`${bot.name} declines — "I'm better here, let's play on!"`);
      setFeedback(`${bot.name} declined your draw offer.`);
    } else {
      onToast(`${bot.name} declines for now — the game is still young.`);
      setFeedback(`${bot.name} declined your draw offer.`);
    }
  };

  const copyPgn = async () => {
    try {
      await navigator.clipboard.writeText(buildChess(sans).pgn() || "—");
      onToast("PGN copied 📋");
    } catch {
      onToast("Clipboard blocked by browser");
    }
  };

  const playerWon =
    status === "done" &&
    ((playerColor === "w" && result === "1-0") || (playerColor === "b" && result === "0-1"));
  const drew = status === "done" && result === "1/2-1/2";

  const topIsBot = !boardFlipped; // boardFlipped false => white at bottom
  const topColor: "w" | "b" = boardFlipped ? "w" : "b";
  const bottomColor: "w" | "b" = boardFlipped ? "b" : "w";
  const nameFor = (c: "w" | "b") => (c === playerColor ? playerName : `${bot.avatar} ${bot.name}`);
  const ratingFor = (c: "w" | "b") => (c === playerColor ? 0 : bot.rating);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[1fr_420px] gap-5 items-start">
      {/* Board column */}
      <div className="space-y-2.5">
        <PlayerHudBar
          username={nameFor(topColor)}
          title={topColor === playerColor ? playerTitle : bot.title}
          avatar={topColor === playerColor ? playerAvatar : bot.avatar}
          rating={ratingFor(topColor)}
          isAi={topColor !== playerColor}
          connected={isOnline}
          color={topColor}
          isActiveTurn={status === "active" && turn === topColor}
          timeRemainingMs={times ? times[topColor] : 0}
          fen={fen}
          showClock={!!times}
        />

        {status === "done" && (
          <div
            className={`max-w-[660px] mx-auto w-full p-4 rounded-2xl border text-center ${
              playerWon
                ? "bg-[#3A4A22]/60 border-[#81B64C]/70"
                : drew
                ? "bg-[#33302C]/80 border-[#4A463F]"
                : "bg-[#4A2626]/50 border-rose-500/50"
            }`}
          >
            <div className="font-display text-xl font-bold flex items-center justify-center gap-2">
              <Trophy className="w-5 h-5 text-amber-400" />
              {playerWon ? "You win!" : drew ? "Draw" : `${bot.name} wins`}{" "}
              <span className="font-mono text-base">{result}</span>
            </div>
            <p className="text-xs text-stone-300 mt-1 capitalize">
              by {termination} · vs {bot.name} ({bot.rating})
              {savedGameId
                ? isOnline
                  ? " · saved — will sync to your archive"
                  : " · saved on this device, syncs when you're back online"
                : ""}
            </p>
            <div className="flex justify-center gap-2 mt-3 flex-wrap">
              <button
                onClick={() => startGame(botId, playerColor, tcId)}
                className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white font-bold text-xs shadow-[0_4px_0_rgba(0,0,0,0.35)]"
              >
                ⟳ Rematch
              </button>
              <button
                onClick={() =>
                  onReviewGame(
                    buildChess(sans).pgn(),
                    playerColor === "w" ? playerName : bot.name,
                    playerColor === "b" ? playerName : bot.name
                  )
                }
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs"
              >
                🔍 Review game
              </button>
              <button
                onClick={() => setStatus("idle")}
                className="px-4 py-2 rounded-xl bg-[#35312C] border border-[#4A463F] text-xs"
              >
                Change bot
              </button>
            </div>
          </div>
        )}

        {feedback && status === "active" && (
          <div className="max-w-[660px] mx-auto w-full px-3.5 py-2.5 rounded-xl bg-[#2B2825] border border-[#4A463F] text-sm flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-amber-400 shrink-0" />
            <span>{feedback}</span>
          </div>
        )}

        <ChessboardArena
          fen={fen}
          flipped={boardFlipped}
          interactive={isPlayerTurn && !thinking}
          playerColor={playerColor}
          onMove={handleMove}
          lastMove={lastMove}
          engineArrows={hintArrows}
          evalCp={evalCp}
          theme={boardTheme}
        />

        <PlayerHudBar
          username={nameFor(bottomColor)}
          title={bottomColor === playerColor ? playerTitle : bot.title}
          avatar={bottomColor === playerColor ? playerAvatar : bot.avatar}
          rating={ratingFor(bottomColor)}
          isAi={bottomColor !== playerColor}
          connected={isOnline}
          color={bottomColor}
          isActiveTurn={status === "active" && turn === bottomColor}
          timeRemainingMs={times ? times[bottomColor] : 0}
          fen={fen}
          showClock={!!times}
        />

        <div className="max-w-[660px] mx-auto w-full flex flex-wrap gap-2">
          {status === "active" && (
            <>
              <button onClick={takeback} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#4A463F] text-xs">
                <RotateCcw className="w-3.5 h-3.5" /> Takeback
              </button>
              <button onClick={showHint} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#4A463F] text-xs">
                <Lightbulb className="w-3.5 h-3.5 text-amber-400" /> Hint{hintsUsed > 0 ? ` (${hintsUsed})` : ""}
              </button>
              <button onClick={offerDraw} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#4A463F] text-xs">
                <Handshake className="w-3.5 h-3.5 text-amber-400" /> Draw
              </button>
              <button
                onClick={() => finishGame(playerColor === "w" ? "0-1" : "1-0", "resignation", sans)}
                className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs"
              >
                <Flag className="w-3.5 h-3.5" /> Resign
              </button>
            </>
          )}
          <button onClick={() => setFlipped(!boardFlipped)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#4A463F] text-xs">
            <FlipVertical2 className="w-3.5 h-3.5" /> Flip
          </button>
          <button onClick={copyPgn} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#4A463F] text-xs">
            <ClipboardCopy className="w-3.5 h-3.5" /> Copy PGN
          </button>
          <span className="ml-auto font-mono text-[11px] text-stone-500 self-center flex items-center gap-1.5">
            {!isOnline && <WifiOff className="w-3.5 h-3.5 text-amber-400" />}
            {thinking ? `${bot.name} is thinking…` : status === "active" ? (isPlayerTurn ? "Your move" : `${bot.name} to move`) : "vs Computer · works offline"}
          </span>
        </div>
      </div>

      {/* Setup / bots column */}
      <div className="space-y-4">
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
          <h3 className="font-display font-bold flex items-center gap-2">
            <Bot className="w-4 h-4 text-emerald-400" /> Play vs Computer
            <span className="ml-auto px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-mono text-[10px] font-bold flex items-center gap-1">
              <WifiOff className="w-3 h-3" /> OFFLINE READY
            </span>
          </h3>
          <p className="text-xs text-stone-400 leading-relaxed">
            Runs 100% on your device with the local engine — no connection needed.
            Finished games save locally and sync to your archive when you&apos;re back online. Unrated.
          </p>

          <div className="grid grid-cols-2 gap-2">
            {COACH_BOTS.map((b) => (
              <button
                key={b.id}
                onClick={() => setBotId(b.id)}
                className={`p-2.5 rounded-xl border text-left transition-all ${
                  botId === b.id
                    ? "bg-emerald-500/15 border-emerald-500"
                    : "bg-[#201D1B] border-[#3A3733] hover:border-stone-500"
                }`}
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">{b.avatar}</span>
                  <span className="min-w-0">
                    <span className="block text-xs font-bold truncate">{b.name}</span>
                    <span className="block text-[10px] font-mono text-stone-400">
                      {b.title} · {b.rating}
                    </span>
                  </span>
                </div>
              </button>
            ))}
          </div>
          <p className="text-[11px] text-stone-400 italic">“{bot.blurb}”</p>

          <div className="grid grid-cols-2 gap-2">
            <label className="text-[11px] text-stone-400">
              Play as
              <select
                value={colorChoice}
                onChange={(e) => setColorChoice(e.target.value as typeof colorChoice)}
                className="w-full mt-1 px-2 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs"
              >
                <option value="white">⬜ White</option>
                <option value="black">⬛ Black</option>
                <option value="random">🎲 Random</option>
              </select>
            </label>
            <label className="text-[11px] text-stone-400">
              Clock
              <select
                value={tcId}
                onChange={(e) => setTcId(e.target.value)}
                className="w-full mt-1 px-2 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs"
              >
                {TIME_OPTIONS.map((t) => (
                  <option key={t.id} value={t.id}>{t.label}</option>
                ))}
              </select>
            </label>
          </div>

          <label className="flex items-center justify-between p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] cursor-pointer">
            <span className="text-xs flex items-center gap-2">
              <GraduationCap className="w-4 h-4 text-amber-400" />
              Practice mode — instant feedback on every move
            </span>
            <input
              type="checkbox"
              checked={practice}
              onChange={(e) => setPractice(e.target.checked)}
              className="accent-[#81B64C] w-4 h-4"
            />
          </label>

          <button
            onClick={() => startGame()}
            className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-display font-bold text-base shadow-[0_5px_0_#457A26] active:translate-y-0.5 active:shadow-[0_2px_0_#457A26] transition-all flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5" /> {status === "active" ? "Restart game" : `Play vs ${bot.name}`}
          </button>
          {status === "active" && (
            <button
              onClick={() => startGame(botId, playerColor, tcId)}
              className="w-full py-2 rounded-xl bg-[#35312C] border border-[#4A463F] text-xs flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" /> New game, same bot
            </button>
          )}
        </div>

        {/* Notation */}
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4">
          <div className="text-[11px] font-mono uppercase tracking-wider text-stone-400 mb-2">
            Moves {sans.length > 0 ? `(${Math.ceil(sans.length / 2)})` : ""}
          </div>
          {sans.length === 0 ? (
            <div className="py-5 text-center text-xs text-stone-500 font-mono">
              Pick a coach and press Play — notation appears here.
            </div>
          ) : (
            <div className="grid grid-cols-[36px_1fr_1fr] gap-y-1 text-sm font-mono max-h-52 overflow-y-auto pr-1">
              {Array.from({ length: Math.ceil(sans.length / 2) }).map((_, i) => (
                <React.Fragment key={i}>
                  <span className="text-stone-500 py-0.5">{i + 1}.</span>
                  <span className="px-1.5 py-0.5 rounded text-stone-100">{sans[i * 2]}</span>
                  <span className="px-1.5 py-0.5 rounded text-stone-100">{sans[i * 2 + 1] || ""}</span>
                </React.Fragment>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
