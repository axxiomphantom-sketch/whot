import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import {
  createLiveGameSession,
  parseTimeControl,
  triggerBotReplyIfNeeded,
} from "@/lib/gameManager";
import { redisStore } from "@/lib/redisStore";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    // 1. Create a direct 1v1 challenge
    if (action === "create") {
      const {
        senderId = "user-ademola",
        receiverId,
        timeControl = "3+2",
        rated = true,
        colorPref = "random",
        customFen = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
      } = body;

      if (!receiverId) {
        return NextResponse.json(
          { error: "Receiver ID is required" },
          { status: 400 }
        );
      }

      const { category } = parseTimeControl(timeControl);

      const challenge = await prisma.challenge.create({
        data: {
          senderId,
          receiverId,
          timeControl,
          category,
          rated: Boolean(rated),
          colorPref,
          customFen,
          status: "pending",
        },
        include: {
          sender: true,
          receiver: true,
        },
      });

      return NextResponse.json({ challenge });
    }

    // 2. Accept a challenge -> starts a live game immediately
    if (action === "accept") {
      const { challengeId } = body;
      const challenge = await prisma.challenge.findUnique({
        where: { id: challengeId },
      });
      if (!challenge) {
        return NextResponse.json(
          { error: "Challenge not found" },
          { status: 404 }
        );
      }

      await prisma.challenge.update({
        where: { id: challengeId },
        data: { status: "accepted" },
      });

      const senderWhite =
        challenge.colorPref === "white"
          ? true
          : challenge.colorPref === "black"
          ? false
          : Math.random() >= 0.5;

      const liveSession = await createLiveGameSession({
        whiteUserId: senderWhite ? challenge.senderId : challenge.receiverId,
        blackUserId: senderWhite ? challenge.receiverId : challenge.senderId,
        timeControl: challenge.timeControl,
        rated: challenge.rated,
        customFen: challenge.customFen,
      });

      if (liveSession.whitePlayer.isAi) {
        await triggerBotReplyIfNeeded(liveSession.id);
      }

      return NextResponse.json({
        gameState: redisStore.liveGames.get(liveSession.id) || liveSession,
      });
    }

    // 3. Decline / cancel a challenge
    if (action === "decline") {
      const { challengeId } = body;
      await prisma.challenge.delete({
        where: { id: challengeId },
      });
      return NextResponse.json({ success: true });
    }

    // 4. Add or Remove Friend
    if (action === "friend_toggle") {
      const { userId = "user-ademola", friendId } = body;
      const existing = await prisma.friendship.findFirst({
        where: {
          OR: [
            { userId, friendId },
            { userId: friendId, friendId: userId },
          ],
        },
      });

      if (existing) {
        await prisma.friendship.delete({ where: { id: existing.id } });
        return NextResponse.json({ status: "removed" });
      } else {
        const created = await prisma.friendship.create({
          data: {
            userId,
            friendId,
            status: "accepted",
          },
          include: {
            user: true,
            friend: true,
          },
        });
        return NextResponse.json({ status: "added", friendship: created });
      }
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: unknown) {
    console.error("Challenges API error:", err);
    return NextResponse.json(
      { error: "Failed to process challenge/friend request" },
      { status: 500 }
    );
  }
}
