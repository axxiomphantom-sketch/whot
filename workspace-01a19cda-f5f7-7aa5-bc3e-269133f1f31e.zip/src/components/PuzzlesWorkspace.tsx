"use client";

import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Chess } from "chess.js";
import { ChessboardArena, BoardThemeKey, BoardArrow } from "./ChessboardArena";
import { soundEngine } from "@/lib/sound";
import { queuePuzzleResult } from "@/lib/offlineStore";
import {
  Flame,
  Lightbulb,
  Eye,
  ArrowRight,
  Plus,
  Trash2,
  CheckCircle2,
  XCircle,
  Trophy,
  Timer,
  ShieldAlert,
  Sparkles,
} from "lucide-react";

export interface PuzzleItem {
  id: string;
  title: string;
  fen: string;
  moves: string;
  rating: number;
  themes: string;
  description: string;
  popularity: number;
  plays: number;
}

interface PuzzlesWorkspaceProps {
  puzzles: PuzzleItem[];
  userPuzzleRating: number;
  userPuzzleRd: number;
  puzzleRushBest: number;
  userId: string;
  boardTheme: BoardThemeKey;
  onPuzzleSolved: (newRating: number, delta: number) => void;
  onRushBestUpdated: (newBest: number) => void;
  onRefreshData: () => void;
}

const PUZZLE_THEMES = [
  "All",
  "Mating Net",
  "Fork",
  "Pin",
  "Skewer",
  "Back Rank",
  "Sacrifice",
  "Discovered Attack",
  "Deflection",
  "Endgame",
];

export const PuzzlesWorkspace: React.FC<PuzzlesWorkspaceProps> = ({
  puzzles,
  userPuzzleRating,
  userPuzzleRd,
  puzzleRushBest,
  userId,
  boardTheme,
  onPuzzleSolved,
  onRushBestUpdated,
  onRefreshData,
}) => {
  const [subMode, setSubMode] = useState<"rated" | "rush">("rated");
  const [selectedTheme, setSelectedTheme] = useState<string>("All");
  const [currentPuzzleIdx, setCurrentPuzzleIdx] = useState<number>(0);

  // Puzzle state
  const [boardFen, setBoardFen] = useState<string>("");
  const [solutionStep, setSolutionStep] = useState<number>(0);
  const [status, setStatus] = useState<"solving" | "correct" | "failed">("solving");
  const [feedbackText, setFeedbackText] = useState<string>(
    "Find the best tactical continuation!"
  );
  const [hintArrow, setHintArrow] = useState<BoardArrow[]>([]);
  const [lastMoveHighlight, setLastMoveHighlight] = useState<{
    from: string;
    to: string;
  } | null>(null);
  const [lastRatingDelta, setLastRatingDelta] = useState<number | null>(null);
  const [startTimeMs, setStartTimeMs] = useState<number>(Date.now());

  // Puzzle Rush State
  const [rushModeType, setRushModeType] = useState<"survival" | "3min" | "5min">(
    "3min"
  );
  const [rushActive, setRushActive] = useState<boolean>(false);
  const [rushScore, setRushScore] = useState<number>(0);
  const [rushStrikes, setRushStrikes] = useState<number>(0);
  const [rushSecondsLeft, setRushSecondsLeft] = useState<number>(180);
  const [rushHistory, setRushHistory] = useState<
    { id: string; rating: number; solved: boolean }[]
  >([]);

  // Custom Puzzle Creation Modal
  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [newTitle, setNewTitle] = useState("");
  const [newFen, setNewFen] = useState(
    "r1bqkbnr/pppp1ppp/2n5/4p2Q/2B1P3/8/PPPP1PPP/RNB1K1NR w KQkq - 4 4"
  );
  const [newMoves, setNewMoves] = useState("Qxf7#");
  const [newRating, setNewRating] = useState(1450);
  const [newThemes, setNewThemes] = useState("Mating Net,Fork");
  const [newDesc, setNewDesc] = useState("White to move and deliver mate.");
  const [createError, setCreateError] = useState<string | null>(null);

  const filteredPuzzles = useMemo(() => {
    if (selectedTheme === "All") return puzzles;
    return puzzles.filter((p) =>
      p.themes.toLowerCase().includes(selectedTheme.toLowerCase())
    );
  }, [puzzles, selectedTheme]);

  const currentPuzzle =
    filteredPuzzles[currentPuzzleIdx % Math.max(1, filteredPuzzles.length)] ||
    puzzles[0];

  const solutionTokens = useMemo(() => {
    if (!currentPuzzle) return [];
    return currentPuzzle.moves
      .trim()
      .split(/\s+/)
      .filter(Boolean);
  }, [currentPuzzle]);

  const playerColor = useMemo(() => {
    if (!currentPuzzle) return "w";
    try {
      const c = new Chess(currentPuzzle.fen);
      return c.turn();
    } catch {
      return "w";
    }
  }, [currentPuzzle]);

  const loadPuzzle = useCallback((puzzle: PuzzleItem | undefined) => {
    if (!puzzle) return;
    setBoardFen(puzzle.fen);
    setSolutionStep(0);
    setStatus("solving");
    setHintArrow([]);
    setLastMoveHighlight(null);
    setLastRatingDelta(null);
    setStartTimeMs(Date.now());
    const c = new Chess(puzzle.fen);
    setFeedbackText(
      `${c.turn() === "w" ? "White" : "Black"} to move — ${puzzle.description}`
    );
  }, []);

  useEffect(() => {
    if (currentPuzzle) {
      loadPuzzle(currentPuzzle);
    }
  }, [currentPuzzle, loadPuzzle]);

  // Puzzle Rush Countdown Timer
  useEffect(() => {
    if (!rushActive || rushModeType === "survival") return;
    const interval = setInterval(() => {
      setRushSecondsLeft((prev) => {
        if (prev <= 1) {
          setRushActive(false);
          soundEngine.play("game_end");
          return 0;
        }
        if (prev <= 10) {
          soundEngine.play("low_time");
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [rushActive, rushModeType]);

  const recordAttemptToServer = async (solved: boolean) => {
    if (!currentPuzzle) return;
    // Offline (or simulated offline): puzzles keep working locally.
    // The rated result is queued on-device and synced when back online.
    if (typeof navigator !== "undefined" && !navigator.onLine) {
      queuePuzzleResult({
        puzzleId: currentPuzzle.id,
        solved,
        timeTakenMs: Date.now() - startTimeMs,
        at: Date.now(),
      });
      setLastRatingDelta(null);
      return;
    }
    try {
      const res = await fetch("/api/puzzles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "attempt",
          userId,
          puzzleId: currentPuzzle.id,
          solved,
          timeTakenMs: Date.now() - startTimeMs,
        }),
      });
      const data = await res.json();
      if (data.ratingChange) {
        setLastRatingDelta(data.ratingChange.delta);
        onPuzzleSolved(data.ratingChange.rating, data.ratingChange.delta);
      }
    } catch {
      // Network dropped mid-attempt — queue the result for later sync.
      queuePuzzleResult({
        puzzleId: currentPuzzle.id,
        solved,
        timeTakenMs: Date.now() - startTimeMs,
        at: Date.now(),
      });
    }
  };

  const handleBoardMove = (moveInput: {
    from: string;
    to: string;
    promotion?: string;
  }) => {
    if (!currentPuzzle || status === "correct") return;

    const chess = new Chess(boardFen);
    let moveObj;
    try {
      moveObj = chess.move({
        from: moveInput.from,
        to: moveInput.to,
        promotion: moveInput.promotion || "q",
      });
    } catch {
      soundEngine.play("illegal");
      return;
    }
    if (!moveObj) return;

    const expectedSanOrUci = solutionTokens[solutionStep];
    const uciPlayed = `${moveObj.from}${moveObj.to}${moveObj.promotion || ""}`;
    const isMatch =
      moveObj.san === expectedSanOrUci ||
      moveObj.san.replace(/[+#]/g, "") ===
        expectedSanOrUci?.replace(/[+#]/g, "") ||
      uciPlayed === expectedSanOrUci;

    if (!isMatch) {
      soundEngine.play("illegal");
      setStatus("failed");
      setFeedbackText(
        `Incorrect (${moveObj.san}). Keep calculating or click Hint!`
      );

      if (subMode === "rush" && rushActive) {
        const nextStrikes = rushStrikes + 1;
        setRushStrikes(nextStrikes);
        setRushHistory((prev) => [
          ...prev,
          { id: currentPuzzle.id, rating: currentPuzzle.rating, solved: false },
        ]);
        if (nextStrikes >= 3) {
          setRushActive(false);
          soundEngine.play("game_end");
        } else {
          // Advance to next puzzle in Rush
          setTimeout(() => {
            setCurrentPuzzleIdx((idx) => idx + 1);
          }, 450);
        }
      } else {
        recordAttemptToServer(false);
      }
      return;
    }

    // Correct move!
    setBoardFen(chess.fen());
    setLastMoveHighlight({ from: moveObj.from, to: moveObj.to });
    setHintArrow([]);

    const nextStep = solutionStep + 1;
    if (nextStep >= solutionTokens.length) {
      // Puzzle completely solved!
      soundEngine.play("game_end");
      setStatus("correct");
      setFeedbackText(`Brilliant! Puzzle solved (${currentPuzzle.moves}).`);

      if (subMode === "rush" && rushActive) {
        const nextScore = rushScore + 1;
        setRushScore(nextScore);
        setRushHistory((prev) => [
          ...prev,
          { id: currentPuzzle.id, rating: currentPuzzle.rating, solved: true },
        ]);
        if (nextScore > puzzleRushBest) {
          onRushBestUpdated(nextScore);
          fetch("/api/puzzles", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "rush_score",
              userId,
              score: nextScore,
            }),
          }).catch(() => {});
        }
        setTimeout(() => {
          setCurrentPuzzleIdx((idx) => idx + 1);
        }, 420);
      } else {
        recordAttemptToServer(true);
      }
    } else {
      // Auto-play opponent's forced response after 320ms
      soundEngine.play(moveObj.captured ? "capture" : "move");
      setSolutionStep(nextStep);
      setFeedbackText("Great move! Opponent responds... find the follow-up!");

      setTimeout(() => {
        const replyChess = new Chess(chess.fen());
        const oppToken = solutionTokens[nextStep];
        try {
          const oppMove = replyChess.move(oppToken);
          if (oppMove) {
            soundEngine.play(oppMove.captured ? "capture" : "move");
            setBoardFen(replyChess.fen());
            setLastMoveHighlight({ from: oppMove.from, to: oppMove.to });
            setSolutionStep(nextStep + 1);
          }
        } catch {
          // If puzzle ended
        }
      }, 340);
    }
  };

  const handleShowHint = () => {
    if (!currentPuzzle || solutionStep >= solutionTokens.length) return;
    const chess = new Chess(boardFen);
    const expected = solutionTokens[solutionStep];
    try {
      const m = chess.move(expected);
      if (m) {
        setHintArrow([
          {
            from: m.from,
            to: m.to,
            color: "#81B64C",
          },
        ]);
        setFeedbackText(
          `Hint: Look closely at moving your ${m.piece.toUpperCase()} from ${m.from.toUpperCase()} to ${m.to.toUpperCase()}.`
        );
      }
    } catch {
      // ignore
    }
  };

  const handlePlaySolution = () => {
    if (!currentPuzzle) return;
    const chess = new Chess(currentPuzzle.fen);
    for (const token of solutionTokens) {
      try {
        chess.move(token);
      } catch {
        break;
      }
    }
    setBoardFen(chess.fen());
    setStatus("correct");
    setFeedbackText(`Solution Line: ${currentPuzzle.moves}`);
  };

  const startPuzzleRush = () => {
    setSubMode("rush");
    setRushScore(0);
    setRushStrikes(0);
    setRushHistory([]);
    setRushSecondsLeft(
      rushModeType === "3min" ? 180 : rushModeType === "5min" ? 300 : 9999
    );
    setRushActive(true);
    setCurrentPuzzleIdx(0);
    soundEngine.play("game_start");
  };

  const handleCreateCustomPuzzle = async (e: React.FormEvent) => {
    e.preventDefault();
    setCreateError(null);
    try {
      const res = await fetch("/api/puzzles", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "create",
          title: newTitle,
          fen: newFen,
          moves: newMoves,
          rating: newRating,
          themes: newThemes,
          description: newDesc,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setCreateError(data.error || "Failed to create puzzle");
        return;
      }
      setShowCreateModal(false);
      setNewTitle("");
      onRefreshData();
    } catch {
      setCreateError("Network error while saving puzzle");
    }
  };

  const handleDeletePuzzle = async (id: string) => {
    await fetch(`/api/puzzles?puzzleId=${id}`, { method: "DELETE" });
    onRefreshData();
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-[1fr_400px] gap-5 items-start">
      {/* Left Column: Interactive Tactical Board */}
      <div className="flex flex-col items-center space-y-3">
        {/* Top Puzzle Status Header Bar */}
        <div className="w-full max-w-[660px] flex items-center justify-between px-4 py-3 rounded-xl bg-[#2B2825] border border-[#3A3733]">
          <div className="flex items-center gap-3">
            <div
              className={`w-9 h-9 rounded-lg flex items-center justify-center font-bold text-lg ${
                playerColor === "w"
                  ? "bg-slate-100 text-slate-900"
                  : "bg-[#35312C] text-slate-100 border border-slate-600"
              }`}
            >
              {playerColor === "w" ? "♔" : "♚"}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-display font-bold text-sm text-slate-100">
                  {currentPuzzle?.title || "Tactical Trainer"}
                </span>
                <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30 font-mono text-xs font-bold">
                  Rating {currentPuzzle?.rating || 1500}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {playerColor === "w" ? "White to Move" : "Black to Move"} •{" "}
                {currentPuzzle?.plays.toLocaleString()} attempts
              </p>
            </div>
          </div>

          {/* User Glicko-2 Puzzle Rating Pill */}
          <div className="text-right">
            <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
              Your Puzzle Rating
            </div>
            <div className="flex items-center justify-end gap-1.5 font-mono text-lg font-extrabold text-emerald-400">
              <span>{userPuzzleRating}</span>
              <span className="text-xs text-slate-500 font-normal">
                ±{Math.round(userPuzzleRd)}
              </span>
              {lastRatingDelta !== null && (
                <span
                  className={`text-xs px-1.5 py-0.5 rounded ${
                    lastRatingDelta >= 0
                      ? "bg-emerald-500/20 text-emerald-300"
                      : "bg-rose-500/20 text-rose-300"
                  }`}
                >
                  {lastRatingDelta >= 0
                    ? `+${lastRatingDelta}`
                    : lastRatingDelta}
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Chessboard */}
        <ChessboardArena
          fen={boardFen || currentPuzzle?.fen || "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"}
          flipped={playerColor === "b"}
          interactive={true}
          playerColor={playerColor}
          onMove={handleBoardMove}
          lastMove={lastMoveHighlight}
          engineArrows={hintArrow}
          showEvalBar={false}
          theme={boardTheme}
        />

        {/* Feedback Banner below Board */}
        <div
          className={`w-full max-w-[660px] flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${
            status === "correct"
              ? "bg-emerald-950/40 border-emerald-500/50 text-emerald-200"
              : status === "failed"
              ? "bg-rose-950/40 border-rose-500/50 text-rose-200"
              : "bg-[#2B2825] border-[#3A3733] text-slate-200"
          }`}
        >
          <div className="flex items-center gap-2.5 text-sm font-medium">
            {status === "correct" ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            ) : status === "failed" ? (
              <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
            ) : (
              <Sparkles className="w-5 h-5 text-amber-400 shrink-0" />
            )}
            <span>{feedbackText}</span>
          </div>

          {status === "failed" && (
            <button
              onClick={() => loadPuzzle(currentPuzzle)}
              className="px-3 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/40 text-xs font-mono font-semibold shrink-0"
            >
              Retry Move
            </button>
          )}
        </div>
      </div>

      {/* Right Column: Tactical Control Deck & Puzzle Rush / Theme Selector */}
      <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-4">
        {/* Sub-mode Switcher: Rated Trainer vs Puzzle Rush */}
        <div className="grid grid-cols-2 gap-1.5 p-1 rounded-xl bg-[#201D1B] border border-[#3A3733]">
          <button
            onClick={() => {
              setSubMode("rated");
              setRushActive(false);
            }}
            className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              subMode === "rated"
                ? "bg-emerald-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Trophy className="w-3.5 h-3.5" />
            Rated Puzzles (Glicko-2)
          </button>
          <button
            onClick={() => setSubMode("rush")}
            className={`py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all ${
              subMode === "rush"
                ? "bg-amber-500 text-slate-950 font-bold shadow"
                : "text-slate-400 hover:text-slate-200"
            }`}
          >
            <Flame className="w-3.5 h-3.5" />
            Puzzle Rush
          </button>
        </div>

        {subMode === "rated" ? (
          <>
            {/* Theme Filter Matrix */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                  Filter by Tactical Motif
                </span>
                <button
                  onClick={() => setShowCreateModal(true)}
                  className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-400 border border-emerald-500/30 text-xs font-mono font-semibold"
                >
                  <Plus className="w-3.5 h-3.5" /> New Puzzle
                </button>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {PUZZLE_THEMES.map((t) => (
                  <button
                    key={t}
                    onClick={() => {
                      setSelectedTheme(t);
                      setCurrentPuzzleIdx(0);
                    }}
                    className={`px-2.5 py-1 rounded-lg text-xs font-medium border transition-all ${
                      selectedTheme === t
                        ? "bg-emerald-500/20 border-emerald-500 text-emerald-300"
                        : "bg-[#201D1B] border-[#3A3733] text-slate-400 hover:text-slate-200"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>
            </div>

            {/* Active Puzzle Themes Tags */}
            {currentPuzzle && (
              <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733] space-y-2">
                <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                  Active Puzzle Motifs
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {currentPuzzle.themes.split(",").map((th) => (
                    <span
                      key={th}
                      className="px-2 py-0.5 rounded bg-[#181E29] text-slate-300 border border-[#4A463F] text-[11px] font-mono"
                    >
                      #{th.trim()}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons: Hint, Show Solution, Next Puzzle */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleShowHint}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#35312C] hover:bg-[#3A3733] border border-[#4A463F] text-amber-300 text-xs font-semibold transition-all"
              >
                <Lightbulb className="w-4 h-4" /> Hint
              </button>
              <button
                onClick={handlePlaySolution}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-[#35312C] hover:bg-[#3A3733] border border-[#4A463F] text-sky-300 text-xs font-semibold transition-all"
              >
                <Eye className="w-4 h-4" /> Solution
              </button>
              <button
                onClick={() => setCurrentPuzzleIdx((idx) => idx + 1)}
                className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-all shadow"
              >
                Next <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Puzzle Directory List */}
            <div>
              <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                Tactical Puzzle Catalog ({filteredPuzzles.length})
              </div>
              <div className="space-y-1.5 max-h-64 overflow-y-auto pr-1">
                {filteredPuzzles.map((p, idx) => (
                  <div
                    key={p.id}
                    onClick={() => setCurrentPuzzleIdx(idx)}
                    className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition-all ${
                      currentPuzzle?.id === p.id
                        ? "bg-emerald-500/15 border-emerald-500/50"
                        : "bg-[#201D1B] border-[#3A3733] hover:border-slate-700"
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-200 truncate">
                        {p.title}
                      </div>
                      <div className="text-[10px] font-mono text-slate-400 truncate">
                        {p.themes}
                      </div>
                    </div>
                    <div className="flex items-center gap-2 shrink-0">
                      <span className="font-mono text-xs font-bold text-amber-400">
                        {p.rating}
                      </span>
                      {!p.id.startsWith("puzzle-") && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeletePuzzle(p.id);
                          }}
                          className="p-1 text-slate-500 hover:text-rose-400"
                          title="Delete custom puzzle"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </>
        ) : (
          /* PUZZLE RUSH PANEL */
          <div className="space-y-4">
            <div className="p-4 rounded-xl bg-gradient-to-br from-amber-500/15 via-[#201D1B] to-[#201D1B] border border-amber-500/30">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400">
                    High-Speed Tactical Blitz
                  </span>
                  <h3 className="text-lg font-display font-bold text-slate-100 flex items-center gap-1.5">
                    <Flame className="w-5 h-5 text-amber-400" /> Puzzle Rush
                  </h3>
                </div>
                <div className="text-right">
                  <span className="text-[10px] font-mono uppercase text-slate-400">
                    Personal Record
                  </span>
                  <div className="font-mono text-xl font-extrabold text-amber-400">
                    🔥 {puzzleRushBest}
                  </div>
                </div>
              </div>

              {/* Rush Mode Selector */}
              <div className="grid grid-cols-3 gap-2 mt-3">
                {(
                  [
                    { id: "3min", label: "3 Min Rush", sub: "Fast Blitz" },
                    { id: "5min", label: "5 Min Rush", sub: "Calculated" },
                    { id: "survival", label: "Survival", sub: "No Clock" },
                  ] as const
                ).map((m) => (
                  <button
                    key={m.id}
                    disabled={rushActive}
                    onClick={() => setRushModeType(m.id)}
                    className={`p-2 rounded-lg border text-left transition-all ${
                      rushModeType === m.id
                        ? "bg-amber-500/20 border-amber-500 text-amber-200"
                        : "bg-[#2B2825] border-[#3A3733] text-slate-400"
                    }`}
                  >
                    <div className="text-xs font-bold">{m.label}</div>
                    <div className="text-[10px] opacity-75">{m.sub}</div>
                  </button>
                ))}
              </div>
            </div>

            {/* Active Rush Scoreboard & Strikes */}
            <div className="grid grid-cols-3 gap-2.5 p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
              <div className="text-center p-2 rounded-lg bg-[#2B2825]">
                <div className="text-[10px] font-mono uppercase text-slate-400">
                  Score
                </div>
                <div className="font-mono text-2xl font-extrabold text-emerald-400 mt-0.5">
                  {rushScore}
                </div>
              </div>

              <div className="text-center p-2 rounded-lg bg-[#2B2825]">
                <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center justify-center gap-1">
                  <Timer className="w-3 h-3" /> Clock
                </div>
                <div className="font-mono text-xl font-bold text-slate-100 mt-1">
                  {rushModeType === "survival"
                    ? "∞"
                    : `${Math.floor(rushSecondsLeft / 60)}:${String(
                        rushSecondsLeft % 60
                      ).padStart(2, "0")}`}
                </div>
              </div>

              <div className="text-center p-2 rounded-lg bg-[#2B2825]">
                <div className="text-[10px] font-mono uppercase text-slate-400 flex items-center justify-center gap-1">
                  <ShieldAlert className="w-3 h-3 text-rose-400" /> Strikes
                </div>
                <div className="flex items-center justify-center gap-1.5 mt-1.5">
                  {[0, 1, 2].map((strikeIdx) => (
                    <span
                      key={strikeIdx}
                      className={`w-5 h-5 rounded flex items-center justify-center font-mono text-xs font-extrabold border ${
                        strikeIdx < rushStrikes
                          ? "bg-rose-500 text-white border-rose-400"
                          : "bg-[#201D1B] text-slate-600 border-[#3A3733]"
                      }`}
                    >
                      ✕
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Rush Progress Badges */}
            {rushHistory.length > 0 && (
              <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
                <div className="text-[10px] font-mono uppercase text-slate-400 mb-2">
                  Run Progression
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {rushHistory.map((item, i) => (
                    <span
                      key={`${item.id}-${i}`}
                      className={`px-2 py-0.5 rounded font-mono text-[11px] font-bold ${
                        item.solved
                          ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
                          : "bg-rose-500/20 text-rose-300 border border-rose-500/40"
                      }`}
                    >
                      {item.solved ? "✓" : "✕"} {item.rating}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={startPuzzleRush}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-display font-bold text-sm shadow-lg transition-all flex items-center justify-center gap-2"
            >
              <Flame className="w-4 h-4" />
              {rushActive ? "Restart Puzzle Rush" : "Start Puzzle Rush Now"}
            </button>
          </div>
        )}
      </div>

      {/* Create Custom Puzzle CRUD Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl max-w-lg w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#3A3733] pb-3">
              <h3 className="font-display font-bold text-base text-slate-100">
                Create Custom Tactical Puzzle
              </h3>
              <button
                onClick={() => setShowCreateModal(false)}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                ✕ Close
              </button>
            </div>

            <form onSubmit={handleCreateCustomPuzzle} className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Puzzle Title
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g., Sicilian Dragon Sacrifice"
                  className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-sm text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Starting FEN Position
                </label>
                <input
                  type="text"
                  required
                  value={newFen}
                  onChange={(e) => setNewFen(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Solution Moves (SAN space-separated)
                  </label>
                  <input
                    type="text"
                    required
                    value={newMoves}
                    onChange={(e) => setNewMoves(e.target.value)}
                    placeholder="e.g., Qxf7#"
                    className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-emerald-300"
                  />
                </div>
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Glicko-2 Rating
                  </label>
                  <input
                    type="number"
                    value={newRating}
                    onChange={(e) => setNewRating(Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Themes (comma-separated)
                </label>
                <input
                  type="text"
                  value={newThemes}
                  onChange={(e) => setNewThemes(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs text-slate-100"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Tactical Prompt Description
                </label>
                <input
                  type="text"
                  value={newDesc}
                  onChange={(e) => setNewDesc(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs text-slate-100"
                />
              </div>

              {createError && (
                <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/50 text-xs text-rose-200">
                  {createError}
                </div>
              )}

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 rounded-lg bg-[#35312C] text-xs text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                >
                  Validate & Save Puzzle
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
