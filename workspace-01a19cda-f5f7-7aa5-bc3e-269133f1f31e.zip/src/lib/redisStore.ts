export interface LiveGameState {
  id: string;
  whitePlayer: {
    id: string;
    username: string;
    title: string | null;
    avatar: string;
    rating: number;
    rd: number;
    isAi: boolean;
    connected: boolean;
  };
  blackPlayer: {
    id: string;
    username: string;
    title: string | null;
    avatar: string;
    rating: number;
    rd: number;
    isAi: boolean;
    connected: boolean;
  };
  fen: string;
  pgn: string;
  turn: "w" | "b";
  timeControl: string; // e.g. "3+2", "10+0", "1+0"
  category: "bullet" | "blitz" | "rapid" | "daily";
  rated: boolean;
  whiteTimeMs: number;
  blackTimeMs: number;
  incrementMs: number;
  lastMoveTimestamp: number;
  status: "active" | "completed";
  result: "*" | "1-0" | "0-1" | "1/2-1/2";
  termination: string;
  drawOfferedBy: "w" | "b" | null;
  whitePremove: { from: string; to: string; promotion?: string } | null;
  blackPremove: { from: string; to: string; promotion?: string } | null;
  moveHistory: {
    ply: number;
    san: string;
    from: string;
    to: string;
    color: "w" | "b";
    fen: string;
    timeSpentMs: number;
    evalCp: number;
  }[];
  ratingChange?: {
    whiteNew: number;
    whiteDelta: number;
    blackNew: number;
    blackDelta: number;
  };
}

export interface QueuedPlayer {
  userId: string;
  socketId: string;
  username: string;
  title: string | null;
  avatar: string;
  rating: number;
  rd: number;
  timeControl: string;
  category: "bullet" | "blitz" | "rapid" | "daily";
  rated: boolean;
  joinedAt: number;
}

export interface WsEventLogEntry {
  id: string;
  timestamp: string;
  direction: "IN" | "OUT";
  event: string;
  payloadSummary: string;
}

class RedisSessionStore {
  public liveGames = new Map<string, LiveGameState>();
  public matchmakingQueue = new Map<string, QueuedPlayer>();
  public wsEventLogs: WsEventLogEntry[] = [];

  public logEvent(direction: "IN" | "OUT", event: string, payload: unknown) {
    const entry: WsEventLogEntry = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
      timestamp: new Date().toISOString().split("T")[1].slice(0, 12),
      direction,
      event,
      payloadSummary:
        typeof payload === "string"
          ? payload
          : JSON.stringify(payload).slice(0, 180),
    };
    this.wsEventLogs.unshift(entry);
    if (this.wsEventLogs.length > 60) {
      this.wsEventLogs.pop();
    }
  }
}

const globalForRedis = globalThis as unknown as {
  redisStore: RedisSessionStore | undefined;
};

export const redisStore =
  globalForRedis.redisStore ?? new RedisSessionStore();

if (process.env.NODE_ENV !== "production") {
  globalForRedis.redisStore = redisStore;
}
