"use client";

import React, { useMemo } from "react";
import { getOpeningExplorerData } from "@/lib/engine";
import { BookOpen, Play } from "lucide-react";

interface OpeningExplorerPanelProps {
  fen: string;
  onPlayBookMove?: (san: string) => void;
}

export const OpeningExplorerPanel: React.FC<OpeningExplorerPanelProps> = ({
  fen,
  onPlayBookMove,
}) => {
  const data = useMemo(() => getOpeningExplorerData(fen), [fen]);

  return (
    <div className="space-y-3">
      {/* Header Banner */}
      <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
        <div className="flex items-center justify-between">
          <span className="px-2 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/30 font-mono text-xs font-bold">
            ECO {data.eco}
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            {data.totalMasterGames.toLocaleString()} Master Games
          </span>
        </div>
        <h4 className="text-sm font-bold text-slate-100 mt-1.5 flex items-center gap-1.5">
          <BookOpen className="w-4 h-4 text-emerald-400 shrink-0" />
          {data.name}
        </h4>
        <p className="text-xs text-slate-400 mt-1 leading-relaxed">
          {data.description}
        </p>
      </div>

      {/* Candidate Continuations Table with Stacked W/D/L Bars */}
      <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
        <div className="grid grid-cols-[56px_74px_1fr] gap-2 pb-2 mb-2 border-b border-[#3A3733] text-[10px] font-mono uppercase tracking-wider text-slate-400">
          <span>Move</span>
          <span>Games</span>
          <span>Win / Draw / Loss %</span>
        </div>

        {data.moves.length === 0 ? (
          <div className="text-center py-6 text-xs text-slate-500 font-mono">
            End of opening book reached — transition to engine calculation.
          </div>
        ) : (
          <div className="space-y-2">
            {data.moves.map((m) => (
              <div
                key={m.san}
                onClick={() => onPlayBookMove?.(m.san)}
                className="group p-2 rounded-lg bg-[#2B2825] hover:bg-[#35312C] border border-[#3A3733] hover:border-emerald-500/50 cursor-pointer transition-all"
              >
                <div className="grid grid-cols-[56px_74px_1fr] items-center gap-2">
                  <div className="flex items-center gap-1 font-mono text-xs font-bold text-emerald-400 group-hover:text-emerald-300">
                    <Play className="w-2.5 h-2.5 opacity-70" />
                    {m.san}
                  </div>
                  <div className="font-mono text-[11px] text-slate-300">
                    {m.totalGames.toLocaleString()}
                  </div>

                  {/* Stacked Horizontal W / D / L Bar */}
                  <div className="flex flex-col gap-1">
                    <div className="w-full h-3.5 rounded overflow-hidden flex font-mono text-[9px] font-bold leading-none">
                      <div
                        style={{ width: `${m.whiteWins}%` }}
                        className="bg-slate-100 text-slate-900 flex items-center justify-center"
                        title={`White Wins: ${m.whiteWins}%`}
                      >
                        {m.whiteWins >= 20 ? `${m.whiteWins}%` : ""}
                      </div>
                      <div
                        style={{ width: `${m.draws}%` }}
                        className="bg-slate-500 text-white flex items-center justify-center"
                        title={`Draws: ${m.draws}%`}
                      >
                        {m.draws >= 20 ? `${m.draws}%` : ""}
                      </div>
                      <div
                        style={{ width: `${m.blackWins}%` }}
                        className="bg-[#35312C] text-slate-200 flex items-center justify-center border-l border-slate-700"
                        title={`Black Wins: ${m.blackWins}%`}
                      >
                        {m.blackWins >= 20 ? `${m.blackWins}%` : ""}
                      </div>
                    </div>
                  </div>
                </div>
                <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400">
                  <span>{m.name}</span>
                  <span className="font-mono text-slate-500">
                    Avg Elo {m.avgRating}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
