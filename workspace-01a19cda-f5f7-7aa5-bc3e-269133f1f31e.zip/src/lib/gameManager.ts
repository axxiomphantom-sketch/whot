import { Chess } from "chess.js";
import { prisma } from "./prisma";
import { redisStore, LiveGameState } from "./redisStore";
import { calculateGlicko2Update } from "./glicko2";
import { evaluatePositionStatic, selectBotMove } from "./engine";

export function parseTimeControl(tc: string): {
  baseMs: number;
  incrementMs: number;
  category: "bullet" | "blitz" | "rapid" | "daily";
} {
  if (tc === "daily" || tc === "24h") {
    return { baseMs: 86400 * 1000, incrementMs: 0, category: "daily" };
  }
  const parts = tc.split("+").map((n) => parseFloat(n));
  const mins = !isNaN(parts[0]) ? parts[0] : 3;
  const incSec = !isNaN(parts[1]) ? parts[1] : 0;

  const baseMs = Math.max(15000, Math.round(mins * 60 * 1000));
  const incrementMs = Math.max(0, Math.round(incSec * 1000));

  const estimatedTotalSeconds = mins * 60 + 40 * incSec;
  let category: "bullet" | "blitz" | "rapid" | "daily" = "blitz";
  if (estimatedTotalSeconds < 180) {
    category = "bullet";
  } else if (estimatedTotalSeconds < 600) {
    category = "blitz";
  } else {
    category = "rapid";
  }

  return { baseMs, incrementMs, category };
}

export function getRatingByCategory(
  user: {
    bulletRating: number;
    bulletRd: number;
    bulletVol: number;
    blitzRating: number;
    blitzRd: number;
    blitzVol: number;
    rapidRating: number;
    rapidRd: number;
    rapidVol: number;
  },
  category: "bullet" | "blitz" | "rapid" | "daily"
) {
  if (category === "bullet") {
    return { rating: user.bulletRating, rd: user.bulletRd, vol: user.bulletVol };
  }
  if (category === "rapid" || category === "daily") {
    return { rating: user.rapidRating, rd: user.rapidRd, vol: user.rapidVol };
  }
  return { rating: user.blitzRating, rd: user.blitzRd, vol: user.blitzVol };
}

export async function createLiveGameSession(params: {
  whiteUserId: string;
  blackUserId: string;
  timeControl: string;
  rated: boolean;
  customFen?: string;
}): Promise<LiveGameState> {
  const { whiteUserId, blackUserId, timeControl, rated, customFen } = params;
  const [whiteUser, blackUser] = await Promise.all([
    prisma.user.findUniqueOrThrow({ where: { id: whiteUserId } }),
    prisma.user.findUniqueOrThrow({ where: { id: blackUserId } }),
  ]);

  const { baseMs, incrementMs, category } = parseTimeControl(timeControl);
  const wRating = getRatingByCategory(whiteUser, category);
  const bRating = getRatingByCategory(blackUser, category);

  const initialFen =
    customFen && customFen.trim()
      ? customFen.trim()
      : "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

  const chess = new Chess(initialFen);

  const dbGame = await prisma.game.create({
    data: {
      whitePlayerId: whiteUser.id,
      blackPlayerId: blackUser.id,
      pgn: "",
      fen: chess.fen(),
      result: "*",
      termination: "in_progress",
      timeControl,
      category,
      rated,
      whiteRatingBefore: wRating.rating,
      blackRatingBefore: bRating.rating,
    },
  });

  const liveState: LiveGameState = {
    id: dbGame.id,
    whitePlayer: {
      id: whiteUser.id,
      username: whiteUser.username,
      title: whiteUser.title,
      avatar: whiteUser.avatar,
      rating: wRating.rating,
      rd: wRating.rd,
      isAi: whiteUser.isAi,
      connected: true,
    },
    blackPlayer: {
      id: blackUser.id,
      username: blackUser.username,
      title: blackUser.title,
      avatar: blackUser.avatar,
      rating: bRating.rating,
      rd: bRating.rd,
      isAi: blackUser.isAi,
      connected: true,
    },
    fen: chess.fen(),
    pgn: "",
    turn: chess.turn(),
    timeControl,
    category,
    rated,
    whiteTimeMs: baseMs,
    blackTimeMs: baseMs,
    incrementMs,
    lastMoveTimestamp: Date.now(),
    status: "active",
    result: "*",
    termination: "in_progress",
    drawOfferedBy: null,
    whitePremove: null,
    blackPremove: null,
    moveHistory: [],
  };

  redisStore.liveGames.set(liveState.id, liveState);
  return liveState;
}

export async function finalizeGameSession(
  gameState: LiveGameState,
  result: "1-0" | "0-1" | "1/2-1/2",
  termination: string
): Promise<LiveGameState> {
  if (gameState.status === "completed") return gameState;

  gameState.status = "completed";
  gameState.result = result;
  gameState.termination = termination;
  gameState.drawOfferedBy = null;

  const scoreWhite: 1 | 0.5 | 0 =
    result === "1-0" ? 1 : result === "0-1" ? 0 : 0.5;
  const scoreBlack: 1 | 0.5 | 0 =
    result === "0-1" ? 1 : result === "1-0" ? 0 : 0.5;

  const wUpdate = calculateGlicko2Update(
    {
      rating: gameState.whitePlayer.rating,
      rd: gameState.whitePlayer.rd,
      vol: 0.06,
    },
    {
      rating: gameState.blackPlayer.rating,
      rd: gameState.blackPlayer.rd,
      vol: 0.06,
    },
    scoreWhite
  );

  const bUpdate = calculateGlicko2Update(
    {
      rating: gameState.blackPlayer.rating,
      rd: gameState.blackPlayer.rd,
      vol: 0.06,
    },
    {
      rating: gameState.whitePlayer.rating,
      rd: gameState.whitePlayer.rd,
      vol: 0.06,
    },
    scoreBlack
  );

  gameState.ratingChange = {
    whiteNew: gameState.rated ? wUpdate.rating : gameState.whitePlayer.rating,
    whiteDelta: gameState.rated ? wUpdate.delta : 0,
    blackNew: gameState.rated ? bUpdate.rating : gameState.blackPlayer.rating,
    blackDelta: gameState.rated ? bUpdate.delta : 0,
  };

  const evalHistory = gameState.moveHistory.map((m) => m.evalCp);
  const moveTimes = gameState.moveHistory.map((m) => m.timeSpentMs);

  await prisma.game.update({
    where: { id: gameState.id },
    data: {
      pgn: gameState.pgn,
      fen: gameState.fen,
      result,
      termination,
      whiteRatingDelta: gameState.ratingChange.whiteDelta,
      blackRatingDelta: gameState.ratingChange.blackDelta,
      evalHistoryJson: JSON.stringify(evalHistory),
      moveTimesJson: JSON.stringify(moveTimes),
      whiteAccuracy: 91.4,
      blackAccuracy: 88.7,
    },
  });

  if (gameState.rated) {
    const ratingField =
      gameState.category === "bullet"
        ? { bulletRating: wUpdate.rating, bulletRd: wUpdate.rd, bulletVol: wUpdate.vol }
        : gameState.category === "rapid" || gameState.category === "daily"
        ? { rapidRating: wUpdate.rating, rapidRd: wUpdate.rd, rapidVol: wUpdate.vol }
        : { blitzRating: wUpdate.rating, blitzRd: wUpdate.rd, blitzVol: wUpdate.vol };

    const blackRatingField =
      gameState.category === "bullet"
        ? { bulletRating: bUpdate.rating, bulletRd: bUpdate.rd, bulletVol: bUpdate.vol }
        : gameState.category === "rapid" || gameState.category === "daily"
        ? { rapidRating: bUpdate.rating, rapidRd: bUpdate.rd, rapidVol: bUpdate.vol }
        : { blitzRating: bUpdate.rating, blitzRd: bUpdate.rd, blitzVol: bUpdate.vol };

    await Promise.all([
      prisma.user.update({
        where: { id: gameState.whitePlayer.id },
        data: {
          ...ratingField,
          gamesPlayed: { increment: 1 },
          wins: result === "1-0" ? { increment: 1 } : undefined,
          losses: result === "0-1" ? { increment: 1 } : undefined,
          draws: result === "1/2-1/2" ? { increment: 1 } : undefined,
        },
      }),
      prisma.user.update({
        where: { id: gameState.blackPlayer.id },
        data: {
          ...blackRatingField,
          gamesPlayed: { increment: 1 },
          wins: result === "0-1" ? { increment: 1 } : undefined,
          losses: result === "1-0" ? { increment: 1 } : undefined,
          draws: result === "1/2-1/2" ? { increment: 1 } : undefined,
        },
      }),
      prisma.ratingHistory.createMany({
        data: [
          {
            userId: gameState.whitePlayer.id,
            category: gameState.category === "daily" ? "rapid" : gameState.category,
            rating: wUpdate.rating,
            rd: wUpdate.rd,
          },
          {
            userId: gameState.blackPlayer.id,
            category: gameState.category === "daily" ? "rapid" : gameState.category,
            rating: bUpdate.rating,
            rd: bUpdate.rd,
          },
        ],
      }),
    ]);
  }

  return gameState;
}

export async function processMoveInGame(
  gameId: string,
  moveInput: { from: string; to: string; promotion?: string } | string
): Promise<{
  success: boolean;
  error?: string;
  gameState?: LiveGameState;
  moveMade?: { san: string; from: string; to: string; flags: string };
}> {
  const gameState = redisStore.liveGames.get(gameId);
  if (!gameState) {
    return { success: false, error: "Live game session not found" };
  }
  if (gameState.status !== "active") {
    return { success: false, error: "Game has already concluded" };
  }

  const chess = new Chess();
  if (gameState.pgn) {
    chess.loadPgn(gameState.pgn);
  } else {
    chess.load(gameState.fen);
  }

  const now = Date.now();
  const elapsedMs = Math.max(0, now - gameState.lastMoveTimestamp);
  const movingColor = chess.turn();

  // Deduct elapsed time (after ply 2 so first moves have grace)
  if (gameState.moveHistory.length >= 2) {
    if (movingColor === "w") {
      gameState.whiteTimeMs = Math.max(0, gameState.whiteTimeMs - elapsedMs);
      if (gameState.whiteTimeMs === 0) {
        await finalizeGameSession(gameState, "0-1", "timeout");
        return { success: true, gameState };
      }
    } else {
      gameState.blackTimeMs = Math.max(0, gameState.blackTimeMs - elapsedMs);
      if (gameState.blackTimeMs === 0) {
        await finalizeGameSession(gameState, "1-0", "timeout");
        return { success: true, gameState };
      }
    }
  }

  let moveObj;
  try {
    if (typeof moveInput === "string") {
      moveObj = chess.move(moveInput);
    } else {
      moveObj = chess.move({
        from: moveInput.from,
        to: moveInput.to,
        promotion: moveInput.promotion || "q",
      });
    }
  } catch {
    return { success: false, error: "Illegal chess move" };
  }

  if (!moveObj) {
    return { success: false, error: "Illegal chess move" };
  }

  // Apply clock increment
  if (movingColor === "w") {
    gameState.whiteTimeMs += gameState.incrementMs;
    gameState.whitePremove = null;
  } else {
    gameState.blackTimeMs += gameState.incrementMs;
    gameState.blackPremove = null;
  }

  gameState.lastMoveTimestamp = now;
  gameState.fen = chess.fen();
  gameState.pgn = chess.pgn();
  gameState.turn = chess.turn();
  gameState.drawOfferedBy = null;

  const evalCp = evaluatePositionStatic(chess);
  gameState.moveHistory.push({
    ply: gameState.moveHistory.length + 1,
    san: moveObj.san,
    from: moveObj.from,
    to: moveObj.to,
    color: moveObj.color,
    fen: chess.fen(),
    timeSpentMs: elapsedMs,
    evalCp,
  });

  // Check game-end conditions
  if (chess.isCheckmate()) {
    await finalizeGameSession(
      gameState,
      movingColor === "w" ? "1-0" : "0-1",
      "checkmate"
    );
  } else if (chess.isStalemate()) {
    await finalizeGameSession(gameState, "1/2-1/2", "stalemate");
  } else if (chess.isThreefoldRepetition()) {
    await finalizeGameSession(gameState, "1/2-1/2", "repetition");
  } else if (chess.isInsufficientMaterial()) {
    await finalizeGameSession(gameState, "1/2-1/2", "insufficient");
  } else if (chess.isDraw()) {
    await finalizeGameSession(gameState, "1/2-1/2", "50-move-rule");
  }

  return {
    success: true,
    gameState,
    moveMade: {
      san: moveObj.san,
      from: moveObj.from,
      to: moveObj.to,
      flags: moveObj.flags,
    },
  };
}

export async function triggerBotReplyIfNeeded(
  gameId: string
): Promise<LiveGameState | null> {
  const gameState = redisStore.liveGames.get(gameId);
  if (!gameState || gameState.status !== "active") return null;

  const isWhiteTurn = gameState.turn === "w";
  const activePlayer = isWhiteTurn
    ? gameState.whitePlayer
    : gameState.blackPlayer;

  if (!activePlayer.isAi) return null;

  const botMove = selectBotMove(gameState.fen, activePlayer.rating);
  if (!botMove) return null;

  const res = await processMoveInGame(gameId, {
    from: botMove.from,
    to: botMove.to,
    promotion: botMove.promotion,
  });

  return res.gameState || null;
}
