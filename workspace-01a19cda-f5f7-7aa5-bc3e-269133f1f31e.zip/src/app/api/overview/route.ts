import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { redisStore } from "@/lib/redisStore";

export const dynamic = "force-dynamic";

export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get("userId") || "user-ademola";

    const [users, games, puzzles, challenges, friendships] = await Promise.all([
      prisma.user.findMany({
        orderBy: { blitzRating: "desc" },
        include: {
          ratingHistory: {
            orderBy: { recordedAt: "asc" },
          },
        },
      }),
      prisma.game.findMany({
        orderBy: { createdAt: "desc" },
        take: 25,
        include: {
          whitePlayer: true,
          blackPlayer: true,
          messages: {
            orderBy: { createdAt: "asc" },
          },
        },
      }),
      prisma.puzzle.findMany({
        orderBy: { rating: "asc" },
      }),
      prisma.challenge.findMany({
        where: { status: "pending" },
        orderBy: { createdAt: "desc" },
        include: {
          sender: true,
          receiver: true,
        },
      }),
      prisma.friendship.findMany({
        where: {
          OR: [{ userId }, { friendId: userId }],
        },
        include: {
          user: true,
          friend: true,
        },
      }),
    ]);

    const currentUser =
      users.find((u) => u.id === userId) || users[0] || null;

    return NextResponse.json({
      currentUser,
      users,
      games,
      puzzles,
      challenges,
      friendships,
      wsEventLogs: redisStore.wsEventLogs.slice(0, 35),
      activeLiveGamesCount: redisStore.liveGames.size,
    });
  } catch (err: unknown) {
    console.error("Overview API error:", err);
    return NextResponse.json(
      { error: "Failed to load platform overview" },
      { status: 500 }
    );
  }
}
