"use client";

import React, { useState, useMemo } from "react";
import { Chess, Square } from "chess.js";
import { ChessPieceSvg } from "./ChessPiecesSvg";
import { CLASSIFICATION_META, MoveClassification } from "@/lib/engine";

export type BoardThemeKey = "emerald" | "obsidian" | "walnut" | "ice";

export const BOARD_THEMES: Record<
  BoardThemeKey,
  { name: string; light: string; dark: string; coordLight: string; coordDark: string }
> = {
  emerald: {
    name: "Classic Green",
    light: "#EEEED2",
    dark: "#769656",
    coordLight: "#769656",
    coordDark: "#EEEED2",
  },
  obsidian: {
    name: "Obsidian Slate",
    light: "#CBD5E1",
    dark: "#57534C",
    coordLight: "#57534C",
    coordDark: "#CBD5E1",
  },
  walnut: {
    name: "Grandmaster Walnut",
    light: "#F0D9B5",
    dark: "#B58863",
    coordLight: "#B58863",
    coordDark: "#F0D9B5",
  },
  ice: {
    name: "Sapphire Ice",
    light: "#E0F2FE",
    dark: "#0369A1",
    coordLight: "#0369A1",
    coordDark: "#E0F2FE",
  },
};

export interface BoardArrow {
  from: string;
  to: string;
  color: string;
  label?: string;
}

interface ChessboardArenaProps {
  fen: string;
  flipped?: boolean;
  interactive?: boolean;
  playerColor?: "w" | "b" | "both";
  onMove?: (move: { from: string; to: string; promotion?: string }) => void;
  onPremove?: (premove: { from: string; to: string; promotion?: string } | null) => void;
  activePremove?: { from: string; to: string; promotion?: string } | null;
  lastMove?: { from: string; to: string } | null;
  classificationBadge?: {
    square: string;
    type: MoveClassification;
  } | null;
  engineArrows?: BoardArrow[];
  evalCp?: number;
  mateIn?: number | null;
  showEvalBar?: boolean;
  theme?: BoardThemeKey;
}

const FILES = ["a", "b", "c", "d", "e", "f", "g", "h"];
const RANKS = ["8", "7", "6", "5", "4", "3", "2", "1"];

function squareToCoords(square: string, flipped: boolean): { x: number; y: number } {
  const fileIdx = FILES.indexOf(square[0]);
  const rankIdx = RANKS.indexOf(square[1]);
  if (fileIdx < 0 || rankIdx < 0) return { x: 0, y: 0 };
  const col = flipped ? 7 - fileIdx : fileIdx;
  const row = flipped ? 7 - rankIdx : rankIdx;
  return {
    x: col * 12.5 + 6.25,
    y: row * 12.5 + 6.25,
  };
}

export const ChessboardArena: React.FC<ChessboardArenaProps> = ({
  fen,
  flipped = false,
  interactive = true,
  playerColor = "both",
  onMove,
  onPremove,
  activePremove = null,
  lastMove = null,
  classificationBadge = null,
  engineArrows = [],
  evalCp = 20,
  mateIn = null,
  showEvalBar = true,
  theme = "emerald",
}) => {
  const [selectedSquare, setSelectedSquare] = useState<string | null>(null);
  const [draggedFrom, setDraggedFrom] = useState<string | null>(null);
  const [pendingPromotion, setPendingPromotion] = useState<{
    from: string;
    to: string;
    color: "w" | "b";
  } | null>(null);

  // User tactical annotations (right-click arrows & square highlights)
  const [annotatedSquares, setAnnotatedSquares] = useState<Set<string>>(new Set());
  const [userArrows, setUserArrows] = useState<BoardArrow[]>([]);
  const [rightDragStart, setRightDragStart] = useState<string | null>(null);

  const chess = useMemo(() => {
    try {
      return new Chess(fen);
    } catch {
      return new Chess();
    }
  }, [fen]);

  const board = useMemo(() => chess.board(), [chess]);
  const turn = chess.turn();
  const inCheck = chess.inCheck();

  // Compute legal moves from selectedSquare
  const legalDestinations = useMemo(() => {
    const map = new Map<string, { isCapture: boolean; isPromotion: boolean }>();
    const activeSq = selectedSquare || draggedFrom;
    if (!activeSq) return map;

    try {
      const moves = chess.moves({ square: activeSq as Square, verbose: true });
      for (const m of moves) {
        map.set(m.to, {
          isCapture: Boolean(m.captured || m.flags.includes("e")),
          isPromotion: Boolean(m.promotion || m.flags.includes("p")),
        });
      }
    } catch {
      // ignore
    }
    return map;
  }, [chess, selectedSquare, draggedFrom]);

  // Find King square if in check
  const checkedKingSquare = useMemo(() => {
    if (!inCheck) return null;
    for (let r = 0; r < 8; r++) {
      for (let c = 0; c < 8; c++) {
        const p = board[r][c];
        if (p && p.type === "k" && p.color === turn) {
          return p.square;
        }
      }
    }
    return null;
  }, [board, inCheck, turn]);

  const handleSquareAction = (sq: string) => {
    if (!interactive) return;

    // Clear user right-click annotations on left click
    if (annotatedSquares.size > 0 || userArrows.length > 0) {
      setAnnotatedSquares(new Set());
      setUserArrows([]);
    }
    if (activePremove && onPremove && selectedSquare === null) {
      onPremove(null);
    }

    const pieceAtTarget = chess.get(sq as Square);
    const isMyTurn =
      playerColor === "both" || playerColor === turn;

    // If a square is already selected
    if (selectedSquare) {
      if (selectedSquare === sq) {
        setSelectedSquare(null);
        return;
      }

      // Check if it's our turn and a legal move
      if (isMyTurn && legalDestinations.has(sq)) {
        const destInfo = legalDestinations.get(sq)!;
        const movingPiece = chess.get(selectedSquare as Square);
        if (destInfo.isPromotion && movingPiece) {
          setPendingPromotion({
            from: selectedSquare,
            to: sq,
            color: movingPiece.color,
          });
          setSelectedSquare(null);
          return;
        }

        onMove?.({ from: selectedSquare, to: sq });
        setSelectedSquare(null);
        return;
      }

      // If it's NOT our turn, support Premove!
      if (!isMyTurn && onPremove && playerColor !== "both") {
        const fromPiece = chess.get(selectedSquare as Square);
        if (fromPiece && fromPiece.color === playerColor && selectedSquare !== sq) {
          onPremove({ from: selectedSquare, to: sq, promotion: "q" });
          setSelectedSquare(null);
          return;
        }
      }

      // Clicking another friendly piece switches selection
      if (
        pieceAtTarget &&
        ((isMyTurn && pieceAtTarget.color === turn) ||
          (!isMyTurn && pieceAtTarget.color === playerColor))
      ) {
        setSelectedSquare(sq);
        return;
      }

      setSelectedSquare(null);
      return;
    }

    // No square currently selected -> select friendly piece
    if (pieceAtTarget) {
      if (
        playerColor === "both"
          ? pieceAtTarget.color === turn
          : pieceAtTarget.color === playerColor
      ) {
        setSelectedSquare(sq);
      }
    }
  };

  const handleDropOnSquare = (targetSq: string) => {
    if (!interactive || !draggedFrom || draggedFrom === targetSq) {
      setDraggedFrom(null);
      return;
    }

    const isMyTurn = playerColor === "both" || playerColor === turn;

    if (isMyTurn && legalDestinations.has(targetSq)) {
      const destInfo = legalDestinations.get(targetSq)!;
      const movingPiece = chess.get(draggedFrom as Square);
      if (destInfo.isPromotion && movingPiece) {
        setPendingPromotion({
          from: draggedFrom,
          to: targetSq,
          color: movingPiece.color,
        });
        setDraggedFrom(null);
        setSelectedSquare(null);
        return;
      }
      onMove?.({ from: draggedFrom, to: targetSq });
    } else if (!isMyTurn && onPremove && playerColor !== "both") {
      const fromPiece = chess.get(draggedFrom as Square);
      if (fromPiece && fromPiece.color === playerColor) {
        onPremove({ from: draggedFrom, to: targetSq, promotion: "q" });
      }
    }

    setDraggedFrom(null);
    setSelectedSquare(null);
  };

  // Compute Eval Bar fill percentage (White's percentage from 4% to 96%)
  const whiteEvalPercent = useMemo(() => {
    if (mateIn !== null) {
      return mateIn > 0 || (mateIn === 0 && turn === "b") ? 97 : 3;
    }
    const clamped = Math.max(-900, Math.min(900, evalCp));
    // Sigmoid curve so +200cp looks clearly winning without pegging the bar
    const pct = 50 + 46 * (2 / (1 + Math.exp(-0.0042 * clamped)) - 1);
    return Math.round(pct);
  }, [evalCp, mateIn, turn]);

  const evalDisplayLabel = useMemo(() => {
    if (mateIn !== null) {
      if (mateIn === 0) return "1-0";
      return `M${Math.abs(mateIn)}`;
    }
    const pawns = (evalCp / 100).toFixed(1);
    return evalCp > 0 ? `+${pawns}` : pawns;
  }, [evalCp, mateIn]);

  const displayRanks = flipped ? [...RANKS].reverse() : RANKS;
  const displayFiles = flipped ? [...FILES].reverse() : FILES;
  const palette = BOARD_THEMES[theme] || BOARD_THEMES.emerald;
  const combinedArrows = [...engineArrows, ...userArrows];

  return (
    <div className="flex items-stretch gap-2.5 select-none w-full max-w-[660px] mx-auto">
      {/* Vertical Stockfish Evaluation Bar */}
      {showEvalBar && (
        <div
          className="w-7 rounded-lg overflow-hidden border border-[#3A3733] bg-[#201D1B] flex flex-col relative shrink-0 shadow-inner"
          title={`Position Evaluation: ${evalDisplayLabel}`}
        >
          <div
            className="w-full transition-all duration-300 ease-out"
            style={{
              height: flipped ? `${whiteEvalPercent}%` : `${100 - whiteEvalPercent}%`,
              backgroundColor: flipped ? "#F1F5F9" : "#201D1B",
            }}
          />
          <div
            className="w-full transition-all duration-300 ease-out"
            style={{
              height: flipped ? `${100 - whiteEvalPercent}%` : `${whiteEvalPercent}%`,
              backgroundColor: flipped ? "#201D1B" : "#F1F5F9",
            }}
          />
          {/* Midline tick */}
          <div className="absolute top-1/2 left-0 right-0 h-[1.5px] bg-emerald-500/60 z-10" />
          {/* Numeric Eval Label */}
          <span
            className={`absolute left-0 right-0 text-center font-mono text-[10px] font-bold tracking-tighter z-20 ${
              evalCp >= 0
                ? flipped
                  ? "top-1.5 text-slate-900"
                  : "bottom-1.5 text-slate-900"
                : flipped
                ? "bottom-1.5 text-slate-200"
                : "top-1.5 text-slate-200"
            }`}
          >
            {evalDisplayLabel}
          </span>
        </div>
      )}

      {/* Main 8x8 Chessboard Container */}
      <div
        className="relative flex-1 aspect-square rounded-xl overflow-hidden border-2 border-[#3A3733] shadow-[0_20px_50px_rgba(0,0,0,0.75)] bg-[#2B2825]"
        onContextMenu={(e) => e.preventDefault()}
      >
        <div className="grid grid-cols-8 grid-rows-8 w-full h-full">
          {displayRanks.map((rank, rIdx) =>
            displayFiles.map((file, fIdx) => {
              const sq = `${file}${rank}`;
              const realRow = RANKS.indexOf(rank);
              const realCol = FILES.indexOf(file);
              const isLight = (realRow + realCol) % 2 === 0;
              const piece = board[realRow]?.[realCol];

              const isSelected = selectedSquare === sq;
              const isLastMove =
                lastMove?.from === sq || lastMove?.to === sq;
              const isPremoveSq =
                activePremove?.from === sq || activePremove?.to === sq;
              const isKingChecked = checkedKingSquare === sq;
              const isAnnotated = annotatedSquares.has(sq);
              const legalMoveInfo = legalDestinations.get(sq);

              const badge =
                classificationBadge && classificationBadge.square === sq
                  ? CLASSIFICATION_META[classificationBadge.type]
                  : null;

              return (
                <div
                  key={sq}
                  onClick={() => handleSquareAction(sq)}
                  onMouseDown={(e) => {
                    if (e.button === 2) {
                      setRightDragStart(sq);
                    }
                  }}
                  onMouseUp={(e) => {
                    if (e.button === 2 && rightDragStart) {
                      if (rightDragStart === sq) {
                        setAnnotatedSquares((prev) => {
                          const next = new Set(prev);
                          if (next.has(sq)) next.delete(sq);
                          else next.add(sq);
                          return next;
                        });
                      } else {
                        setUserArrows((prev) => [
                          ...prev,
                          {
                            from: rightDragStart,
                            to: sq,
                            color: "rgba(245, 158, 11, 0.85)",
                          },
                        ]);
                      }
                      setRightDragStart(null);
                    }
                  }}
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={() => handleDropOnSquare(sq)}
                  className="relative flex items-center justify-center cursor-pointer select-none"
                  style={{
                    backgroundColor: isLight ? palette.light : palette.dark,
                  }}
                >
                  {/* Last Move Highlight Overlay */}
                  {isLastMove && (
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{ backgroundColor: "rgba(16, 185, 129, 0.34)" }}
                    />
                  )}

                  {/* Selected Square Highlight Overlay */}
                  {isSelected && (
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{ backgroundColor: "rgba(16, 185, 129, 0.52)" }}
                    />
                  )}

                  {/* Premove Highlight Overlay */}
                  {isPremoveSq && (
                    <div
                      className="absolute inset-0 pointer-events-none animate-pulse"
                      style={{ backgroundColor: "rgba(244, 63, 94, 0.48)" }}
                    />
                  )}

                  {/* Right-Click Tactical Annotation Highlight */}
                  {isAnnotated && (
                    <div
                      className="absolute inset-0 pointer-events-none border-[3px] border-amber-400/90"
                      style={{ backgroundColor: "rgba(245, 158, 11, 0.32)" }}
                    />
                  )}

                  {/* King in Check Radial Crimson Glow */}
                  {isKingChecked && (
                    <div
                      className="absolute inset-0 pointer-events-none animate-pulse"
                      style={{
                        background:
                          "radial-gradient(circle, rgba(239,68,68,0.9) 0%, rgba(239,68,68,0.45) 55%, rgba(239,68,68,0) 78%)",
                      }}
                    />
                  )}

                  {/* Rank Coordinate (Left Edge) */}
                  {fIdx === 0 && (
                    <span
                      className="absolute top-1 left-1.5 font-mono text-[10px] font-bold leading-none pointer-events-none opacity-85"
                      style={{
                        color: isLight ? palette.coordLight : palette.coordDark,
                      }}
                    >
                      {rank}
                    </span>
                  )}

                  {/* File Coordinate (Bottom Edge) */}
                  {rIdx === 7 && (
                    <span
                      className="absolute bottom-1 right-1.5 font-mono text-[10px] font-bold leading-none pointer-events-none opacity-85"
                      style={{
                        color: isLight ? palette.coordLight : palette.coordDark,
                      }}
                    >
                      {file}
                    </span>
                  )}

                  {/* Legal Move Indicator Dot / Capture Ring */}
                  {legalMoveInfo && (
                    <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-20">
                      {legalMoveInfo.isCapture ? (
                        <div className="w-[84%] h-[84%] rounded-full border-[4.5px] border-black/30 dark:border-emerald-950/45" />
                      ) : (
                        <div className="w-[28%] h-[28%] rounded-full bg-black/28" />
                      )}
                    </div>
                  )}

                  {/* Chess Piece SVG */}
                  {piece && (
                    <div
                      draggable={interactive}
                      onDragStart={() => {
                        setDraggedFrom(sq);
                        setSelectedSquare(sq);
                      }}
                      className="w-[84%] h-[84%] z-10 transition-transform duration-75 active:scale-110"
                    >
                      <ChessPieceSvg type={piece.type} color={piece.color} />
                    </div>
                  )}

                  {/* Move Classification Badge Overlay (!!, !, ★, ??, etc.) */}
                  {badge && (
                    <div
                      className="absolute -top-1 -right-1 z-30 px-1.5 py-0.5 rounded-full text-[10px] font-mono font-extrabold shadow-lg border"
                      style={{
                        backgroundColor: badge.color,
                        color: "#171512",
                        borderColor: "#FFFFFF",
                      }}
                      title={`${badge.type}: ${badge.description}`}
                    >
                      {badge.symbol}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* SVG Tactical & Engine Best-Move Arrow Overlay */}
        {combinedArrows.length > 0 && (
          <svg
            viewBox="0 0 100 100"
            className="absolute inset-0 w-full h-full pointer-events-none z-20"
          >
            <defs>
              <marker
                id="arrowhead-emerald"
                markerWidth="3.8"
                markerHeight="3.8"
                refX="2.4"
                refY="1.9"
                orient="auto"
              >
                <polygon points="0 0, 3.8 1.9, 0 3.8" fill="#81B64C" />
              </marker>
              <marker
                id="arrowhead-amber"
                markerWidth="3.8"
                markerHeight="3.8"
                refX="2.4"
                refY="1.9"
                orient="auto"
              >
                <polygon points="0 0, 3.8 1.9, 0 3.8" fill="#F59E0B" />
              </marker>
              <marker
                id="arrowhead-crimson"
                markerWidth="3.8"
                markerHeight="3.8"
                refX="2.4"
                refY="1.9"
                orient="auto"
              >
                <polygon points="0 0, 3.8 1.9, 0 3.8" fill="#EF4444" />
              </marker>
            </defs>
            {combinedArrows.map((arrow, idx) => {
              if (!arrow.from || !arrow.to) return null;
              const start = squareToCoords(arrow.from, flipped);
              const end = squareToCoords(arrow.to, flipped);
              const dx = end.x - start.x;
              const dy = end.y - start.y;
              const len = Math.sqrt(dx * dx + dy * dy);
              if (len === 0) return null;
              // Shorten end slightly so arrowhead lands in center of target square
              const targetX = end.x - (dx / len) * 2.2;
              const targetY = end.y - (dy / len) * 2.2;
              const isRed = arrow.color.includes("239") || arrow.color.includes("EF4444");
              const isAmber = arrow.color.includes("245") || arrow.color.includes("F59E0B");
              const marker = isRed
                ? "url(#arrowhead-crimson)"
                : isAmber
                ? "url(#arrowhead-amber)"
                : "url(#arrowhead-emerald)";

              return (
                <line
                  key={`${arrow.from}-${arrow.to}-${idx}`}
                  x1={start.x}
                  y1={start.y}
                  x2={targetX}
                  y2={targetY}
                  stroke={arrow.color}
                  strokeWidth="2.1"
                  strokeLinecap="round"
                  opacity="0.88"
                  markerEnd={marker}
                />
              );
            })}
          </svg>
        )}

        {/* Pawn Promotion Modal Overlay */}
        {pendingPromotion && (
          <div className="absolute inset-0 bg-black/65 backdrop-blur-sm z-40 flex items-center justify-center p-4">
            <div className="bg-[#2B2825] border border-emerald-500/50 rounded-xl p-4 shadow-2xl max-w-xs w-full text-center">
              <div className="text-xs font-mono uppercase tracking-wider text-emerald-400 mb-1">
                Pawn Promotion
              </div>
              <div className="text-sm font-semibold text-slate-100 mb-3">
                Select Promotion Piece ({pendingPromotion.to.toUpperCase()})
              </div>
              <div className="grid grid-cols-4 gap-2">
                {(["q", "r", "b", "n"] as const).map((pType) => (
                  <button
                    key={pType}
                    onClick={() => {
                      onMove?.({
                        from: pendingPromotion.from,
                        to: pendingPromotion.to,
                        promotion: pType,
                      });
                      setPendingPromotion(null);
                    }}
                    className="flex flex-col items-center justify-center p-2 rounded-lg bg-[#35312C] hover:bg-emerald-500/20 border border-[#3A3733] hover:border-emerald-500 transition-all"
                  >
                    <div className="w-12 h-12">
                      <ChessPieceSvg
                        type={pType}
                        color={pendingPromotion.color}
                      />
                    </div>
                    <span className="text-[11px] font-mono uppercase text-slate-300 mt-1">
                      {pType === "q"
                        ? "Queen"
                        : pType === "r"
                        ? "Rook"
                        : pType === "b"
                        ? "Bishop"
                        : "Knight"}
                    </span>
                  </button>
                ))}
              </div>
              <button
                onClick={() => setPendingPromotion(null)}
                className="mt-3 text-xs text-slate-400 hover:text-slate-200"
              >
                Cancel Move
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
