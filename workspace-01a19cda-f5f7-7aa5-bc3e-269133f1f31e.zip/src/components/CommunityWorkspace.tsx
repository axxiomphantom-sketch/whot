"use client";

import React, { useState, useMemo } from "react";
import {
  Trophy,
  Swords,
  UserPlus,
  UserCheck,
  Search,
  TrendingUp,
  Activity,
  ExternalLink,
  Check,
  X,
  Plus,
  Trash2,
} from "lucide-react";

export interface PlatformUser {
  id: string;
  username: string;
  email: string;
  title: string | null;
  avatar: string;
  country: string;
  bio: string;
  isAi: boolean;
  isOnline: boolean;
  bulletRating: number;
  bulletRd: number;
  bulletVol: number;
  blitzRating: number;
  blitzRd: number;
  blitzVol: number;
  rapidRating: number;
  rapidRd: number;
  rapidVol: number;
  puzzleRating: number;
  puzzleRd: number;
  puzzleRushBest: number;
  gamesPlayed: number;
  wins: number;
  losses: number;
  draws: number;
  streak: number;
  ratingHistory?: {
    id: string;
    category: string;
    rating: number;
    rd: number;
    recordedAt: string;
  }[];
}

export interface ChallengeRecord {
  id: string;
  senderId: string;
  receiverId: string;
  timeControl: string;
  category: string;
  rated: boolean;
  colorPref: string;
  customFen: string;
  status: string;
  sender: PlatformUser;
  receiver: PlatformUser;
}

export interface GameArchiveRecord {
  id: string;
  whitePlayerId: string;
  blackPlayerId: string;
  pgn: string;
  fen: string;
  result: string;
  termination: string;
  timeControl: string;
  category: string;
  rated: boolean;
  whiteAccuracy: number | null;
  blackAccuracy: number | null;
  openingEco: string;
  openingName: string;
  whiteRatingBefore: number;
  blackRatingBefore: number;
  whiteRatingDelta: number;
  blackRatingDelta: number;
  createdAt: string;
  whitePlayer: PlatformUser;
  blackPlayer: PlatformUser;
}

interface CommunityWorkspaceProps {
  currentUser: PlatformUser;
  users: PlatformUser[];
  games: GameArchiveRecord[];
  challenges: ChallengeRecord[];
  friendIds: Set<string>;
  onAcceptChallenge: (challengeId: string) => void;
  onDeclineChallenge: (challengeId: string) => void;
  onCreateChallenge: (params: {
    receiverId: string;
    timeControl: string;
    rated: boolean;
    colorPref: string;
    customFen?: string;
  }) => void;
  onToggleFriend: (friendId: string) => void;
  onOpenGameInAnalysis: (game: GameArchiveRecord) => void;
  onDeleteGame: (gameId: string) => void;
  onStartDirectMatch: (opponentId: string, timeControl: string) => void;
}

export const CommunityWorkspace: React.FC<CommunityWorkspaceProps> = ({
  currentUser,
  users,
  games,
  challenges,
  friendIds,
  onAcceptChallenge,
  onDeclineChallenge,
  onCreateChallenge,
  onToggleFriend,
  onOpenGameInAnalysis,
  onDeleteGame,
  onStartDirectMatch,
}) => {
  const [leaderboardCategory, setLeaderboardCategory] = useState<
    "blitz" | "bullet" | "rapid" | "puzzle"
  >("blitz");
  const [searchQuery, setSearchQuery] = useState("");
  const [inspectedUserId, setInspectedUserId] = useState<string>(currentUser.id);

  // Create Challenge Modal state
  const [challengeTargetUser, setChallengeTargetUser] =
    useState<PlatformUser | null>(null);
  const [chalTimeControl, setChalTimeControl] = useState("3+2");
  const [chalRated, setChalRated] = useState(true);
  const [chalColor, setChalColor] = useState<"random" | "white" | "black">(
    "random"
  );
  const [chalCustomFen, setChalCustomFen] = useState("");

  const inspectedUser = useMemo(
    () => users.find((u) => u.id === inspectedUserId) || currentUser,
    [users, inspectedUserId, currentUser]
  );

  const sortedUsers = useMemo(() => {
    const filtered = users.filter(
      (u) =>
        u.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (u.title && u.title.toLowerCase().includes(searchQuery.toLowerCase()))
    );
    return filtered.sort((a, b) => {
      if (leaderboardCategory === "bullet") return b.bulletRating - a.bulletRating;
      if (leaderboardCategory === "rapid") return b.rapidRating - a.rapidRating;
      if (leaderboardCategory === "puzzle") return b.puzzleRating - a.puzzleRating;
      return b.blitzRating - a.blitzRating;
    });
  }, [users, searchQuery, leaderboardCategory]);

  const userGames = useMemo(
    () =>
      games.filter(
        (g) =>
          g.whitePlayerId === inspectedUser.id ||
          g.blackPlayerId === inspectedUser.id
      ),
    [games, inspectedUser.id]
  );

  // Build Rating Progression SVG points for inspectedUser
  const ratingCurvePoints = useMemo(() => {
    const hist =
      inspectedUser.ratingHistory?.filter(
        (r) => r.category === leaderboardCategory
      ) || [];
    if (hist.length === 0) {
      const base =
        leaderboardCategory === "bullet"
          ? inspectedUser.bulletRating
          : leaderboardCategory === "rapid"
          ? inspectedUser.rapidRating
          : leaderboardCategory === "puzzle"
          ? inspectedUser.puzzleRating
          : inspectedUser.blitzRating;
      return [
        base - 65,
        base - 48,
        base - 52,
        base - 30,
        base - 18,
        base - 24,
        base - 8,
        base,
      ];
    }
    return hist.map((h) => h.rating);
  }, [inspectedUser, leaderboardCategory]);

  const minR = Math.min(...ratingCurvePoints) - 20;
  const maxR = Math.max(...ratingCurvePoints) + 20;
  const svgW = 360;
  const svgH = 90;
  const ratingSvgPath = ratingCurvePoints
    .map((r, idx) => {
      const x =
        ratingCurvePoints.length <= 1
          ? svgW / 2
          : (idx / (ratingCurvePoints.length - 1)) * (svgW - 20) + 10;
      const y =
        svgH - 12 - ((r - minR) / Math.max(1, maxR - minR)) * (svgH - 24);
      return `${idx === 0 ? "M" : "L"} ${x.toFixed(1)} ${y.toFixed(1)}`;
    })
    .join(" ");

  const totalDecided =
    inspectedUser.wins + inspectedUser.losses + inspectedUser.draws || 1;
  const winPct = Math.round((inspectedUser.wins / totalDecided) * 100);
  const drawPct = Math.round((inspectedUser.draws / totalDecided) * 100);
  const lossPct = Math.max(0, 100 - winPct - drawPct);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-[1.15fr_0.85fr] gap-5 items-start">
      {/* Left Column: Global Leaderboards & Direct 1v1 Challenges Queue */}
      <div className="space-y-5">
        {/* Active 1v1 Challenges Queue */}
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
                <Swords className="w-4 h-4 text-emerald-400" />
                Live 1v1 Challenges & Invites ({challenges.length})
              </h3>
              <p className="text-xs text-slate-400">
                Accept an incoming challenge to launch directly onto the live WebSocket board, or issue a custom invite.
              </p>
            </div>
            <button
              onClick={() =>
                setChallengeTargetUser(
                  users.find((u) => u.id !== currentUser.id) || users[0]
                )
              }
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs shadow transition-all"
            >
              <Plus className="w-3.5 h-3.5" /> New Challenge
            </button>
          </div>

          {challenges.length === 0 ? (
            <div className="p-6 text-center rounded-xl bg-[#201D1B] border border-[#3A3733] text-xs text-slate-400">
              No pending challenges right now. Click{" "}
              <span className="text-emerald-400 font-semibold">
                + New Challenge
              </span>{" "}
              or challenge any player from the leaderboard below!
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5">
              {challenges.map((c) => (
                <div
                  key={c.id}
                  className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-emerald-500/40 flex items-center justify-between gap-2 transition-all"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-9 h-9 rounded-lg bg-[#35312C] border border-[#4A463F] flex items-center justify-center text-base shrink-0">
                      {c.sender.avatar}
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        {c.sender.title && (
                          <span className="px-1 py-0.2 rounded bg-amber-500/20 text-amber-400 font-mono text-[10px] font-bold">
                            {c.sender.title}
                          </span>
                        )}
                        <span className="font-semibold text-xs text-slate-100 truncate">
                          {c.sender.username}
                        </span>
                      </div>
                      <div className="flex items-center gap-1.5 mt-0.5 font-mono text-[11px] text-emerald-400">
                        <span>{c.timeControl}</span>
                        <span>•</span>
                        <span className="uppercase">{c.category}</span>
                        <span>•</span>
                        <span className="text-slate-400">
                          {c.rated ? "Rated" : "Casual"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onAcceptChallenge(c.id)}
                      className="px-2.5 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1"
                      title="Accept & Play Now"
                    >
                      <Check className="w-3.5 h-3.5" /> Play
                    </button>
                    <button
                      onClick={() => onDeclineChallenge(c.id)}
                      className="p-1.5 rounded-lg bg-[#35312C] hover:bg-rose-500/20 text-slate-400 hover:text-rose-300 border border-[#4A463F]"
                      title="Decline Challenge"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Global Glicko-2 Leaderboards */}
        <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              Glicko-2 Standings & Player Directory
            </h3>

            {/* Category Tabs */}
            <div className="flex items-center gap-1 p-1 rounded-xl bg-[#201D1B] border border-[#3A3733]">
              {(["blitz", "bullet", "rapid", "puzzle"] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setLeaderboardCategory(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-mono uppercase font-semibold transition-all ${
                    leaderboardCategory === cat
                      ? "bg-emerald-500 text-slate-950 font-bold"
                      : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search grandmasters, titled players, or friends..."
              className="w-full pl-9 pr-3 py-2 rounded-xl bg-[#201D1B] border border-[#3A3733] text-xs text-slate-100 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Standings Table */}
          <div className="space-y-1.5">
            {sortedUsers.map((u, idx) => {
              const rating =
                leaderboardCategory === "bullet"
                  ? u.bulletRating
                  : leaderboardCategory === "rapid"
                  ? u.rapidRating
                  : leaderboardCategory === "puzzle"
                  ? u.puzzleRating
                  : u.blitzRating;
              const rd =
                leaderboardCategory === "bullet"
                  ? u.bulletRd
                  : leaderboardCategory === "rapid"
                  ? u.rapidRd
                  : leaderboardCategory === "puzzle"
                  ? u.puzzleRd
                  : u.blitzRd;
              const isFriend = friendIds.has(u.id);
              const isSelected = inspectedUser.id === u.id;

              return (
                <div
                  key={u.id}
                  onClick={() => setInspectedUserId(u.id)}
                  className={`flex items-center justify-between p-2.5 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? "bg-[#35312C] border-emerald-500/60"
                      : "bg-[#201D1B] border-[#3A3733] hover:border-slate-700"
                  }`}
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span
                      className={`w-6 text-center font-mono text-xs font-extrabold ${
                        idx === 0
                          ? "text-amber-400"
                          : idx === 1
                          ? "text-slate-300"
                          : idx === 2
                          ? "text-amber-600"
                          : "text-slate-500"
                      }`}
                    >
                      #{idx + 1}
                    </span>

                    <div className="relative">
                      <div className="w-9 h-9 rounded-lg bg-[#2B2825] border border-[#4A463F] flex items-center justify-center text-base">
                        {u.avatar}
                      </div>
                      <span
                        className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-[#201D1B] ${
                          u.isOnline ? "bg-emerald-500" : "bg-slate-600"
                        }`}
                      />
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        {u.title && (
                          <span className="px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 font-mono text-[10px] font-bold">
                            {u.title}
                          </span>
                        )}
                        <span className="font-semibold text-xs text-slate-100 truncate">
                          {u.username}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500">
                          [{u.country}]
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 truncate max-w-[240px]">
                        {u.wins}W / {u.draws}D / {u.losses}L • Streak 🔥{u.streak}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 shrink-0">
                    <div className="text-right">
                      <div className="font-mono text-sm font-extrabold text-emerald-400">
                        {rating}
                      </div>
                      <div className="font-mono text-[10px] text-slate-500">
                        RD ±{Math.round(rd)}
                      </div>
                    </div>

                    {u.id !== currentUser.id && (
                      <div
                        className="flex items-center gap-1"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <button
                          onClick={() => onToggleFriend(u.id)}
                          className={`p-1.5 rounded-lg border transition-all ${
                            isFriend
                              ? "bg-emerald-500/15 border-emerald-500/40 text-emerald-400"
                              : "bg-[#2B2825] border-[#3A3733] text-slate-400 hover:text-slate-200"
                          }`}
                          title={isFriend ? "Friends (Click to remove)" : "Add Friend"}
                        >
                          {isFriend ? (
                            <UserCheck className="w-3.5 h-3.5" />
                          ) : (
                            <UserPlus className="w-3.5 h-3.5" />
                          )}
                        </button>
                        <button
                          onClick={() => onStartDirectMatch(u.id, "3+2")}
                          className="px-2.5 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-slate-950 border border-emerald-500/40 font-mono text-[11px] font-bold transition-all"
                          title="Play Live 1v1 Now"
                        >
                          Play
                        </button>
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right Column: Inspected Player Profile Dossier, Rating Progression & Game History */}
      <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-4">
        {/* Player Profile Header */}
        <div className="p-4 rounded-xl bg-[#201D1B] border border-[#3A3733] flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-14 h-14 rounded-xl bg-[#35312C] border border-emerald-500/40 flex items-center justify-center text-2xl shadow-inner">
              {inspectedUser.avatar}
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                {inspectedUser.title && (
                  <span className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40 font-mono text-xs font-extrabold">
                    {inspectedUser.title}
                  </span>
                )}
                <h3 className="font-display font-bold text-lg text-slate-100">
                  {inspectedUser.username}
                </h3>
                <span className="text-xs font-mono text-slate-400">
                  ({inspectedUser.country})
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1 max-w-sm">
                {inspectedUser.bio}
              </p>
            </div>
          </div>

          {inspectedUser.id !== currentUser.id && (
            <button
              onClick={() => setChallengeTargetUser(inspectedUser)}
              className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs shrink-0"
            >
              Custom Invite
            </button>
          )}
        </div>

        {/* 4-Category Glicko-2 Ratings Matrix */}
        <div className="grid grid-cols-4 gap-2">
          {[
            {
              label: "Bullet",
              rating: inspectedUser.bulletRating,
              rd: inspectedUser.bulletRd,
              vol: inspectedUser.bulletVol,
            },
            {
              label: "Blitz",
              rating: inspectedUser.blitzRating,
              rd: inspectedUser.blitzRd,
              vol: inspectedUser.blitzVol,
            },
            {
              label: "Rapid",
              rating: inspectedUser.rapidRating,
              rd: inspectedUser.rapidRd,
              vol: inspectedUser.rapidVol,
            },
            {
              label: "Tactics",
              rating: inspectedUser.puzzleRating,
              rd: inspectedUser.puzzleRd,
              vol: 0.06,
            },
          ].map((item) => (
            <div
              key={item.label}
              className="p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] text-center"
            >
              <div className="text-[10px] font-mono uppercase text-slate-400">
                {item.label}
              </div>
              <div className="font-mono text-lg font-extrabold text-slate-100 mt-0.5">
                {item.rating}
              </div>
              <div className="font-mono text-[10px] text-emerald-400">
                ±{Math.round(item.rd)} RD
              </div>
            </div>
          ))}
        </div>

        {/* Glicko-2 Rating History SVG Curve */}
        <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              Glicko-2 {leaderboardCategory.toUpperCase()} Rating History
            </span>
            <span className="font-mono text-xs text-emerald-400 font-bold">
              Peak {Math.max(...ratingCurvePoints)}
            </span>
          </div>
          <svg
            viewBox={`0 0 ${svgW} ${svgH}`}
            className="w-full h-24 rounded-lg bg-[#2B2825] border border-[#3A3733]"
          >
            <path
              d={ratingSvgPath}
              fill="none"
              stroke="#81B64C"
              strokeWidth="2.4"
              strokeLinecap="round"
            />
          </svg>
        </div>

        {/* Win / Draw / Loss Performance Bar */}
        <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733] space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-mono uppercase text-[11px] text-slate-400 flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-sky-400" />
              Career W/D/L Breakdown ({inspectedUser.gamesPlayed} Games)
            </span>
            <span className="font-mono text-xs text-slate-300">
              {winPct}% Win Rate
            </span>
          </div>
          <div className="w-full h-3 rounded-full overflow-hidden flex">
            <div
              style={{ width: `${winPct}%` }}
              className="bg-emerald-500"
              title={`Wins: ${inspectedUser.wins}`}
            />
            <div
              style={{ width: `${drawPct}%` }}
              className="bg-slate-400"
              title={`Draws: ${inspectedUser.draws}`}
            />
            <div
              style={{ width: `${lossPct}%` }}
              className="bg-rose-500"
              title={`Losses: ${inspectedUser.losses}`}
            />
          </div>
          <div className="flex justify-between font-mono text-[11px] text-slate-400">
            <span className="text-emerald-400">{inspectedUser.wins} Wins</span>
            <span>{inspectedUser.draws} Draws</span>
            <span className="text-rose-400">{inspectedUser.losses} Losses</span>
          </div>
        </div>

        {/* Player Match History Log with 1-Click Engine Review */}
        <div>
          <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
            Recent Match Archive ({userGames.length})
          </div>
          <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
            {userGames.map((g) => {
              const isWhite = g.whitePlayerId === inspectedUser.id;
              const won =
                (isWhite && g.result === "1-0") ||
                (!isWhite && g.result === "0-1");
              const drew = g.result === "1/2-1/2";

              return (
                <div
                  key={g.id}
                  className="p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-slate-700 flex items-center justify-between gap-2"
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-200">
                      <span
                        className={`px-1.5 py-0.2 rounded font-mono text-[10px] font-bold ${
                          won
                            ? "bg-emerald-500/20 text-emerald-400"
                            : drew
                            ? "bg-slate-500/20 text-slate-300"
                            : "bg-rose-500/20 text-rose-400"
                        }`}
                      >
                        {won ? "WIN" : drew ? "DRAW" : "LOSS"} ({g.result})
                      </span>
                      <span className="truncate">
                        {g.whitePlayer.username} vs {g.blackPlayer.username}
                      </span>
                    </div>
                    <div className="text-[11px] font-mono text-slate-400 mt-0.5 truncate">
                      {g.timeControl} • {g.openingName} • Acc:{" "}
                      <span className="text-emerald-400">
                        {g.whiteAccuracy ?? 91.2}%
                      </span>{" "}
                      / {g.blackAccuracy ?? 88.4}%
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <button
                      onClick={() => onOpenGameInAnalysis(g)}
                      className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/30 text-[11px] font-mono font-semibold"
                    >
                      <ExternalLink className="w-3 h-3" /> Review
                    </button>
                    {!g.id.startsWith("game-") && (
                      <button
                        onClick={() => onDeleteGame(g.id)}
                        className="p-1 text-slate-500 hover:text-rose-400"
                        title="Delete archived game"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Create Direct 1v1 Challenge Modal */}
      {challengeTargetUser && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl max-w-md w-full p-5 shadow-2xl space-y-4">
            <div className="flex items-center justify-between border-b border-[#3A3733] pb-3">
              <h3 className="font-display font-bold text-base text-slate-100 flex items-center gap-2">
                <Swords className="w-4 h-4 text-emerald-400" />
                Create Direct 1v1 Challenge
              </h3>
              <button
                onClick={() => setChallengeTargetUser(null)}
                className="text-xs text-slate-400 hover:text-slate-200"
              >
                ✕ Close
              </button>
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Select Opponent
                </label>
                <select
                  value={challengeTargetUser.id}
                  onChange={(e) => {
                    const found = users.find((u) => u.id === e.target.value);
                    if (found) setChallengeTargetUser(found);
                  }}
                  className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs text-slate-100"
                >
                  {users
                    .filter((u) => u.id !== currentUser.id)
                    .map((u) => (
                      <option key={u.id} value={u.id}>
                        {u.title ? `${u.title} ` : ""}
                        {u.username} (Blitz {u.blitzRating})
                      </option>
                    ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Time Control
                  </label>
                  <select
                    value={chalTimeControl}
                    onChange={(e) => setChalTimeControl(e.target.value)}
                    className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-xs text-slate-100"
                  >
                    <option value="1+0">1+0 Bullet</option>
                    <option value="1+1">1+1 Bullet</option>
                    <option value="2+1">2+1 Bullet</option>
                    <option value="3+0">3+0 Blitz</option>
                    <option value="3+2">3+2 Blitz</option>
                    <option value="5+0">5+0 Blitz</option>
                    <option value="10+0">10+0 Rapid</option>
                    <option value="15+10">15+10 Rapid</option>
                    <option value="daily">Daily (24h)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-slate-400 mb-1">
                    Color Assignment
                  </label>
                  <select
                    value={chalColor}
                    onChange={(e) =>
                      setChalColor(
                        e.target.value as "random" | "white" | "black"
                      )
                    }
                    className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs text-slate-100"
                  >
                    <option value="random">Random Color</option>
                    <option value="white">Play as White</option>
                    <option value="black">Play as Black</option>
                  </select>
                </div>
              </div>

              <div className="flex items-center justify-between p-2.5 rounded-lg bg-[#201D1B] border border-[#3A3733]">
                <span className="text-xs text-slate-300">
                  Rated Match (Glicko-2 Points Active)
                </span>
                <input
                  type="checkbox"
                  checked={chalRated}
                  onChange={(e) => setChalRated(e.target.checked)}
                  className="accent-emerald-500 w-4 h-4"
                />
              </div>

              <div>
                <label className="block text-xs text-slate-400 mb-1">
                  Optional Custom Starting FEN (leave blank for standard)
                </label>
                <input
                  type="text"
                  value={chalCustomFen}
                  onChange={(e) => setChalCustomFen(e.target.value)}
                  placeholder="rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
                  className="w-full px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] font-mono text-[11px] text-slate-200"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  onClick={() => setChallengeTargetUser(null)}
                  className="px-4 py-2 rounded-lg bg-[#35312C] text-xs text-slate-300"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    onCreateChallenge({
                      receiverId: challengeTargetUser.id,
                      timeControl: chalTimeControl,
                      rated: chalRated,
                      colorPref: chalColor,
                      customFen: chalCustomFen || undefined,
                    });
                    setChallengeTargetUser(null);
                  }}
                  className="px-4 py-2 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                >
                  Send Challenge Invite
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
