"use client";

import React, { useMemo } from "react";
import {
  Play,
  Puzzle as PuzzleIcon,
  GraduationCap,
  Search,
  Trophy,
  Flame,
  Bot,
  Wifi,
  WifiOff,
  Download,
  Check,
  Lock,
  Users,
  Swords,
  ChevronRight,
  Clock3,
  Sparkles,
  CloudUpload,
  MonitorSmartphone,
} from "lucide-react";
import type {
  PlatformUser,
  GameArchiveRecord,
  ChallengeRecord,
} from "./CommunityWorkspace";
import type { PuzzleItem } from "./PuzzlesWorkspace";
import { COACH_BOTS } from "./OfflinePlay";
import { OFFLINE_CAPABILITIES, timeAgo } from "@/lib/offlineStore";

export type AppTab =
  | "home"
  | "play"
  | "computer"
  | "analysis"
  | "puzzles"
  | "community"
  | "architecture";

const QUICK_PAIRING = [
  { id: "1+0", big: "1+0", cat: "Bullet" },
  { id: "2+1", big: "2+1", cat: "Bullet" },
  { id: "3+0", big: "3+0", cat: "Blitz" },
  { id: "3+2", big: "3+2", cat: "Blitz" },
  { id: "5+0", big: "5+0", cat: "Blitz" },
  { id: "5+3", big: "5+3", cat: "Blitz" },
  { id: "10+0", big: "10+0", cat: "Rapid" },
  { id: "15+10", big: "15+10", cat: "Rapid" },
  { id: "daily", big: "Daily", cat: "Correspondence" },
];

const GLYPHS: Record<string, string> = {
  K: "♔", Q: "♕", R: "♖", B: "♗", N: "♘", P: "♙",
  k: "♚", q: "♛", r: "♜", b: "♝", n: "♞", p: "♟",
};

function MiniBoard({ fen }: { fen: string }) {
  const cells = useMemo(() => {
    const rows: (string | null)[][] = [];
    const placement = (fen || "").split(" ")[0] || "";
    for (const rank of placement.split("/")) {
      const row: (string | null)[] = [];
      for (const ch of rank) {
        if (/\d/.test(ch)) {
          for (let i = 0; i < parseInt(ch, 10); i++) row.push(null);
        } else row.push(ch);
      }
      while (row.length < 8) row.push(null);
      rows.push(row.slice(0, 8));
    }
    while (rows.length < 8) rows.push(Array(8).fill(null));
    return rows;
  }, [fen]);

  return (
    <div className="w-[76px] h-[76px] rounded-lg overflow-hidden border border-black/40 grid grid-cols-8 grid-rows-8 shrink-0 shadow">
      {cells.flatMap((row, r) =>
        row.map((p, c) => (
          <div
            key={`${r}-${c}`}
            className="flex items-center justify-center leading-none"
            style={{
              backgroundColor: (r + c) % 2 === 0 ? "#EEEED2" : "#769656",
              fontSize: 10,
            }}
          >
            {p ? (
              <span
                style={{
                  color: p === p.toUpperCase() ? "#FFFFFF" : "#1B1B19",
                  textShadow:
                    p === p.toUpperCase()
                      ? "0 0 2px #1B1B19, 0 1px 1px #1B1B19"
                      : "0 0 2px rgba(255,255,255,.35)",
                }}
              >
                {GLYPHS[p]}
              </span>
            ) : null}
          </div>
        ))
      )}
    </div>
  );
}

function leagueFor(rating: number): { name: string; icon: string; next: number } {
  if (rating >= 2600) return { name: "Legend League", icon: "💎", next: 100 };
  if (rating >= 2300) return { name: "Champion League", icon: "🏆", next: 2600 };
  if (rating >= 2000) return { name: "Elite League", icon: "🔥", next: 2300 };
  if (rating >= 1700) return { name: "Crystal League", icon: "🔷", next: 2000 };
  if (rating >= 1400) return { name: "Silver League", icon: "⚔️", next: 1700 };
  if (rating >= 1100) return { name: "Bronze League", icon: "🥉", next: 1400 };
  if (rating >= 800) return { name: "Stone League", icon: "🪨", next: 1100 };
  return { name: "Wood League", icon: "🪵", next: 800 };
}

interface HomeDashboardProps {
  currentUser: PlatformUser;
  users: PlatformUser[];
  games: GameArchiveRecord[];
  puzzles: PuzzleItem[];
  challenges: ChallengeRecord[];
  isOnline: boolean;
  forceOffline: boolean;
  snapshotSavedAt: number | null;
  puzzlePackCount: number;
  puzzlePackSavedAt: number | null;
  offlineGamesCount: number;
  unsyncedCount: number;
  canInstall: boolean;
  onGoTab: (tab: AppTab) => void;
  onQuickPlay: (tc: string) => void;
  onPlayBot: (rating: number) => void;
  onOpenGame: (game: GameArchiveRecord) => void;
  onDownloadOfflinePack: () => void;
  onToggleForceOffline: (v: boolean) => void;
  onInstall: () => void;
}

export default function HomeDashboard({
  currentUser,
  users,
  games,
  puzzles,
  challenges,
  isOnline,
  forceOffline,
  snapshotSavedAt,
  puzzlePackCount,
  puzzlePackSavedAt,
  offlineGamesCount,
  unsyncedCount,
  canInstall,
  onGoTab,
  onQuickPlay,
  onPlayBot,
  onOpenGame,
  onDownloadOfflinePack,
  onToggleForceOffline,
  onInstall,
}: HomeDashboardProps) {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening";
  const league = leagueFor(currentUser.blitzRating);
  const leagueProgress =
    league.next === 100
      ? 100
      : Math.max(4, Math.min(96, Math.round(((currentUser.blitzRating % 300) / 300) * 100)));

  const dailyPuzzle = useMemo(() => {
    if (puzzles.length === 0) return null;
    const dayIndex = Math.floor(Date.now() / 86_400_000);
    return puzzles[dayIndex % puzzles.length];
  }, [puzzles]);

  const myGames = useMemo(
    () =>
      games
        .filter(
          (g) => g.whitePlayerId === currentUser.id || g.blackPlayerId === currentUser.id
        )
        .slice(0, 4),
    [games, currentUser.id]
  );
  const lastGame = myGames[0] || games[0];

  const topPlayers = useMemo(
    () => [...users].sort((a, b) => b.blitzRating - a.blitzRating).slice(0, 5),
    [users]
  );
  const onlineFriends = useMemo(
    () => users.filter((u) => u.id !== currentUser.id && u.isOnline).slice(0, 5),
    [users, currentUser.id]
  );

  const resultFor = (g: GameArchiveRecord) => {
    const isWhite = g.whitePlayerId === currentUser.id;
    if (g.result === "1/2-1/2") return { label: "You Drew", cls: "text-stone-300 bg-stone-500/20 border-stone-500/40" };
    if ((isWhite && g.result === "1-0") || (!isWhite && g.result === "0-1"))
      return { label: "You Won", cls: "text-[#BCE08A] bg-[#81B64C]/20 border-[#81B64C]/50" };
    if (g.result === "*") return { label: "In progress", cls: "text-amber-300 bg-amber-500/15 border-amber-500/40" };
    return { label: "You Lost", cls: "text-rose-300 bg-rose-500/15 border-rose-500/40" };
  };

  return (
    <div className="space-y-4 pb-2">
      {/* ---------------- Greeting + ratings (Chess.com home style) ---------------- */}
      <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 md:p-5 shadow-xl">
        <div className="flex flex-wrap items-center gap-4">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[#EEEED2] to-[#C9C7A8] text-stone-900 flex items-center justify-center text-3xl font-bold shadow-inner">
            {currentUser.avatar}
          </div>
          <div className="min-w-0 flex-1">
            <h2 className="font-display text-xl md:text-2xl font-bold leading-tight">
              {greeting}, {currentUser.username} {currentUser.title ? <span className="text-amber-400 text-base align-middle">· {currentUser.title}</span> : null} 👋
            </h2>
            <p className="text-sm text-stone-400 mt-0.5 flex items-center gap-2 flex-wrap">
              <span className="inline-flex items-center gap-1 text-orange-400 font-semibold">
                <Flame className="w-4 h-4" /> {currentUser.streak}-day streak
              </span>
              <span>· {currentUser.gamesPlayed} games · {league.icon} {league.name}</span>
              <span className={`inline-flex items-center gap-1 font-mono text-[11px] px-2 py-0.5 rounded-full border ${isOnline ? "bg-[#81B64C]/15 border-[#81B64C]/50 text-[#BCE08A]" : "bg-amber-500/15 border-amber-500/50 text-amber-300"}`}>
                {isOnline ? <Wifi className="w-3 h-3" /> : <WifiOff className="w-3 h-3" />}
                {isOnline ? "ONLINE" : forceOffline ? "OFFLINE MODE (test)" : "OFFLINE"}
              </span>
            </p>
            <div className="mt-2.5 max-w-md">
              <div className="flex justify-between text-[10px] font-mono text-stone-500">
                <span>{league.name} progress</span>
                <span>{league.next === 100 ? "Max league" : `${currentUser.blitzRating} / ${league.next}`}</span>
              </div>
              <div className="h-2 rounded-full bg-[#201D1B] mt-1 overflow-hidden">
                <div className="h-full rounded-full bg-gradient-to-r from-[#81B64C] to-[#BCE08A] transition-all" style={{ width: `${leagueProgress}%` }} />
              </div>
            </div>
          </div>

          <div className="grid grid-cols-4 gap-2 text-center shrink-0">
            {[
              { icon: "🚀", label: "Bullet", v: currentUser.bulletRating },
              { icon: "⚡", label: "Blitz", v: currentUser.blitzRating },
              { icon: "⏱️", label: "Rapid", v: currentUser.rapidRating },
              { icon: "🧩", label: "Puzzles", v: currentUser.puzzleRating },
            ].map((r) => (
              <div key={r.label} className="px-3 py-2 rounded-2xl bg-[#201D1B] border border-[#3A3733] min-w-[74px]">
                <div className="text-sm">{r.icon}</div>
                <div className="font-mono font-extrabold text-[#E9E7DF] leading-tight">{r.v}</div>
                <div className="text-[9px] font-mono uppercase text-stone-500">{r.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 xl:grid-cols-[1fr_380px] gap-4 items-start">
        <div className="space-y-4 min-w-0">
          {/* ---------------- Quick pairing (Lichess style) ---------------- */}
          <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 md:p-5 shadow-xl">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h3 className="font-display font-bold text-lg flex items-center gap-2">
                <Swords className="w-5 h-5 text-[#BCE08A]" /> Quick Pairing
              </h3>
              <span className="text-xs font-mono text-stone-400">
                {isOnline
                  ? `${users.length * 1214 + 9137} players · instant Glicko-2 match`
                  : "Offline — you'll be paired with the computer"}
              </span>
            </div>

            <div className="grid grid-cols-3 gap-2 mt-3">
              {QUICK_PAIRING.map((q) => (
                <button
                  key={q.id}
                  onClick={() => onQuickPlay(q.id)}
                  className="py-3.5 rounded-2xl bg-[#35312C] hover:bg-[#81B64C] border border-[#4A463F] hover:border-[#81B64C] text-stone-100 hover:text-white transition-all group active:scale-[0.98]"
                >
                  <div className="font-display text-xl md:text-2xl font-bold leading-none">{q.big}</div>
                  <div className="text-[11px] text-stone-400 group-hover:text-white/90 mt-1">{q.cat}</div>
                </button>
              ))}
            </div>

            <button
              onClick={() => onQuickPlay("3+2")}
              className="w-full mt-3 py-4 rounded-2xl bg-[#81B64C] hover:bg-[#95C75F] text-white font-display font-bold text-lg shadow-[0_6px_0_#457A26] active:translate-y-1 active:shadow-[0_2px_0_#457A26] transition-all flex items-center justify-center gap-2"
            >
              <Play className="w-6 h-6 fill-white" /> {isOnline ? "New 3+2 Game" : "Play vs Computer"}
            </button>
            <div className="grid grid-cols-2 gap-2 mt-2">
              <button
                onClick={() => onGoTab("computer")}
                className="py-2.5 rounded-xl bg-[#35312C] border border-[#4A463F] text-sm font-semibold flex items-center justify-center gap-2 hover:border-stone-400"
              >
                <Bot className="w-4 h-4 text-[#BCE08A]" /> Play with the Computer
              </button>
              <button
                onClick={() => onGoTab("community")}
                className="py-2.5 rounded-xl bg-[#35312C] border border-[#4A463F] text-sm font-semibold flex items-center justify-center gap-2 hover:border-stone-400"
              >
                <Users className="w-4 h-4 text-amber-400" /> Play a Friend
                {challenges.length > 0 && (
                  <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-stone-950 font-mono text-[10px] font-extrabold">
                    {challenges.length}
                  </span>
                )}
              </button>
            </div>
          </section>

          {/* ---------------- Hero cards (Chess.com style) ---------------- */}
          <section className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => onGoTab("puzzles")}
              className="text-left p-4 rounded-3xl bg-gradient-to-br from-[#4A3B14] to-[#2B2825] border border-amber-500/40 hover:border-amber-400 transition-all group"
            >
              <PuzzleIcon className="w-7 h-7 text-amber-400" />
              <div className="font-display font-bold mt-2">Daily Puzzle</div>
              <p className="text-xs text-stone-400 mt-0.5 line-clamp-2">
                {dailyPuzzle ? `${dailyPuzzle.title} · rated ${dailyPuzzle.rating}` : "A fresh tactic every day"}
              </p>
              <span className="inline-flex items-center gap-1 text-amber-300 text-xs font-bold mt-2">
                Solve now <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </span>
              <span className="block text-[10px] font-mono text-stone-500 mt-1">Works offline with your puzzle pack</span>
            </button>

            <button
              onClick={() => onGoTab("puzzles")}
              className="text-left p-4 rounded-3xl bg-gradient-to-br from-[#5A2413] to-[#2B2825] border border-orange-500/40 hover:border-orange-400 transition-all group"
            >
              <Flame className="w-7 h-7 text-orange-400" />
              <div className="font-display font-bold mt-2">Puzzle Rush</div>
              <p className="text-xs text-stone-400 mt-0.5">
                How many in 3 minutes? Best: 🔥 {currentUser.puzzleRushBest}
              </p>
              <span className="inline-flex items-center gap-1 text-orange-300 text-xs font-bold mt-2">
                Start rush <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </span>
              <span className="block text-[10px] font-mono text-stone-500 mt-1">3-min · 5-min · Survival</span>
            </button>

            <button
              onClick={() => (lastGame ? onOpenGame(lastGame) : onGoTab("analysis"))}
              className="text-left p-4 rounded-3xl bg-gradient-to-br from-[#173A2E] to-[#2B2825] border border-[#81B64C]/50 hover:border-[#BCE08A] transition-all group"
            >
              <Search className="w-7 h-7 text-[#BCE08A]" />
              <div className="font-display font-bold mt-2">Game Review</div>
              <p className="text-xs text-stone-400 mt-0.5 line-clamp-2">
                {lastGame
                  ? `${lastGame.whitePlayer.username} vs ${lastGame.blackPlayer.username}`
                  : "Analyse any game move by move"}
              </p>
              <span className="inline-flex items-center gap-1 text-[#BCE08A] text-xs font-bold mt-2">
                Review <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
              </span>
              <span className="block text-[10px] font-mono text-stone-500 mt-1">Engine runs on-device — offline OK</span>
            </button>
          </section>

          {/* ---------------- Play a coach (bot personalities) ---------------- */}
          <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 md:p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-amber-400" /> Play a Coach
              </h3>
              <span className="text-[11px] font-mono text-stone-500">8 levels · hints & takebacks · offline</span>
            </div>
            <div className="flex gap-2 mt-3 overflow-x-auto pb-1 -mx-1 px-1">
              {COACH_BOTS.map((b) => (
                <button
                  key={b.id}
                  onClick={() => onPlayBot(b.rating)}
                  className="shrink-0 w-[104px] p-3 rounded-2xl bg-[#201D1B] border border-[#3A3733] hover:border-[#81B64C] text-center transition-all active:scale-[0.97]"
                >
                  <div className="text-3xl">{b.avatar}</div>
                  <div className="text-xs font-bold mt-1 truncate">{b.name}</div>
                  <div className="text-[10px] text-stone-400">{b.title}</div>
                  <div className="font-mono text-xs font-bold text-[#BCE08A] mt-0.5">{b.rating}</div>
                </button>
              ))}
            </div>
          </section>

          {/* ---------------- Recent games with mini boards ---------------- */}
          <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 md:p-5 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold flex items-center gap-2">
                <Clock3 className="w-5 h-5 text-[#BCE08A]" /> Recent Games
              </h3>
              <button onClick={() => onGoTab("analysis")} className="text-xs font-bold text-[#BCE08A] flex items-center gap-1">
                Game archive <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            {myGames.length === 0 ? (
              <div className="py-8 text-center">
                <div className="text-4xl">♟️</div>
                <p className="text-sm text-stone-400 mt-2">No games yet — your finished games will appear here with engine reviews.</p>
                <button onClick={() => onQuickPlay("3+2")} className="mt-3 px-4 py-2 rounded-xl bg-[#81B64C] text-white text-xs font-bold shadow-[0_4px_0_#457A26]">
                  Play your first game
                </button>
              </div>
            ) : (
              <div className="space-y-2 mt-3">
                {myGames.map((g) => {
                  const res = resultFor(g);
                  const opp = g.whitePlayerId === currentUser.id ? g.blackPlayer : g.whitePlayer;
                  return (
                    <button
                      key={g.id}
                      onClick={() => onOpenGame(g)}
                      className="w-full flex items-center gap-3 p-2.5 rounded-2xl bg-[#201D1B] border border-[#3A3733] hover:border-[#81B64C]/70 text-left transition-all"
                    >
                      <MiniBoard fen={g.fen} />
                      <span className="min-w-0 flex-1">
                        <span className="flex items-center gap-2 flex-wrap">
                          <span className="font-bold text-sm truncate">
                            {opp.title ? `${opp.title} ` : ""}{opp.username}
                          </span>
                          <span className={`px-1.5 py-0.5 rounded-full border text-[10px] font-bold ${res.cls}`}>{res.label}</span>
                        </span>
                        <span className="block text-xs text-stone-400 truncate mt-0.5">
                          {g.timeControl} · {g.openingName}
                        </span>
                        <span className="block text-[11px] font-mono text-stone-500">
                          Accuracy {g.whiteAccuracy ?? "—"}% / {g.blackAccuracy ?? "—"}% · {g.result}
                        </span>
                      </span>
                      <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#81B64C]/15 border border-[#81B64C]/40 text-[#BCE08A] text-[11px] font-bold shrink-0">
                        <Search className="w-3 h-3" /> Review
                      </span>
                    </button>
                  );
                })}
              </div>
            )}
            {offlineGamesCount > 0 && (
              <p className="text-[11px] font-mono text-stone-500 mt-2 flex items-center gap-1.5">
                <CloudUpload className="w-3.5 h-3.5" />
                {offlineGamesCount} offline game(s) saved on this device
                {unsyncedCount > 0 ? ` · ${unsyncedCount} waiting to sync` : " · all synced ✓"}
              </p>
            )}
          </section>
        </div>

        {/* ---------------- Right rail ---------------- */}
        <div className="space-y-4">
          {/* Offline ready card */}
          <section className={`rounded-3xl border p-4 shadow-xl ${isOnline ? "bg-[#2B2825] border-[#3A3733]" : "bg-[#3A2E12] border-amber-500/60"}`}>
            <h3 className="font-display font-bold flex items-center gap-2">
              {isOnline ? <Wifi className="w-5 h-5 text-[#BCE08A]" /> : <WifiOff className="w-5 h-5 text-amber-400" />}
              {isOnline ? "Ready for offline" : "You're offline — keep playing!"}
            </h3>
            <p className="text-xs text-stone-400 mt-1 leading-relaxed">
              {isOnline
                ? "Download once, then the app, computer games, puzzles and analysis keep working with no connection — just like Lichess & Chess.com on mobile."
                : "No connection needed for the features below. Anything you finish syncs automatically when you're back."}
            </p>

            <div className="mt-3 space-y-1">
              {OFFLINE_CAPABILITIES.offline.map((f) => (
                <div key={f} className="flex items-start gap-2 text-xs text-stone-200">
                  <Check className="w-3.5 h-3.5 text-[#BCE08A] mt-0.5 shrink-0" /> {f}
                </div>
              ))}
              {OFFLINE_CAPABILITIES.onlineOnly.map((f) => (
                <div key={f} className="flex items-start gap-2 text-xs text-stone-500">
                  <Lock className="w-3.5 h-3.5 mt-0.5 shrink-0" /> {f}
                  <span className="ml-auto font-mono text-[9px] uppercase">online</span>
                </div>
              ))}
            </div>

            <div className="mt-3 p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] font-mono text-[11px] text-stone-400 space-y-0.5">
              <div>🧩 Puzzle pack: <b className="text-stone-100">{puzzlePackCount} puzzles</b>{puzzlePackSavedAt ? ` · ${timeAgo(puzzlePackSavedAt)}` : " · not downloaded yet"}</div>
              <div>💾 Saved data: <b className="text-stone-100">{snapshotSavedAt ? timeAgo(snapshotSavedAt) : "—"}</b></div>
              <div>♟️ Offline games on device: <b className="text-stone-100">{offlineGamesCount}</b>{unsyncedCount > 0 ? ` (${unsyncedCount} to sync)` : ""}</div>
            </div>

            <div className="flex flex-col gap-2 mt-3">
              <button
                onClick={onDownloadOfflinePack}
                disabled={!isOnline}
                className="w-full py-2.5 rounded-xl bg-[#81B64C] hover:bg-[#95C75F] disabled:opacity-40 text-white text-sm font-bold shadow-[0_4px_0_#457A26] flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" /> {puzzlePackCount > 0 ? "Refresh offline pack" : "Download for offline"}
              </button>
              {canInstall && (
                <button
                  onClick={onInstall}
                  className="w-full py-2.5 rounded-xl bg-[#35312C] border border-[#4A463F] text-sm font-semibold flex items-center justify-center gap-2"
                >
                  <MonitorSmartphone className="w-4 h-4 text-[#BCE08A]" /> Install app (Add to Home Screen)
                </button>
              )}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] cursor-pointer">
                <span className="text-xs">✈️ Test offline mode <span className="text-stone-500">(simulates no internet)</span></span>
                <input
                  type="checkbox"
                  checked={forceOffline}
                  onChange={(e) => onToggleForceOffline(e.target.checked)}
                  className="accent-[#81B64C] w-4 h-4"
                />
              </label>
            </div>
          </section>

          {/* Friends online */}
          <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 shadow-xl">
            <h3 className="font-display font-bold flex items-center gap-2">
              <Users className="w-5 h-5 text-amber-400" /> Friends & Masters Online
            </h3>
            <div className="space-y-1.5 mt-3">
              {onlineFriends.map((u) => (
                <button
                  key={u.id}
                  onClick={() => onGoTab("community")}
                  className="w-full flex items-center gap-2.5 p-2 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-stone-500 text-left"
                >
                  <span className="relative w-9 h-9 rounded-lg bg-[#35312C] flex items-center justify-center shrink-0">
                    {u.avatar}
                    <span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border border-[#201D1B] ${isOnline ? "bg-[#81B64C]" : "bg-stone-600"}`} />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-xs font-bold truncate">{u.title ? `${u.title} ` : ""}{u.username}</span>
                    <span className="block text-[10px] font-mono text-stone-500">Blitz {u.blitzRating} · 🔥{u.streak}</span>
                  </span>
                  <span className="text-[10px] font-bold text-[#BCE08A] shrink-0">{isOnline ? "Challenge" : "Cached"}</span>
                </button>
              ))}
            </div>
          </section>

          {/* Leaderboard mini */}
          <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h3 className="font-display font-bold flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-400" /> Top Blitz
              </h3>
              <button onClick={() => onGoTab("community")} className="text-xs font-bold text-[#BCE08A]">All standings</button>
            </div>
            <div className="space-y-1 mt-3">
              {topPlayers.map((u, i) => (
                <div
                  key={u.id}
                  className={`flex items-center gap-2.5 p-2 rounded-xl border ${u.id === currentUser.id ? "bg-[#81B64C]/10 border-[#81B64C]/50" : "bg-[#201D1B] border-[#3A3733]"}`}
                >
                  <span className={`w-6 text-center font-mono text-xs font-extrabold ${i === 0 ? "text-amber-400" : i === 1 ? "text-stone-300" : i === 2 ? "text-amber-600" : "text-stone-500"}`}>
                    {i + 1}
                  </span>
                  <span className="text-lg">{u.avatar}</span>
                  <span className="text-xs font-semibold truncate flex-1">{u.title ? `${u.title} ` : ""}{u.username}</span>
                  <span className="font-mono text-xs font-extrabold text-[#BCE08A]">{u.blitzRating}</span>
                </div>
              ))}
            </div>
            {!isOnline && (
              <p className="text-[10px] font-mono text-stone-500 mt-2">Showing last saved standings · syncs when online</p>
            )}
          </section>

          {/* Arenas */}
          <section className="rounded-3xl bg-[#2B2825] border border-[#3A3733] p-4 shadow-xl">
            <h3 className="font-display font-bold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-[#BCE08A]" /> Arena Tournaments
            </h3>
            <div className="space-y-2 mt-3">
              {[
                { icon: "🛡️", name: "Hourly Blitz Arena", info: "3+2 Rated · 57 min", players: 842 },
                { icon: "🐆", name: "Lagos Rapid Arena", info: "10+0 Rated · 2h", players: 318 },
                { icon: "🚀", name: "Bullet Frenzy", info: "1+0 Rated · 27 min", players: 1204 },
              ].map((a) => (
                <button
                  key={a.name}
                  onClick={() => (isOnline ? onGoTab("community") : onGoTab("computer"))}
                  className="w-full flex items-center gap-3 p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-stone-500 text-left"
                >
                  <span className="text-2xl">{a.icon}</span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-xs font-bold truncate">{a.name}</span>
                    <span className="block text-[10px] font-mono text-stone-500">{a.info}</span>
                  </span>
                  <span className="text-[10px] font-mono text-stone-400 shrink-0">👥 {isOnline ? a.players : "—"}</span>
                </button>
              ))}
            </div>
            {!isOnline && (
              <p className="text-[10px] font-mono text-amber-400 mt-2 flex items-center gap-1">
                <Lock className="w-3 h-3" /> Arenas need a connection — tap to play the computer instead.
              </p>
            )}
          </section>
        </div>
      </div>
    </div>
  );
}
