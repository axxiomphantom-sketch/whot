import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Warm charcoal system (professional chess-app palette)
        obsidian: {
          950: "#201D1B",
          900: "#2B2825",
          800: "#35312C",
          700: "#3A3733",
          600: "#4A463F",
        },
        // Tournament green — remaps every existing `emerald-*` class
        emerald: {
          50: "#F3F8EC",
          100: "#E2F0D2",
          200: "#C8E3AC",
          300: "#BCE08A",
          400: "#95C75F",
          500: "#81B64C",
          600: "#639237",
          700: "#4E742D",
          800: "#3F5C27",
          900: "#354E23",
          950: "#1B2A10",
        },
        amber: {
          400: "#FBBF24",
          500: "#F59E0B",
        },
        board: {
          light: "#EEEED2",
          dark: "#769656",
        },
      },
      fontFamily: {
        sans: ["Plus Jakarta Sans", "Inter", "system-ui", "sans-serif"],
        display: ["Space Grotesk", "Inter", "system-ui", "sans-serif"],
        mono: ["JetBrains Mono", "Fira Code", "monospace"],
      },
      boxShadow: {
        btn3d: "0 5px 0 #457A26",
        card: "0 10px 30px rgba(0,0,0,0.35)",
      },
    },
  },
  plugins: [],
};
export default config;
