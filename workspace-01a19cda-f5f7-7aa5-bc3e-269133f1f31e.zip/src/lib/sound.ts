"use client";

export type SoundEffectType =
  | "move"
  | "capture"
  | "check"
  | "castle"
  | "promote"
  | "game_start"
  | "game_end"
  | "low_time"
  | "illegal";

class ChessSoundEngine {
  private ctx: AudioContext | null = null;
  public enabled = true;

  private getContext(): AudioContext | null {
    if (typeof window === "undefined") return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === "suspended") {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public play(type: SoundEffectType) {
    if (!this.enabled) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;

    switch (type) {
      case "move": {
        // Tactile wooden piece placement thud
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "triangle";
        osc.frequency.setValueAtTime(165, now);
        osc.frequency.exponentialRampToValueAtTime(65, now + 0.065);
        gain.gain.setValueAtTime(0.28, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.075);
        break;
      }
      case "capture": {
        // Crisp snap + deeper bass thud
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(240, now);
        osc.frequency.exponentialRampToValueAtTime(52, now + 0.09);
        gain.gain.setValueAtTime(0.32, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.095);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.1);
        break;
      }
      case "check": {
        // High metallic resonance alert
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = "sine";
        osc.frequency.setValueAtTime(587.33, now); // D5
        osc.frequency.setValueAtTime(880, now + 0.06); // A5
        gain.gain.setValueAtTime(0.24, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now);
        osc.stop(now + 0.26);
        break;
      }
      case "castle": {
        // Double wooden tap (King + Rook)
        this.playTone(ctx, 160, 65, now, 0.06, 0.24);
        this.playTone(ctx, 185, 75, now + 0.075, 0.06, 0.24);
        break;
      }
      case "promote": {
        // Ascending emerald arpeggio
        this.playTone(ctx, 440, 440, now, 0.08, 0.2);
        this.playTone(ctx, 554.37, 554.37, now + 0.07, 0.08, 0.2);
        this.playTone(ctx, 659.25, 659.25, now + 0.14, 0.14, 0.25);
        break;
      }
      case "game_start": {
        this.playTone(ctx, 330, 440, now, 0.12, 0.2);
        this.playTone(ctx, 440, 659.25, now + 0.1, 0.18, 0.22);
        break;
      }
      case "game_end": {
        this.playTone(ctx, 523.25, 523.25, now, 0.12, 0.22);
        this.playTone(ctx, 659.25, 659.25, now + 0.11, 0.12, 0.22);
        this.playTone(ctx, 783.99, 783.99, now + 0.22, 0.28, 0.26);
        break;
      }
      case "low_time": {
        this.playTone(ctx, 740, 740, now, 0.05, 0.18);
        break;
      }
      case "illegal": {
        this.playTone(ctx, 130, 95, now, 0.12, 0.25);
        break;
      }
    }
  }

  private playTone(
    ctx: AudioContext,
    startFreq: number,
    endFreq: number,
    startTime: number,
    duration: number,
    volume: number
  ) {
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "triangle";
    osc.frequency.setValueAtTime(startFreq, startTime);
    osc.frequency.exponentialRampToValueAtTime(endFreq, startTime + duration);
    gain.gain.setValueAtTime(volume, startTime);
    gain.gain.exponentialRampToValueAtTime(0.001, startTime + duration);
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(startTime);
    osc.stop(startTime + duration + 0.01);
  }
}

export const soundEngine = new ChessSoundEngine();
