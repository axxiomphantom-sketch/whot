import { NextRequest, NextResponse } from "next/server";
import { Chess } from "chess.js";
import { prisma } from "@/lib/prisma";
import { calculateGlicko2Update } from "@/lib/glicko2";

export async function GET(req: NextRequest) {
  const theme = req.nextUrl.searchParams.get("theme");
  const puzzles = await prisma.puzzle.findMany({
    where:
      theme && theme !== "All"
        ? {
            themes: {
              contains: theme,
            },
          }
        : undefined,
    orderBy: { rating: "asc" },
  });
  return NextResponse.json({ puzzles });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === "attempt") {
      const { userId = "user-ademola", puzzleId, solved, timeTakenMs = 8000 } = body;
      const [user, puzzle] = await Promise.all([
        prisma.user.findUnique({ where: { id: userId } }),
        prisma.puzzle.findUnique({ where: { id: puzzleId } }),
      ]);

      if (!user || !puzzle) {
        return NextResponse.json(
          { error: "User or Puzzle not found" },
          { status: 404 }
        );
      }

      const glickoResult = calculateGlicko2Update(
        { rating: user.puzzleRating, rd: user.puzzleRd, vol: 0.06 },
        { rating: puzzle.rating, rd: puzzle.rd || 65.0, vol: 0.06 },
        solved ? 1 : 0
      );

      const [updatedUser] = await Promise.all([
        prisma.user.update({
          where: { id: user.id },
          data: {
            puzzleRating: glickoResult.rating,
            puzzleRd: glickoResult.rd,
          },
        }),
        prisma.puzzle.update({
          where: { id: puzzle.id },
          data: {
            plays: { increment: 1 },
          },
        }),
        prisma.puzzleAttempt.create({
          data: {
            userId: user.id,
            puzzleId: puzzle.id,
            solved: Boolean(solved),
            timeTakenMs,
            ratingDelta: glickoResult.delta,
          },
        }),
        prisma.ratingHistory.create({
          data: {
            userId: user.id,
            category: "puzzle",
            rating: glickoResult.rating,
            rd: glickoResult.rd,
          },
        }),
      ]);

      return NextResponse.json({
        user: updatedUser,
        ratingChange: glickoResult,
      });
    }

    if (action === "rush_score") {
      const { userId = "user-ademola", score } = body;
      const user = await prisma.user.findUnique({ where: { id: userId } });
      if (!user) {
        return NextResponse.json({ error: "User not found" }, { status: 404 });
      }
      const newBest = Math.max(user.puzzleRushBest, Number(score) || 0);
      const updated = await prisma.user.update({
        where: { id: userId },
        data: { puzzleRushBest: newBest },
      });
      return NextResponse.json({ user: updated, newBest });
    }

    if (action === "create") {
      const {
        title,
        fen,
        moves,
        rating = 1600,
        themes = "Tactics,Mating Net",
        description = "Custom tactical puzzle.",
      } = body;

      if (!title || !fen || !moves) {
        return NextResponse.json(
          { error: "Title, FEN, and solution moves are required." },
          { status: 400 }
        );
      }

      // Validate FEN and move sequence with chess.js
      let testChess: Chess;
      try {
        testChess = new Chess(fen.trim());
      } catch {
        return NextResponse.json(
          { error: "Invalid FEN position string." },
          { status: 400 }
        );
      }

      const tokens = moves
        .trim()
        .split(/\s+/)
        .filter((t: string) => t && !/^\d+\./.test(t));

      if (tokens.length === 0) {
        return NextResponse.json(
          { error: "Provide at least one legal solution move." },
          { status: 400 }
        );
      }

      const normalizedSanMoves: string[] = [];
      for (const token of tokens) {
        try {
          const m = testChess.move(token);
          if (!m) {
            return NextResponse.json(
              { error: `Move "${token}" is illegal in the given position.` },
              { status: 400 }
            );
          }
          normalizedSanMoves.push(m.san);
        } catch {
          return NextResponse.json(
            { error: `Move "${token}" is illegal in the given position.` },
            { status: 400 }
          );
        }
      }

      const created = await prisma.puzzle.create({
        data: {
          title: title.trim(),
          fen: fen.trim(),
          moves: normalizedSanMoves.join(" "),
          rating: Number(rating) || 1600,
          themes: themes.trim(),
          description: description.trim(),
          popularity: 100,
          plays: 1,
        },
      });

      return NextResponse.json({ puzzle: created });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: unknown) {
    console.error("Puzzles API error:", err);
    return NextResponse.json(
      { error: "Puzzle operation failed" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const puzzleId = req.nextUrl.searchParams.get("puzzleId");
    if (!puzzleId) {
      return NextResponse.json({ error: "Missing puzzleId" }, { status: 400 });
    }
    await prisma.puzzle.delete({ where: { id: puzzleId } });
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error("Delete puzzle error:", err);
    return NextResponse.json(
      { error: "Failed to delete puzzle" },
      { status: 500 }
    );
  }
}
