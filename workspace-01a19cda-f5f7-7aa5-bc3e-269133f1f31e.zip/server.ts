import { createServer } from "http";
import { parse } from "url";
import next from "next";
import { Server as SocketIOServer } from "socket.io";
import { redisStore } from "./src/lib/redisStore";
import {
  createLiveGameSession,
  processMoveInGame,
  finalizeGameSession,
  triggerBotReplyIfNeeded,
} from "./src/lib/gameManager";
import { moderateChatMessage } from "./src/lib/moderation";
import { prisma } from "./src/lib/prisma";

const dev = process.env.NODE_ENV !== "production";
const hostname = "0.0.0.0";
const port = parseInt(process.env.PORT || "3000", 10);

const app = next({ dev, hostname, port });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  const httpServer = createServer((req, res) => {
    const parsedUrl = parse(req.url!, true);
    handle(req, res, parsedUrl);
  });

  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
    path: "/socket.io",
  });

  // Expose io globally so API routes can also broadcast if needed
  (globalThis as unknown as { io: SocketIOServer }).io = io;

  io.on("connection", (socket) => {
    redisStore.logEvent("IN", "socket:connect", { socketId: socket.id });

    // 1. game:join
    socket.on("game:join", async (payload: { gameId: string; userId?: string }) => {
      redisStore.logEvent("IN", "game:join", payload);
      const { gameId } = payload;
      socket.join(`game:${gameId}`);

      const state = redisStore.liveGames.get(gameId);
      if (state) {
        socket.emit("game:state_sync", state);
        redisStore.logEvent("OUT", "game:state_sync", {
          gameId: state.id,
          fen: state.fen,
          turn: state.turn,
        });
      }
    });

    // 2. game:move
    socket.on(
      "game:move",
      async (payload: {
        gameId: string;
        from: string;
        to: string;
        promotion?: string;
      }) => {
        redisStore.logEvent("IN", "game:move", payload);
        const res = await processMoveInGame(payload.gameId, {
          from: payload.from,
          to: payload.to,
          promotion: payload.promotion,
        });

        if (!res.success || !res.gameState) {
          socket.emit("game:error", { message: res.error || "Illegal move" });
          return;
        }

        io.to(`game:${payload.gameId}`).emit("game:state_sync", res.gameState);
        redisStore.logEvent("OUT", "game:state_sync", {
          gameId: res.gameState.id,
          san: res.moveMade?.san,
          fen: res.gameState.fen,
        });

        // If game is still active, check if opponent is AI or has a queued premove
        const activeState = res.gameState;
        if (activeState.status === "active") {
          const nextTurn = activeState.turn;
          const queuedPremove =
            nextTurn === "w"
              ? activeState.whitePremove
              : activeState.blackPremove;

          if (queuedPremove) {
            setTimeout(async () => {
              const preRes = await processMoveInGame(
                payload.gameId,
                queuedPremove
              );
              if (preRes.success && preRes.gameState) {
                io.to(`game:${payload.gameId}`).emit(
                  "game:state_sync",
                  preRes.gameState
                );
              }
            }, 90);
          } else {
            const nextPlayer =
              nextTurn === "w"
                ? activeState.whitePlayer
                : activeState.blackPlayer;
            if (nextPlayer.isAi) {
              setTimeout(async () => {
                const botUpdated = await triggerBotReplyIfNeeded(payload.gameId);
                if (botUpdated) {
                  io.to(`game:${payload.gameId}`).emit(
                    "game:state_sync",
                    botUpdated
                  );
                  redisStore.logEvent("OUT", "game:state_sync (bot)", {
                    gameId: botUpdated.id,
                    fen: botUpdated.fen,
                  });

                  // If human queued a premove while bot was thinking, execute it!
                  if (botUpdated.status === "active") {
                    const humanPremove =
                      botUpdated.turn === "w"
                        ? botUpdated.whitePremove
                        : botUpdated.blackPremove;
                    if (humanPremove) {
                      const pRes = await processMoveInGame(
                        payload.gameId,
                        humanPremove
                      );
                      if (pRes.success && pRes.gameState) {
                        io.to(`game:${payload.gameId}`).emit(
                          "game:state_sync",
                          pRes.gameState
                        );
                        // And trigger bot reply again if still active
                        setTimeout(async () => {
                          const botAfterPre = await triggerBotReplyIfNeeded(
                            payload.gameId
                          );
                          if (botAfterPre) {
                            io.to(`game:${payload.gameId}`).emit(
                              "game:state_sync",
                              botAfterPre
                            );
                          }
                        }, 360);
                      }
                    }
                  }
                }
              }, 380);
            }
          }
        }
      }
    );

    // 3. game:premove
    socket.on(
      "game:premove",
      (payload: {
        gameId: string;
        color: "w" | "b";
        premove: { from: string; to: string; promotion?: string } | null;
      }) => {
        redisStore.logEvent("IN", "game:premove", payload);
        const state = redisStore.liveGames.get(payload.gameId);
        if (!state) return;
        if (payload.color === "w") {
          state.whitePremove = payload.premove;
        } else {
          state.blackPremove = payload.premove;
        }
        io.to(`game:${payload.gameId}`).emit("game:state_sync", state);
      }
    );

    // 4. game:resign
    socket.on(
      "game:resign",
      async (payload: { gameId: string; color: "w" | "b" }) => {
        redisStore.logEvent("IN", "game:resign", payload);
        const state = redisStore.liveGames.get(payload.gameId);
        if (!state || state.status !== "active") return;
        const result = payload.color === "w" ? "0-1" : "1-0";
        const updated = await finalizeGameSession(state, result, "resignation");
        io.to(`game:${payload.gameId}`).emit("game:state_sync", updated);
        redisStore.logEvent("OUT", "game:state_sync (resign)", {
          gameId: updated.id,
          result: updated.result,
        });
      }
    );

    // 5. game:draw_offer
    socket.on(
      "game:draw_offer",
      async (payload: {
        gameId: string;
        color: "w" | "b";
        action: "offer" | "accept" | "decline";
      }) => {
        redisStore.logEvent("IN", "game:draw_offer", payload);
        const state = redisStore.liveGames.get(payload.gameId);
        if (!state || state.status !== "active") return;

        if (payload.action === "offer") {
          state.drawOfferedBy = payload.color;
          // If opponent is AI and position eval is close to equal (-90 to +90 cp) after ply 12, AI accepts draw!
          const opponent =
            payload.color === "w" ? state.blackPlayer : state.whitePlayer;
          if (opponent.isAi && state.moveHistory.length >= 10) {
            const lastEval =
              state.moveHistory[state.moveHistory.length - 1]?.evalCp || 0;
            if (Math.abs(lastEval) < 110) {
              await finalizeGameSession(state, "1/2-1/2", "draw_agreement");
            }
          }
        } else if (payload.action === "accept") {
          await finalizeGameSession(state, "1/2-1/2", "draw_agreement");
        } else if (payload.action === "decline") {
          state.drawOfferedBy = null;
        }

        io.to(`game:${payload.gameId}`).emit("game:state_sync", state);
      }
    );

    // 6. chat:message
    socket.on(
      "chat:message",
      async (payload: {
        gameId: string;
        senderId: string;
        senderName: string;
        text: string;
      }) => {
        redisStore.logEvent("IN", "chat:message", payload);
        const mod = moderateChatMessage(payload.text);
        if (!mod.cleanText) return;

        let savedMsg;
        try {
          savedMsg = await prisma.chatMessage.create({
            data: {
              gameId: payload.gameId,
              senderId: payload.senderId,
              senderName: payload.senderName,
              text: mod.cleanText,
              flagged: mod.flagged,
              reactionsJson: "{}",
            },
          });
        } catch {
          savedMsg = {
            id: `msg-${Date.now()}`,
            gameId: payload.gameId,
            senderId: payload.senderId,
            senderName: payload.senderName,
            text: mod.cleanText,
            flagged: mod.flagged,
            reactionsJson: "{}",
            createdAt: new Date(),
          };
        }

        io.to(`game:${payload.gameId}`).emit("chat:message", savedMsg);
      }
    );

    // 7. matchmaking:join
    socket.on(
      "matchmaking:join",
      async (payload: {
        userId: string;
        timeControl: string;
        rated: boolean;
        opponentId?: string;
        colorPref?: "random" | "white" | "black";
      }) => {
        redisStore.logEvent("IN", "matchmaking:join", payload);
        try {
          const user = await prisma.user.findUnique({
            where: { id: payload.userId },
          });
          if (!user) return;

          let opponent;
          if (payload.opponentId) {
            opponent = await prisma.user.findUnique({
              where: { id: payload.opponentId },
            });
          }
          if (!opponent) {
            const candidates = await prisma.user.findMany({
              where: { id: { not: user.id } },
            });
            // Sort by closest blitzRating (Glicko-2 matchmaking)
            candidates.sort(
              (a, b) =>
                Math.abs(a.blitzRating - user.blitzRating) -
                Math.abs(b.blitzRating - user.blitzRating)
            );
            opponent = candidates[0];
          }

          if (!opponent) return;

          const playWhite =
            payload.colorPref === "white"
              ? true
              : payload.colorPref === "black"
              ? false
              : Math.random() >= 0.5;

          const liveSession = await createLiveGameSession({
            whiteUserId: playWhite ? user.id : opponent.id,
            blackUserId: playWhite ? opponent.id : user.id,
            timeControl: payload.timeControl || "3+2",
            rated: payload.rated ?? true,
          });

          socket.join(`game:${liveSession.id}`);
          socket.emit("matchmaking:matched", liveSession);
          redisStore.logEvent("OUT", "matchmaking:matched", {
            gameId: liveSession.id,
            white: liveSession.whitePlayer.username,
            black: liveSession.blackPlayer.username,
          });

          // If AI is White, make first move automatically
          if (liveSession.whitePlayer.isAi) {
            setTimeout(async () => {
              const botFirst = await triggerBotReplyIfNeeded(liveSession.id);
              if (botFirst) {
                io.to(`game:${liveSession.id}`).emit(
                  "game:state_sync",
                  botFirst
                );
              }
            }, 450);
          }
        } catch (err) {
          console.error("Matchmaking error:", err);
        }
      }
    );

    socket.on("disconnect", () => {
      redisStore.logEvent("IN", "socket:disconnect", { socketId: socket.id });
    });
  });

  httpServer.listen(port, hostname, () => {
    console.log(
      `> Obsidian Grandmaster Chess Server & WebSocket Engine listening on http://${hostname}:${port}`
    );
  });
});
