import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    if (action === "register") {
      const { username, email, title, country, avatar, bio } = body;
      if (!username || !email) {
        return NextResponse.json(
          { error: "Username and email are required." },
          { status: 400 }
        );
      }

      const existing = await prisma.user.findFirst({
        where: {
          OR: [{ username: username.trim() }, { email: email.trim() }],
        },
      });
      if (existing) {
        return NextResponse.json(
          { error: "Username or email already exists." },
          { status: 409 }
        );
      }

      const newUser = await prisma.user.create({
        data: {
          username: username.trim(),
          email: email.trim(),
          passwordHash: "hashed_user_pw",
          title: title || null,
          country: country || "NG",
          avatar: avatar || "♔",
          bio: bio || "Competitive tactician on Obsidian Grandmaster.",
          isAi: false,
          isOnline: true,
          bulletRating: 1500,
          blitzRating: 1500,
          rapidRating: 1500,
          puzzleRating: 1600,
        },
      });

      await prisma.ratingHistory.createMany({
        data: [
          { userId: newUser.id, category: "blitz", rating: 1500, rd: 110 },
          { userId: newUser.id, category: "rapid", rating: 1500, rd: 110 },
          { userId: newUser.id, category: "bullet", rating: 1500, rd: 110 },
          { userId: newUser.id, category: "puzzle", rating: 1600, rd: 90 },
        ],
      });

      return NextResponse.json({ user: newUser });
    }

    if (action === "update") {
      const { userId, username, title, country, avatar, bio } = body;
      if (!userId) {
        return NextResponse.json(
          { error: "User ID is required." },
          { status: 400 }
        );
      }

      const updated = await prisma.user.update({
        where: { id: userId },
        data: {
          username: username ? username.trim() : undefined,
          title: title === "" ? null : title,
          country: country || undefined,
          avatar: avatar || undefined,
          bio: bio !== undefined ? bio : undefined,
        },
      });

      return NextResponse.json({ user: updated });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: unknown) {
    console.error("Users API error:", err);
    return NextResponse.json(
      { error: "User operation failed" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get("userId");
    if (!userId || userId === "user-ademola") {
      return NextResponse.json(
        { error: "Cannot delete primary seeded grandmaster account." },
        { status: 400 }
      );
    }
    await prisma.user.delete({ where: { id: userId } });
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error("Delete user error:", err);
    return NextResponse.json(
      { error: "Failed to delete user" },
      { status: 500 }
    );
  }
}
