# ♔ ObsidianChess.io — Grandmaster Real-Time Chess Platform

A full-stack, dark-mode, real-time online chess platform inspired by Chess.com — built with
**Next.js 14 (React + TypeScript)**, **Tailwind CSS**, **Socket.io WebSockets**, **Chess.js**,
**Prisma ORM**, an authentic **Glicko-2** rating/matchmaking engine, and a **Stockfish-structured
Multi-PV analysis engine** (evaluation bar, best-move arrows, CAPS accuracy, and all 10 move
classifications).

## ▶️ Run it

```bash
npm install
npx prisma db push      # creates prisma/dev.db (SQLite dev database)
npm run db:seed         # seeds 8 players (incl. titled engine opponents), 5 games, 12 puzzles, challenges
npm run build           # production build
npm run start           # custom server.ts → Next.js + Socket.io on http://0.0.0.0:3000
# or: npm run dev       # dev mode (same custom server, HMR)
```

Sign in with any one-click demo account (recommended: **GM Ademola_GM**, Lagos 🇳🇬, Blitz 2418)
or create your own account (starts at 1500 Glicko-2, RD ±110).

## 🎨 v2 — Professional Home redesign + Offline mode (research-based)

The home experience was rebuilt from research into the professional apps:

- **Chess.com (mobile)**: always-visible bottom navigation (Home / Play / Puzzles / Lessons / More),
  a Home screen of *relevant shortcuts first* — per-time-control ratings, league standing,
  hero cards (Daily Puzzle, Puzzle Rush, Game Review), recent games with mini-board thumbnails,
  and a big docked green **New Game** button. Our v2 mirrors all of these, in the warm-charcoal +
  tournament-green (`#81B64C`, board `#EEEED2`/`#769656`) design language.
- **Lichess**: the **Quick Pairing** 3×3 time-control tile grid (1+0 … 15+10, Daily),
  "Play with the Computer" / "Play a Friend" as first-class actions, arena list, and —
  crucially — its offline model.
- **PWA best practice**: a service worker precaches the app shell (Cache-First for hashed
  assets, Network-First for read APIs), with a Web App Manifest so the site installs to the
  home screen and boots with no connection at all.

### 📴 What works offline — and what doesn't (by design)

| Works fully offline (on-device) | Online-only (gracefully locked offline) |
|---|---|
| Play vs Computer — 8 coach bots (400–2500), clocks, hints, takebacks, practice-mode feedback, autosave/resume | Live matchmaking vs real players |
| Downloaded puzzle pack + Puzzle Rush (results queue & sync later) | Rated Glicko-2 points & leaderboard sync |
| Engine analysis board, Game Review, opening explorer, PGN/FEN import | In-game chat & emoji reactions |
| Saved games, profile, cached leaderboards/friends | 1v1 challenges & friend requests |

Finished offline games and puzzle results **sync automatically** to your account when
connectivity returns. Try it: use the **Online/Offline pill** in the header (or ✈️ *Test
offline mode* on Home) to simulate an outage — or really go offline after tapping
**Download for offline** once. Install via the browser's "Add to Home Screen".

Key files: `src/components/HomeDashboard.tsx`, `src/components/OfflinePlay.tsx`,
`src/lib/offlineStore.ts`, `public/sw.js`, `src/app/manifest.ts`, `src/components/SwRegister.tsx`.

## ✨ Features

### Play & Matchmaking
- Time controls: Bullet (1+0, 1+1, 2+1), Blitz (3+0, 3+2, 5+0), Rapid (10+0, 15+10, 30+0),
  Daily, plus **custom minutes + increment**
- **Glicko-2 matchmaking** with expanding rating window, match-quality % and win expectancy
- Full rules via Chess.js: en passant, castling rights, promotion modal (Q/R/B/N),
  check/checkmate, stalemate, threefold repetition, 50-move rule, insufficient material
- Click-click **and** drag-and-drop moves, legal-move dots/capture rings, last-move highlight,
  king-in-check glow, **premoves** (queued on the opponent's turn, auto-executed),
  right-click arrows & square annotations
- Live clocks with increments & tenths under 20s, low-time beeps, captured-piece trays,
  material differential, Web-Audio sound effects (move/capture/check/castle/promote/…)
- Draw offers (titled bots accept near-equal positions), resignation, timeout, rematch,
  result banner with Glicko-2 rating deltas, disconnect/reconnect via Socket.io + REST sync

### Analysis & Game Review
- Free analysis board with **Multi-PV engine lines** (centipawn / mate scores, depth,
  principal variations), green/blue/red best-move arrows, vertical evaluation bar
- **Game Review**: CAPS-style White/Black accuracy %, evaluation graph (click to scrub),
  10-category classification table (**Brilliant !!, Great !, Best ★, Excellent, Good, Book 📖,
  Inaccuracy ?!, Mistake ?, Blunder ??, Miss ✕**), key-moments list and **"Retry mistake"** trainer
- **Opening Explorer**: ECO code/name, master-game candidate moves with White/Draw/Black
  win-rate bars and average Elo — click a move to play it
- **PGN/FEN import, export, copy & .pgn download**, keyboard scrubbing (←/→), board flip,
  save imported games to your persistent archive

### Puzzles
- 12 engine-validated tactical puzzles (forks, pins, skewers, back-rank, smothered mate,
  sacrifices, mating nets…), theme filters, hints (arrow), solution playback
- **Rated puzzles** update your Puzzle Glicko-2 rating vs the puzzle's rating
- **Puzzle Rush**: 3-min / 5-min / Survival, 3-strikes system, live score progression,
  persistent personal record
- Create/delete your own puzzles (FEN + SAN solution validated server-side by Chess.js)

### Social & Community
- Leaderboards (Bullet/Blitz/Rapid/Puzzles) with RD display and player search
- Player profiles: 4-category Glicko-2 matrix, rating-history chart, W/D/L breakdown,
  match archive with one-click engine review
- Friends add/remove, direct **1v1 challenges** (time control, rated, colour, custom FEN),
  accept → instant live game
- In-game chat with emoji quick-reactions, per-message reactions, titled-bot replies and a
  **fair-play moderation filter**

### Architecture tab
- Live WebSocket event-stream telemetry, interactive **Glicko-2 calculator sandbox**,
  copy-ready PostgreSQL/Prisma schema and TypeScript WebSocket event contracts

## 🗄️ Data model (Prisma)

`User` (Glicko-2 rating/RD/volatility per category), `Game` (PGN, FEN, result, termination,
accuracy, opening, eval & move-time histories, rating deltas), `Puzzle`, `PuzzleAttempt`,
`RatingHistory`, `Challenge`, `Friendship`, `ChatMessage`.
Dev uses SQLite (`prisma/dev.db`); **`prisma/schema.postgres.prisma`** is the production
PostgreSQL schema (UUID ids, JSONB ratings, array fields, indexes) — point
`POSTGRES_DATABASE_URL` at Postgres to deploy it.

## 🔌 WebSocket event contracts (Socket.io, `/socket.io`)

Client → Server: `game:join`, `game:move`, `game:premove`, `game:resign`,
`game:draw_offer`, `chat:message`, `matchmaking:join`
Server → Client: `game:state_sync`, `game:error`, `matchmaking:matched`, `chat:message`

Live game rooms, premoves, clocks and matchmaking queues are kept in a Redis-style session
store (`src/lib/redisStore.ts`, in-memory for this sandbox — swap the Map for a real Redis
client for multi-instance production). All REST mutations are also exposed under
`/api/games`, `/api/puzzles`, `/api/challenges`, `/api/chat`, `/api/users`, `/api/overview`,
so play stays in sync even if a socket drops.

## ♟️ Engine note

`src/lib/engine.ts` implements a self-contained Multi-PV alpha-beta engine with piece-square
tables, MVV-LVA move ordering and mate detection, emitting **Stockfish-compatible output**
(centipawns, mate-in-N, PVs, depth) on both client (analysis) and server (titled-bot replies,
calibrated to each opponent's rating). It is a drop-in seam: replace `analyzePosition()` with a
Stockfish 16+ WASM worker (`postMessage("go depth 18")`) without changing any UI code.
