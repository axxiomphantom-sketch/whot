import type { Metadata, Viewport } from "next";
import "./globals.css";
import SwRegister from "@/components/SwRegister";

export const metadata: Metadata = {
  title: "ObsidianChess.io — Play Chess Online & Offline",
  description:
    "Play live chess online or offline against the computer. Tactical puzzles, Puzzle Rush, Glicko-2 ratings, engine Game Review and opening explorer. Installable PWA.",
  applicationName: "ObsidianChess.io",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "ObsidianChess",
  },
  icons: {
    icon: "/icons/icon-192.png",
    apple: "/icons/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  themeColor: "#81B64C",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Space+Grotesk:wght@500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#201D1B] text-[#E9E7DF] antialiased">
        {children}
        <SwRegister />
      </body>
    </html>
  );
}
