"use client";

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { Chess, Square } from "chess.js";
import { io, Socket } from "socket.io-client";
import {
  Crown,
  Home,
  Play,
  Bot,
  Wifi,
  WifiOff,
  BarChart3,
  Puzzle as PuzzleIcon,
  Users,
  Cpu,
  Trophy,
  Zap,
  Timer,
  CalendarDays,
  Swords,
  Flag,
  Handshake,
  RefreshCw,
  FlipVertical2,
  Volume2,
  VolumeX,
  Send,
  Copy,
  Download,
  ChevronFirst,
  ChevronLast,
  ChevronLeft,
  ChevronRight,
  X,
  Check,
  Sparkles,
  Loader2,
  LogIn,
  UserRound,
  Search,
  Settings2,
  BookOpen,
} from "lucide-react";

import {
  ChessboardArena,
  BoardThemeKey,
  BOARD_THEMES,
  BoardArrow,
} from "@/components/ChessboardArena";
import { PlayerHudBar } from "@/components/PlayerHudBar";
import { OpeningExplorerPanel } from "@/components/OpeningExplorerPanel";
import { EvalGraphAndReview } from "@/components/EvalGraphAndReview";
import { PuzzlesWorkspace, PuzzleItem } from "@/components/PuzzlesWorkspace";
import {
  CommunityWorkspace,
  PlatformUser,
  ChallengeRecord,
  GameArchiveRecord,
} from "@/components/CommunityWorkspace";
import { ArchitectureWorkspace } from "@/components/ArchitectureWorkspace";
import HomeDashboard, { AppTab } from "@/components/HomeDashboard";
import OfflinePlay from "@/components/OfflinePlay";
import {
  saveSnapshot,
  loadSnapshot,
  savePuzzlePack,
  loadPuzzlePack,
  loadOfflineGames,
  unsyncedOfflineGames,
  markOfflineGamesSynced,
  loadPendingPuzzleResults,
  clearPendingPuzzleResults,
  loadSettings,
  saveSettings,
} from "@/lib/offlineStore";
import {
  analyzePosition,
  runFullGameReview,
  EngineLine,
  FullGameReview,
  CLASSIFICATION_META,
} from "@/lib/engine";
import { calculateMatchQuality } from "@/lib/glicko2";
import { soundEngine } from "@/lib/sound";
import type { LiveGameState, WsEventLogEntry } from "@/lib/redisStore";
import { QUICK_REACTIONS } from "@/lib/moderation";

const START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

const TIME_CONTROLS = [
  { id: "1+0", label: "1 min", cat: "Bullet", icon: "🚀" },
  { id: "1+1", label: "1|1", cat: "Bullet", icon: "🚀" },
  { id: "2+1", label: "2|1", cat: "Bullet", icon: "🚀" },
  { id: "3+0", label: "3 min", cat: "Blitz", icon: "⚡" },
  { id: "3+2", label: "3|2", cat: "Blitz", icon: "⚡" },
  { id: "5+0", label: "5 min", cat: "Blitz", icon: "⚡" },
  { id: "10+0", label: "10 min", cat: "Rapid", icon: "⏱️" },
  { id: "15+10", label: "15|10", cat: "Rapid", icon: "⏱️" },
  { id: "30+0", label: "30 min", cat: "Rapid", icon: "⏱️" },
  { id: "daily", label: "Daily", cat: "Daily", icon: "📅" },
];

interface ChatMsg {
  id: string;
  gameId: string;
  senderId: string;
  senderName: string;
  text: string;
  flagged?: boolean;
  reactionsJson?: string;
  createdAt?: string;
}

type TabKey = AppTab;

export default function HomePage() {
  // ---------- Global data ----------
  const [loading, setLoading] = useState(true);
  const [users, setUsers] = useState<PlatformUser[]>([]);
  const [games, setGames] = useState<GameArchiveRecord[]>([]);
  const [puzzles, setPuzzles] = useState<PuzzleItem[]>([]);
  const [challenges, setChallenges] = useState<ChallengeRecord[]>([]);
  const [friendIds, setFriendIds] = useState<Set<string>>(new Set());
  const [wsLogs, setWsLogs] = useState<WsEventLogEntry[]>([]);
  const [liveCount, setLiveCount] = useState(0);
  const [currentUserId, setCurrentUserId] = useState<string>("user-ademola");
  const [signedIn, setSignedIn] = useState(false);
  const [tab, setTab] = useState<TabKey>("home");
  const [toast, setToast] = useState<string | null>(null);
  const [boardTheme, setBoardTheme] = useState<BoardThemeKey>("emerald");
  const [soundOn, setSoundOn] = useState(true);
  const [showAuth, setShowAuth] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  // ---------- Offline-first state ----------
  const [navOnline, setNavOnline] = useState(true);
  const [forceOffline, setForceOffline] = useState(false);
  const forceOfflineRef = useRef(false);
  const isOnline = navOnline && !forceOffline;
  const [fromCache, setFromCache] = useState(false);
  const [snapshotSavedAt, setSnapshotSavedAt] = useState<number | null>(null);
  const [puzzlePackMeta, setPuzzlePackMeta] = useState<{ count: number; savedAt: number | null }>({ count: 0, savedAt: null });
  const [offlineGameStats, setOfflineGameStats] = useState({ total: 0, unsynced: 0 });
  const [botPick, setBotPick] = useState<{ rating: number; nonce: number }>({ rating: 1500, nonce: 0 });
  const [canInstall, setCanInstall] = useState(false);
  const installPromptRef = useRef<Event & { prompt?: () => void; userChoice?: Promise<unknown> } | null>(null);

  const refreshOfflineMeta = useCallback(() => {
    const snap = loadSnapshot();
    setSnapshotSavedAt(snap?.savedAt ?? null);
    const pack = loadPuzzlePack();
    setPuzzlePackMeta({ count: pack?.puzzles.length ?? 0, savedAt: pack?.savedAt ?? null });
    const all = loadOfflineGames();
    setOfflineGameStats({ total: all.length, unsynced: all.filter((g) => !g.synced).length });
  }, []);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3200);
  }, []);

  /** Stale-closure-safe offline check for callbacks (real or ✈️ simulated). */
  const currentlyOffline = useCallback(
    () =>
      forceOfflineRef.current ||
      (typeof navigator !== "undefined" && !navigator.onLine),
    []
  );

  const currentUser = useMemo(
    () => users.find((u) => u.id === currentUserId) || users[0],
    [users, currentUserId]
  );

  /** Hydrate the whole app from the on-device snapshot (offline boot). */
  const hydrateFromCache = useCallback((uid: string): boolean => {
    const snap = loadSnapshot();
    const pack = loadPuzzlePack();
    if (!snap && !pack) return false;
    if (snap) {
      setUsers(snap.users as PlatformUser[]);
      setGames(snap.games as GameArchiveRecord[]);
      setChallenges(snap.challenges as ChallengeRecord[]);
      const ids = new Set<string>();
      (snap.friendships as { userId: string; friendId: string }[]).forEach((f) => {
        ids.add(f.userId === uid ? f.friendId : f.userId);
      });
      setFriendIds(ids);
    }
    if (pack) setPuzzles(pack.puzzles as PuzzleItem[]);
    setFromCache(true);
    refreshOfflineMeta();
    return true;
  }, [refreshOfflineMeta]);

  const fetchOverview = useCallback(
    async (uid?: string) => {
      const id = uid || currentUserId;
      // Simulated offline (✈️ test toggle): behave exactly like no network.
      if (forceOfflineRef.current) {
        hydrateFromCache(id);
        setLoading(false);
        return;
      }
      try {
        const res = await fetch(`/api/overview?userId=${encodeURIComponent(id)}`, {
          cache: "no-store",
        });
        if (!res.ok) throw new Error(`overview ${res.status}`);
        const data = await res.json();
        if (!data.users) throw new Error("empty overview");
        setUsers(data.users);
        if (data.games) setGames(data.games);
        if (data.puzzles) setPuzzles(data.puzzles);
        if (data.challenges) setChallenges(data.challenges);
        if (data.wsEventLogs) setWsLogs(data.wsEventLogs);
        if (typeof data.activeLiveGamesCount === "number")
          setLiveCount(data.activeLiveGamesCount);
        if (data.friendships) {
          const ids = new Set<string>();
          data.friendships.forEach(
            (f: { userId: string; friendId: string }) => {
              ids.add(f.userId === id ? f.friendId : f.userId);
            }
          );
          setFriendIds(ids);
        }
        // Snapshot everything offline features need, for the next no-network boot.
        saveSnapshot({
          userId: id,
          users: data.users,
          games: data.games || [],
          challenges: data.challenges || [],
          friendships: data.friendships || [],
        });
        if (data.puzzles && data.puzzles.length > 0) savePuzzlePack(data.puzzles);
        setFromCache(false);
        refreshOfflineMeta();
      } catch {
        // Offline / server unreachable — fall back to the on-device snapshot.
        hydrateFromCache(id);
      } finally {
        setLoading(false);
      }
    },
    [currentUserId, hydrateFromCache, refreshOfflineMeta]
  );

  useEffect(() => {
    const saved =
      typeof window !== "undefined"
        ? localStorage.getItem("obsidian_user")
        : null;
    if (saved) {
      setCurrentUserId(saved);
      setSignedIn(true);
      fetchOverview(saved);
    } else {
      fetchOverview("user-ademola");
      setShowAuth(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /* Restore device settings (theme / sound / offline simulation) */
  useEffect(() => {
    const s = loadSettings();
    if (s.boardTheme) setBoardTheme(s.boardTheme as BoardThemeKey);
    if (typeof s.soundOn === "boolean") setSoundOn(s.soundOn);
    if (s.forceOffline) {
      setForceOffline(true);
      forceOfflineRef.current = true;
    }
    setNavOnline(typeof navigator === "undefined" ? true : navigator.onLine);
    refreshOfflineMeta();
  }, [refreshOfflineMeta]);

  /* Real connectivity changes */
  useEffect(() => {
    const on = () => setNavOnline(true);
    const off = () => setNavOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  /* PWA install prompt */
  useEffect(() => {
    const handler = (e: Event) => {
      e.preventDefault();
      installPromptRef.current = e as typeof installPromptRef.current;
      setCanInstall(true);
    };
    const installed = () => setCanInstall(false);
    window.addEventListener("beforeinstallprompt", handler);
    window.addEventListener("appinstalled", installed);
    return () => {
      window.removeEventListener("beforeinstallprompt", handler);
      window.removeEventListener("appinstalled", installed);
    };
  }, []);

  const promptInstall = async () => {
    const p = installPromptRef.current;
    if (p?.prompt) {
      p.prompt();
      try {
        await p.userChoice;
      } catch {
        /* ignore */
      }
      setCanInstall(false);
    } else {
      showToast("Use your browser menu → “Add to Home Screen” to install 📲");
    }
  };

  const setForceOfflineMode = (v: boolean) => {
    setForceOffline(v);
    forceOfflineRef.current = v;
    saveSettings({ forceOffline: v });
    if (v) {
      hydrateFromCache(currentUserId);
      showToast("✈️ Offline mode ON — computer games, puzzles & analysis still work");
    } else {
      showToast("Back online — syncing…");
    }
  };

  /** Sync on-device offline progress (finished computer games + puzzle results). */
  const syncOfflineData = useCallback(async () => {
    if (forceOfflineRef.current) return;
    let synced = 0;
    try {
      const pendingGames = unsyncedOfflineGames();
      const doneIds: string[] = [];
      for (const g of pendingGames) {
        try {
          const res = await fetch("/api/games", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "import",
              userId: g.playerColor === "w" ? currentUserId : "user-magnus",
              opponentId: g.playerColor === "w" ? "user-magnus" : currentUserId,
              pgn: g.pgn,
              openingName: `Offline game vs ${g.opponentName}`,
              timeControl: "10+0",
            }),
          });
          if (res.ok) doneIds.push(g.id);
        } catch {
          break;
        }
      }
      if (doneIds.length > 0) {
        markOfflineGamesSynced(doneIds);
        synced += doneIds.length;
      }

      const pendingPuzzles = loadPendingPuzzleResults();
      if (pendingPuzzles.length > 0) {
        let puzzleOk = true;
        for (const r of pendingPuzzles) {
          try {
            const res = await fetch("/api/puzzles", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                action: "attempt",
                userId: currentUserId,
                puzzleId: r.puzzleId,
                solved: r.solved,
                timeTakenMs: r.timeTakenMs,
              }),
            });
            if (res.ok) synced += 1;
          } catch {
            puzzleOk = false;
            break;
          }
        }
        if (puzzleOk) clearPendingPuzzleResults();
      }
    } finally {
      refreshOfflineMeta();
    }
    if (synced > 0) {
      showToast(`☁️ Synced ${synced} offline result(s) to your account`);
      fetchOverview();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [currentUserId, refreshOfflineMeta]);

  /* Auto-sync whenever connectivity returns (or the ✈️ test toggle turns off) */
  const wasOnlineRef = useRef(true);
  useEffect(() => {
    if (isOnline && !wasOnlineRef.current) {
      fetchOverview();
      syncOfflineData();
    }
    if (isOnline && wasOnlineRef.current && !loading) {
      // first boot while online: flush anything left over from a previous trip
      syncOfflineData();
    }
    wasOnlineRef.current = isOnline;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOnline, loading]);

  useEffect(() => {
    soundEngine.enabled = soundOn;
    saveSettings({ soundOn });
  }, [soundOn]);

  useEffect(() => {
    saveSettings({ boardTheme });
  }, [boardTheme]);

  const signInAs = (id: string) => {
    setCurrentUserId(id);
    setSignedIn(true);
    setShowAuth(false);
    localStorage.setItem("obsidian_user", id);
    fetchOverview(id);
    const u = users.find((x) => x.id === id);
    showToast(`Welcome back, ${u?.username || "Grandmaster"}! ♔`);
    soundEngine.play("game_start");
  };

  // ---------- Socket ----------
  const socketRef = useRef<Socket | null>(null);
  const [socketConnected, setSocketConnected] = useState(false);
  useEffect(() => {
    const s = io({ path: "/socket.io", transports: ["websocket", "polling"] });
    socketRef.current = s;
    s.on("connect", () => setSocketConnected(true));
    s.on("disconnect", () => setSocketConnected(false));
    s.on("game:state_sync", (state: LiveGameState) => {
      setLiveGame((prev) =>
        prev && prev.id === state.id ? state : prev
      );
    });
    s.on("chat:message", (msg: ChatMsg) => {
      setChatMessages((prev) =>
        prev.some((m) => m.id === msg.id) ? prev : [...prev, msg]
      );
    });
    return () => {
      s.disconnect();
    };
  }, []);

  /* ✈️ Simulated offline also drops the live socket, like a real outage */
  useEffect(() => {
    const s = socketRef.current;
    if (!s) return;
    if (forceOffline || !navOnline) {
      s.disconnect();
      setSocketConnected(false);
    } else if (!s.connected) {
      s.connect();
    }
  }, [forceOffline, navOnline]);

  // ---------- Play / Live game ----------
  const [selectedTc, setSelectedTc] = useState("3+2");
  const [customMins, setCustomMins] = useState(7);
  const [customInc, setCustomInc] = useState(3);
  const [useCustomTc, setUseCustomTc] = useState(false);
  const [ratedGame, setRatedGame] = useState(true);
  const [opponentPick, setOpponentPick] = useState<string>("auto");
  const [colorPref, setColorPref] = useState<"random" | "white" | "black">("random");
  const [searching, setSearching] = useState(false);
  const [searchSecs, setSearchSecs] = useState(0);
  const searchTimer = useRef<ReturnType<typeof setInterval> | null>(null);

  const [liveGame, setLiveGame] = useState<LiveGameState | null>(null);
  const [premove, setPremove] = useState<{
    from: string;
    to: string;
    promotion?: string;
  } | null>(null);
  const premoveRef = useRef<typeof premove>(null);
  premoveRef.current = premove;
  const [chatMessages, setChatMessages] = useState<ChatMsg[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [playFlipped, setPlayFlipped] = useState<boolean | null>(null);
  const [moveBusy, setMoveBusy] = useState(false);
  const [nowTick, setNowTick] = useState(Date.now());
  const lastPlyRef = useRef(0);
  const chatEndRef = useRef<HTMLDivElement>(null);

  const myColor: "w" | "b" | null = useMemo(() => {
    if (!liveGame || !currentUser) return null;
    if (liveGame.whitePlayer.id === currentUser.id) return "w";
    if (liveGame.blackPlayer.id === currentUser.id) return "b";
    return null;
  }, [liveGame, currentUser]);

  const opponentPlayer = useMemo(() => {
    if (!liveGame || !myColor) return null;
    return myColor === "w" ? liveGame.blackPlayer : liveGame.whitePlayer;
  }, [liveGame, myColor]);

  const flippedPlay =
    playFlipped !== null ? playFlipped : myColor === "b";

  // ticking clocks
  useEffect(() => {
    if (!liveGame || liveGame.status !== "active") return;
    const t = setInterval(() => setNowTick(Date.now()), 100);
    return () => clearInterval(t);
  }, [liveGame]);

  const displayTimes = useMemo(() => {
    if (!liveGame) return { w: 0, b: 0 };
    let w = liveGame.whiteTimeMs;
    let b = liveGame.blackTimeMs;
    if (liveGame.status === "active" && liveGame.moveHistory.length >= 2) {
      const elapsed = Math.max(0, nowTick - liveGame.lastMoveTimestamp);
      if (liveGame.turn === "w") w = Math.max(0, w - elapsed);
      else b = Math.max(0, b - elapsed);
    }
    return { w, b };
  }, [liveGame, nowTick]);

  // low-time warning beeps
  const myMs = myColor === "w" ? displayTimes.w : displayTimes.b;
  useEffect(() => {
    if (
      liveGame?.status === "active" &&
      liveGame.turn === myColor &&
      myMs > 0 &&
      myMs < 10000 &&
      Math.floor(myMs / 1000) !== Math.floor((myMs + 100) / 1000)
    ) {
      soundEngine.play("low_time");
    }
  }, [myMs, liveGame, myColor]);

  // move sound effects
  useEffect(() => {
    if (!liveGame) return;
    const n = liveGame.moveHistory.length;
    if (n > lastPlyRef.current && n > 0) {
      const last = liveGame.moveHistory[n - 1];
      if (last.san.includes("O-O")) soundEngine.play("castle");
      else if (last.san.includes("+") || last.san.includes("#"))
        soundEngine.play("check");
      else if (last.san.includes("x")) soundEngine.play("capture");
      else if (last.san.includes("=")) soundEngine.play("promote");
      else soundEngine.play("move");
      if (liveGame.status === "completed") soundEngine.play("game_end");
    }
    lastPlyRef.current = n;
  }, [liveGame]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chatMessages]);

  const loadChat = useCallback(async (gameId: string) => {
    try {
      const res = await fetch(`/api/chat?gameId=${gameId}`);
      const data = await res.json();
      if (data.messages) setChatMessages(data.messages);
    } catch {
      /* ignore */
    }
  }, []);

  const startGame = useCallback(
    async (opts?: { opponentId?: string; tc?: string; gameState?: LiveGameState }) => {
      if (opts?.gameState) {
        setLiveGame(opts.gameState);
        lastPlyRef.current = opts.gameState.moveHistory.length;
        setPremove(null);
        setPlayFlipped(null);
        setTab("play");
        socketRef.current?.emit("game:join", {
          gameId: opts.gameState.id,
          userId: currentUserId,
        });
        loadChat(opts.gameState.id);
        soundEngine.play("game_start");
        return;
      }
      if (currentlyOffline()) {
        showToast("📡 You're offline — live games are paused. Play vs Computer works fully offline!");
        setTab("computer");
        return;
      }
      const tc = opts?.tc || (useCustomTc ? `${customMins}+${customInc}` : selectedTc);
      try {
        const res = await fetch("/api/games", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "create",
            userId: currentUserId,
            opponentId:
              opts?.opponentId ||
              (opponentPick === "auto" ? undefined : opponentPick),
            timeControl: tc,
            rated: ratedGame,
            colorPref,
          }),
        });
        const data = await res.json();
        if (data.gameState) {
          await startGame({ gameState: data.gameState });
          showToast(
            `Match found! ${data.gameState.whitePlayer.username} vs ${data.gameState.blackPlayer.username} (${tc})`
          );
        } else {
          showToast(data.error || "Could not start match");
        }
      } catch {
        showToast("Network error starting match");
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [currentUserId, opponentPick, ratedGame, colorPref, selectedTc, useCustomTc, customMins, customInc]
  );

  const beginMatchmaking = () => {
    if (!isOnline) {
      showToast("📡 Live matchmaking needs a connection — opening Play vs Computer (works offline)");
      setTab("computer");
      return;
    }
    setSearching(true);
    setSearchSecs(0);
    soundEngine.play("move");
    let s = 0;
    searchTimer.current = setInterval(() => {
      s += 1;
      setSearchSecs(s);
    }, 1000);
    // brief queue ritual so the expanding Glicko-2 window is visible
    setTimeout(async () => {
      if (searchTimer.current) clearInterval(searchTimer.current);
      setSearching(false);
      await startGame();
    }, 1400);
  };

  const cancelMatchmaking = () => {
    setSearching(false);
    if (searchTimer.current) clearInterval(searchTimer.current);
  };

  const doMove = useCallback(
    async (mv: { from: string; to: string; promotion?: string }) => {
      if (!liveGame || liveGame.status !== "active" || moveBusy) return;
      // local legality check for instant feedback
      try {
        const c = new Chess(liveGame.fen);
        c.move({ from: mv.from, to: mv.to, promotion: mv.promotion || "q" });
      } catch {
        soundEngine.play("illegal");
        return;
      }
      setMoveBusy(true);
      setPremove(null);
      try {
        const res = await fetch("/api/games", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            action: "move",
            gameId: liveGame.id,
            ...mv,
            autoBotReply: true,
          }),
        });
        const data = await res.json();
        if (data.gameState) {
          setLiveGame(data.gameState);
          // execute a queued premove if it's now our turn again
          const pm = premoveRef.current;
          if (
            pm &&
            data.gameState.status === "active" &&
            data.gameState.turn === myColor
          ) {
            setTimeout(() => doMove(pm), 120);
          }
          if (data.gameState.status === "completed") fetchOverview();
        } else if (data.error) {
          soundEngine.play("illegal");
          showToast(data.error);
        }
      } catch {
        showToast("Move sync failed — check connection");
      } finally {
        setMoveBusy(false);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [liveGame, moveBusy, myColor]
  );

  const handleResign = async () => {
    if (!liveGame || !myColor) return;
    socketRef.current?.emit("game:resign", { gameId: liveGame.id, color: myColor });
    const res = await fetch("/api/games", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "resign", gameId: liveGame.id, color: myColor }),
    });
    const data = await res.json();
    if (data.gameState) {
      setLiveGame(data.gameState);
      fetchOverview();
    }
  };

  const handleDraw = async (sub: "offer" | "accept") => {
    if (!liveGame || !myColor) return;
    if (sub === "offer") {
      setLiveGame({ ...liveGame, drawOfferedBy: myColor });
      showToast("Draw offer sent 🤝 — titled bots accept near-equal positions after move 10.");
      // Bot adjudication via server socket path; also emulate locally:
      const res = await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "draw",
          gameId: liveGame.id,
          color: myColor,
          subAction: "offer",
        }),
      });
      const data = await res.json();
      if (data.gameState) setLiveGame(data.gameState);
      // If bot would accept (eval within ±1.10 and >=10 plies), accept on its behalf
      const lastEval =
        liveGame.moveHistory[liveGame.moveHistory.length - 1]?.evalCp || 0;
      if (
        opponentPlayer?.isAi &&
        liveGame.moveHistory.length >= 10 &&
        Math.abs(lastEval) < 110
      ) {
        setTimeout(() => handleDrawAccept(), 700);
      }
    } else {
      await handleDrawAccept();
    }
  };

  const handleDrawAccept = async () => {
    if (!liveGame) return;
    const res = await fetch("/api/games", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "draw",
        gameId: liveGame.id,
        color: myColor,
        subAction: "accept",
      }),
    });
    const data = await res.json();
    if (data.gameState) {
      setLiveGame(data.gameState);
      fetchOverview();
    }
  };

  const sendChat = async (textOverride?: string) => {
    const text = (textOverride ?? chatInput).trim();
    if (!text || !liveGame || !currentUser) return;
    if (currentlyOffline()) {
      showToast("💬 Chat is online-only — your message wasn't sent");
      return;
    }
    setChatInput("");
    const optimistic: ChatMsg = {
      id: `local-${Date.now()}`,
      gameId: liveGame.id,
      senderId: currentUser.id,
      senderName: currentUser.username,
      text,
      reactionsJson: "{}",
    };
    setChatMessages((p) => [...p, optimistic]);
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "send",
          gameId: liveGame.id,
          senderId: currentUser.id,
          senderName: currentUser.username,
          text,
          opponentName: opponentPlayer?.username,
          opponentIsAi: opponentPlayer?.isAi,
        }),
      });
      const data = await res.json();
      if (data.messages) {
        setChatMessages((prev) => {
          const withoutOpt = prev.filter((m) => m.id !== optimistic.id);
          const fresh = data.messages.filter(
            (m: ChatMsg) => !withoutOpt.some((x) => x.id === m.id)
          );
          return [...withoutOpt, ...fresh];
        });
        if (data.moderationNotice) showToast(data.moderationNotice);
      }
    } catch {
      /* keep optimistic */
    }
  };

  const reactToMsg = async (msg: ChatMsg, emoji: string) => {
    if (msg.id.startsWith("local-")) return;
    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "react", messageId: msg.id, emoji }),
      });
      const data = await res.json();
      if (data.message)
        setChatMessages((p) => p.map((m) => (m.id === msg.id ? data.message : m)));
    } catch {
      /* ignore */
    }
  };

  const liveLastMove = liveGame?.moveHistory[liveGame.moveHistory.length - 1];
  const liveEval = liveLastMove?.evalCp ?? 20;

  const matchQuality = useMemo(() => {
    if (!currentUser) return null;
    const opp =
      opponentPick === "auto"
        ? users
            .filter((u) => u.id !== currentUser.id)
            .sort(
              (a, b) =>
                Math.abs(a.blitzRating - currentUser.blitzRating) -
                Math.abs(b.blitzRating - currentUser.blitzRating)
            )[0]
        : users.find((u) => u.id === opponentPick);
    if (!opp) return null;
    const q = calculateMatchQuality(
      { rating: currentUser.blitzRating, rd: currentUser.blitzRd, vol: currentUser.blitzVol },
      { rating: opp.blitzRating, rd: opp.blitzRd, vol: opp.blitzVol },
      searchSecs
    );
    return { opp, ...q };
  }, [currentUser, users, opponentPick, searchSecs]);

  // ---------- Analysis ----------
  const [analysisFen, setAnalysisFen] = useState(START_FEN);
  const [analysisSans, setAnalysisSans] = useState<string[]>([]);
  const [analysisFens, setAnalysisFens] = useState<string[]>([START_FEN]);
  const [viewPly, setViewPly] = useState(0);
  const [analysisFlipped, setAnalysisFlipped] = useState(false);
  const [engineLines, setEngineLines] = useState<EngineLine[]>([]);
  const [engineBusy, setEngineBusy] = useState(false);
  const [review, setReview] = useState<FullGameReview | null>(null);
  const [reviewNames, setReviewNames] = useState({ w: "White", b: "Black" });
  const [reviewBusy, setReviewBusy] = useState(false);
  const [importText, setImportText] = useState(
    "1. e4 e5 2. Nf3 d6 3. d4 Bg4 4. dxe5 Bxf3 5. Qxf3 dxe5 6. Bc4 Nf6 7. Qb3 Qe7 8. Nc3 c6 9. Bg5 b5 10. Nxb5 cxb5 11. Bxb5+ Nbd7 12. O-O-O Rd8 13. Rxd7 Rxd7 14. Rd1 Qe6 15. Bxd7+ Nxd7 16. Qb8+ Nxb8 17. Rd8#"
  );
  const [analysisPgn, setAnalysisPgn] = useState("");
  const [retry, setRetry] = useState<{
    ply: number;
    bestSan: string;
    fenBefore: string;
  } | null>(null);
  const [retryFeedback, setRetryFeedback] = useState<string | null>(null);
  const [analysisTab, setAnalysisTab] = useState<"engine" | "opening" | "review">("engine");

  const displayAnalysisFen = review
    ? viewPly === 0
      ? review.plies[0]?.fenBefore || START_FEN
      : review.plies[Math.min(viewPly, review.plies.length) - 1]?.fenAfter || START_FEN
    : retry
    ? retry.fenBefore
    : analysisFens[Math.min(viewPly, analysisFens.length - 1)] || START_FEN;

  const maxPly = review ? review.plies.length : analysisSans.length;

  // engine analysis (client-side, Stockfish-structured Multi-PV)
  useEffect(() => {
    if (tab !== "analysis") return;
    setEngineBusy(true);
    const t = setTimeout(() => {
      try {
        const lines = analyzePosition(displayAnalysisFen, 2, 3);
        setEngineLines(lines);
      } catch {
        setEngineLines([]);
      } finally {
        setEngineBusy(false);
      }
    }, 180);
    return () => clearTimeout(t);
  }, [displayAnalysisFen, tab]);

  const analysisArrows: BoardArrow[] = useMemo(() => {
    const arr: BoardArrow[] = [];
    if (engineLines[0]?.from)
      arr.push({ from: engineLines[0].from, to: engineLines[0].to, color: "#81B64C" });
    if (engineLines[1]?.from && analysisTab === "engine")
      arr.push({ from: engineLines[1].from, to: engineLines[1].to, color: "rgba(56,189,248,0.75)" });
    if (review && viewPly > 0) {
      const ply = review.plies[viewPly - 1];
      if (ply && ply.bestMoveSan !== ply.san && ply.bestMoveFrom)
        arr.push({ from: ply.bestMoveFrom, to: ply.bestMoveTo, color: "rgba(239,68,68,0.8)" });
    }
    return arr;
  }, [engineLines, review, viewPly, analysisTab]);

  const analysisBadge = useMemo(() => {
    if (!review || viewPly === 0) return null;
    const ply = review.plies[viewPly - 1];
    return ply ? { square: ply.to, type: ply.classification } : null;
  }, [review, viewPly]);

  const analysisLastMove = useMemo(() => {
    if (review && viewPly > 0) {
      const p = review.plies[viewPly - 1];
      return p ? { from: p.from, to: p.to } : null;
    }
    if (viewPly > 0 && analysisSans.length >= viewPly) {
      // derive from fen diff — use chess replay
      const c = new Chess();
      let last: { from: string; to: string } | null = null;
      for (let i = 0; i < viewPly; i++) {
        try {
          const m = c.move(analysisSans[i]);
          last = { from: m.from, to: m.to };
        } catch {
          break;
        }
      }
      return last;
    }
    return null;
  }, [review, viewPly, analysisSans]);

  const applyAnalysisMove = (mv: { from: string; to: string; promotion?: string }) => {
    if (retry) {
      const c = new Chess(retry.fenBefore);
      try {
        const m = c.move({ from: mv.from, to: mv.to, promotion: mv.promotion || "q" });
        if (m.san === retry.bestSan || m.san.replace(/[+#]/g, "") === retry.bestSan.replace(/[+#]/g, "")) {
          soundEngine.play("promote");
          setRetryFeedback(`✅ Correct! ${m.san} was the engine's best move. Well retrained!`);
          setTimeout(() => {
            setRetry(null);
            setRetryFeedback(null);
          }, 1600);
        } else {
          soundEngine.play("illegal");
          setRetryFeedback(`✕ ${m.san} isn't best here. The engine wanted ${retry.bestSan} — try again!`);
        }
      } catch {
        soundEngine.play("illegal");
      }
      return;
    }
    if (review) {
      showToast("Exit Game Review (✕) to explore freely on the analysis board.");
      return;
    }
    // free analysis: truncate future if scrubbed back
    const baseSans = analysisSans.slice(0, viewPly);
    const c = new Chess();
    baseSans.forEach((s) => {
      try { c.move(s); } catch { /* noop */ }
    });
    try {
      const m = c.move({ from: mv.from, to: mv.to, promotion: mv.promotion || "q" });
      soundEngine.play(m.captured ? "capture" : m.san.includes("+") ? "check" : "move");
      const newSans = [...baseSans, m.san];
      const newFens = [START_FEN];
      const rc = new Chess();
      newSans.forEach((s) => {
        rc.move(s);
        newFens.push(rc.fen());
      });
      setAnalysisSans(newSans);
      setAnalysisFens(newFens);
      setAnalysisFen(c.fen());
      setViewPly(newSans.length);
      setAnalysisPgn(c.pgn());
    } catch {
      soundEngine.play("illegal");
    }
  };

  const playSanOnAnalysis = (san: string) => {
    const fen = displayAnalysisFen;
    const c = new Chess(fen);
    try {
      const m = c.move(san);
      applyAnalysisMove({ from: m.from, to: m.to, promotion: m.promotion });
    } catch {
      showToast(`Move ${san} is not legal in this position`);
    }
  };

  const loadPgnIntoAnalysis = (pgn: string, wName = "White", bName = "Black") => {
    const c = new Chess();
    try {
      c.loadPgn(pgn);
    } catch {
      const tokens = pgn.split(/\s+/).filter((t) => t && !/^\d+\./.test(t));
      for (const t of tokens) {
        try { c.move(t); } catch { break; }
      }
    }
    const hist = c.history({ verbose: true });
    const sans = hist.map((h) => h.san);
    const fens = [START_FEN];
    const rc = new Chess();
    sans.forEach((s) => {
      rc.move(s);
      fens.push(rc.fen());
    });
    setReview(null);
    setRetry(null);
    setAnalysisSans(sans);
    setAnalysisFens(fens);
    setAnalysisFen(rc.fen());
    setViewPly(sans.length);
    setAnalysisPgn(c.pgn());
    setReviewNames({ w: wName, b: bName });
  };

  const runReview = (pgn: string, wName: string, bName: string) => {
    setReviewBusy(true);
    setReviewNames({ w: wName, b: bName });
    setTimeout(() => {
      try {
        const r = runFullGameReview(pgn);
        setReview(r);
        setViewPly(0);
        setAnalysisTab("review");
        setTab("analysis");
        soundEngine.play("game_start");
        showToast(
          `Game Review complete — White ${r.whiteAccuracy}% · Black ${r.blackAccuracy}% accuracy`
        );
      } catch {
        showToast("Could not review that PGN");
      } finally {
        setReviewBusy(false);
      }
    }, 60);
  };

  const openGameInAnalysis = (g: GameArchiveRecord) => {
    loadPgnIntoAnalysis(g.pgn, g.whitePlayer.username, g.blackPlayer.username);
    setTab("analysis");
    runReview(g.pgn, g.whitePlayer.username, g.blackPlayer.username);
  };

  const copyText = async (txt: string, label: string) => {
    try {
      await navigator.clipboard.writeText(txt);
      showToast(`${label} copied to clipboard 📋`);
    } catch {
      showToast("Clipboard blocked by browser");
    }
  };

  const downloadPgn = (pgn: string, name: string) => {
    const blob = new Blob([pgn], { type: "application/x-chess-pgn" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const saveImportedGame = async () => {
    if (currentlyOffline()) {
      showToast("📥 Analysis works offline — saving to your cloud archive needs a connection");
      return;
    }
    const isFen = importText.includes("/") && !/^\s*1\./.test(importText);
    try {
      const res = await fetch("/api/games", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "import",
          userId: currentUserId,
          opponentId: "user-magnus",
          pgn: isFen ? undefined : importText,
          fen: isFen ? importText : undefined,
          openingName: "Imported PGN/FEN Analysis",
        }),
      });
      const data = await res.json();
      if (data.game) {
        showToast("Game saved to your archive with engine accuracy scores ✅");
        fetchOverview();
        if (data.game.pgn) loadPgnIntoAnalysis(data.game.pgn);
      } else showToast(data.error || "Import failed");
    } catch {
      showToast("Import failed");
    }
  };

  // ---------- Community handlers ----------
  const handleAcceptChallenge = async (challengeId: string) => {
    if (currentlyOffline()) {
      showToast("🔒 Challenges are online-only — reconnect to accept this one");
      return;
    }
    const res = await fetch("/api/challenges", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "accept", challengeId }),
    });
    const data = await res.json();
    if (data.gameState) {
      fetchOverview();
      startGame({ gameState: data.gameState });
      showToast("Challenge accepted — good luck! ♟️");
    } else showToast(data.error || "Could not accept challenge");
  };

  const handleDeclineChallenge = async (challengeId: string) => {
    setChallenges((p) => p.filter((c) => c.id !== challengeId));
    await fetch("/api/challenges", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "decline", challengeId }),
    });
    showToast("Challenge declined");
  };

  const handleCreateChallenge = async (params: {
    receiverId: string;
    timeControl: string;
    rated: boolean;
    colorPref: string;
    customFen?: string;
  }) => {
    const res = await fetch("/api/challenges", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "create", senderId: currentUserId, ...params }),
    });
    const data = await res.json();
    if (data.challenge) {
      showToast(`Challenge sent to ${data.challenge.receiver.username} (${params.timeControl}) ⚔️`);
      fetchOverview();
    } else showToast(data.error || "Challenge failed");
  };

  const handleToggleFriend = async (friendId: string) => {
    if (currentlyOffline()) {
      showToast("🔒 Friends sync when you're back online");
      return;
    }
    const had = friendIds.has(friendId);
    setFriendIds((prev) => {
      const n = new Set(prev);
      if (had) n.delete(friendId);
      else n.add(friendId);
      return n;
    });
    await fetch("/api/challenges", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "friend_toggle", userId: currentUserId, friendId }),
    });
    showToast(had ? "Friend removed" : "Friend added 🤝");
  };

  const handleDeleteGame = async (gameId: string) => {
    setGames((p) => p.filter((g) => g.id !== gameId));
    await fetch(`/api/games?gameId=${gameId}`, { method: "DELETE" });
    showToast("Archived game deleted");
  };

  // keyboard scrubbing in analysis
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (tab !== "analysis") return;
      if ((e.target as HTMLElement)?.tagName === "TEXTAREA" || (e.target as HTMLElement)?.tagName === "INPUT") return;
      if (e.key === "ArrowLeft") setViewPly((p) => Math.max(0, p - 1));
      if (e.key === "ArrowRight") setViewPly((p) => Math.min(maxPly, p + 1));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [tab, maxPly]);

  // ---------- Render helpers ----------
  const tabs: { key: TabKey; label: string; short: string; icon: React.ReactNode; offlineOk: boolean }[] = [
    { key: "home", label: "Home", short: "Home", icon: <Home className="w-4 h-4" />, offlineOk: true },
    { key: "play", label: "Play Live", short: "Play", icon: <Play className="w-4 h-4" />, offlineOk: false },
    { key: "computer", label: "Play Computer", short: "Computer", icon: <Bot className="w-4 h-4" />, offlineOk: true },
    { key: "puzzles", label: "Puzzles & Rush", short: "Puzzles", icon: <PuzzleIcon className="w-4 h-4" />, offlineOk: true },
    { key: "analysis", label: "Learn · Analysis", short: "Learn", icon: <BarChart3 className="w-4 h-4" />, offlineOk: true },
    { key: "community", label: "Community", short: "Social", icon: <Users className="w-4 h-4" />, offlineOk: false },
    { key: "architecture", label: "Architecture", short: "System", icon: <Cpu className="w-4 h-4" />, offlineOk: true },
  ];

  const downloadOfflinePack = async () => {
    if (currentlyOffline()) {
      showToast("You're offline already — reconnect to refresh the pack");
      return;
    }
    showToast("⬇️ Downloading app, puzzles & your data for offline use…");
    await fetchOverview(currentUserId);
    // Warm the service-worker API cache too
    try {
      await fetch("/api/puzzles", { cache: "no-store" });
    } catch {
      /* ignore */
    }
    refreshOfflineMeta();
    showToast(`✅ Offline pack ready — ${puzzles.length || puzzlePackMeta.count} puzzles + your games saved on this device`);
  };

  const resultBanner = useMemo(() => {
    if (!liveGame || liveGame.status !== "completed" || !myColor) return null;
    const won =
      (myColor === "w" && liveGame.result === "1-0") ||
      (myColor === "b" && liveGame.result === "0-1");
    const drew = liveGame.result === "1/2-1/2";
    const myDelta =
      myColor === "w"
        ? liveGame.ratingChange?.whiteDelta
        : liveGame.ratingChange?.blackDelta;
    const myNew =
      myColor === "w"
        ? liveGame.ratingChange?.whiteNew
        : liveGame.ratingChange?.blackNew;
    return { won, drew, myDelta, myNew };
  }, [liveGame, myColor]);

  if (loading) {
    return (
      <div className="min-h-screen bg-[#201D1B] flex flex-col items-center justify-center gap-4">
        <div className="text-6xl animate-pulse">♔</div>
        <div className="font-display text-xl text-slate-200">Obsidian Grandmaster</div>
        <div className="flex items-center gap-2 text-sm text-slate-400 font-mono">
          <Loader2 className="w-4 h-4 animate-spin text-emerald-400" />
          Connecting to matchmaking, engine & tactics servers…
        </div>
        <div className="grid grid-cols-3 gap-3 mt-4 w-full max-w-xl px-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-24 rounded-2xl bg-[#2B2825] border border-[#3A3733] animate-pulse" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#201D1B] text-slate-100 flex">
      {/* ============ SIDEBAR ============ */}
      <aside className="hidden lg:flex w-[260px] shrink-0 flex-col border-r border-[#33302C] bg-[#262321] sticky top-0 h-screen">
        <div className="p-4 border-b border-[#33302C]">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#95C75F] to-[#4E742D] text-white flex items-center justify-center text-2xl shadow-lg shadow-emerald-500/20">
              ♔
            </div>
            <div>
              <div className="font-display font-bold leading-none text-[17px]">
                Obsidian<span className="text-emerald-400">Chess</span>.io
              </div>
              <div className="text-[10px] font-mono text-stone-400 mt-1 flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${isOnline ? (socketConnected ? "bg-[#81B64C]" : "bg-amber-500 animate-pulse") : "bg-amber-500"}`} />
                {!isOnline
                  ? "OFFLINE MODE · on-device engine"
                  : socketConnected
                  ? "WebSocket LIVE · 0ms"
                  : "REST sync · reconnecting"}
              </div>
            </div>
          </div>
        </div>

        {/* Current user card */}
        {currentUser && (
          <button
            onClick={() => setShowProfile(true)}
            className="mx-3 mt-3 p-3 rounded-2xl bg-[#2B2825] border border-[#3A3733] hover:border-emerald-500/50 text-left transition-all"
          >
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-lg bg-slate-100 text-slate-900 flex items-center justify-center text-lg font-bold">
                {currentUser.avatar}
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  {currentUser.title && (
                    <span className="px-1 py-0.2 rounded bg-amber-500/20 text-amber-400 font-mono text-[9px] font-extrabold">
                      {currentUser.title}
                    </span>
                  )}
                  <span className="font-semibold text-sm truncate">{currentUser.username}</span>
                </div>
                <div className="text-[11px] text-slate-400">
                  🔥 {currentUser.streak} streak · {currentUser.gamesPlayed} games
                </div>
              </div>
            </div>
            <div className="grid grid-cols-3 gap-1.5 mt-2.5 text-center">
              {[
                { l: "Bullet", v: currentUser.bulletRating },
                { l: "Blitz", v: currentUser.blitzRating },
                { l: "Rapid", v: currentUser.rapidRating },
              ].map((r) => (
                <div key={r.l} className="py-1 rounded-lg bg-[#201D1B]">
                  <div className="text-[9px] font-mono uppercase text-slate-500">{r.l}</div>
                  <div className="font-mono text-sm font-bold text-emerald-400">{r.v}</div>
                </div>
              ))}
            </div>
          </button>
        )}

        <nav className="p-3 space-y-1">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm transition-all ${
                tab === t.key
                  ? "bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 font-semibold"
                  : "text-slate-400 hover:text-slate-100 hover:bg-[#35312C] border border-transparent"
              }`}
            >
              <span className="flex items-center gap-2.5">{t.icon}{t.label}
                {!isOnline && !t.offlineOk && <span className="text-[9px] font-mono px-1 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">ONLINE</span>}
                {!isOnline && t.offlineOk && <span className="text-[9px] font-mono px-1 rounded bg-[#81B64C]/15 text-[#BCE08A] border border-[#81B64C]/40">OFFLINE ✓</span>}
              </span>
              {t.key === "community" && challenges.length > 0 && (
                <span className="px-1.5 py-0.5 rounded-full bg-amber-500 text-slate-950 font-mono text-[10px] font-extrabold">
                  {challenges.length}
                </span>
              )}
              {t.key === "play" && liveGame?.status === "active" && (
                <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              )}
            </button>
          ))}
        </nav>

        <div className="mt-auto p-3 space-y-2 border-t border-[#33302C]">
          <div className="flex items-center justify-between text-xs text-slate-400 px-1">
            <span className="flex items-center gap-1.5"><Settings2 className="w-3.5 h-3.5" /> Board theme</span>
            <select
              value={boardTheme}
              onChange={(e) => setBoardTheme(e.target.value as BoardThemeKey)}
              className="bg-[#2B2825] border border-[#3A3733] rounded-lg px-2 py-1 text-xs text-slate-200"
            >
              {Object.entries(BOARD_THEMES).map(([k, v]) => (
                <option key={k} value={k}>{v.name}</option>
              ))}
            </select>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setSoundOn((s) => !s)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-xs text-slate-300"
            >
              {soundOn ? <Volume2 className="w-3.5 h-3.5 text-emerald-400" /> : <VolumeX className="w-3.5 h-3.5" />}
              {soundOn ? "Sound on" : "Muted"}
            </button>
            <button
              onClick={() => setShowAuth(true)}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-xs text-slate-300"
            >
              <LogIn className="w-3.5 h-3.5" /> Switch account
            </button>
          </div>
          <p className="text-[10px] text-slate-600 font-mono text-center">
            Glicko-2 · Socket.io · Stockfish-structured engine
          </p>
        </div>
      </aside>

      {/* ============ MAIN ============ */}
      <main className="flex-1 min-w-0">
        {/* Mobile / top header */}
        <header className="sticky top-0 z-40 backdrop-blur bg-[#201D1B]/85 border-b border-[#33302C]">
          <div className="px-4 py-3 flex items-center justify-between gap-3 flex-wrap">
            <div className="flex items-center gap-2 lg:hidden">
              <span className="text-2xl">♔</span>
              <span className="font-display font-bold">Obsidian<span className="text-emerald-400">Chess</span>.io</span>
            </div>
            <div className="hidden lg:block">
              <h1 className="font-display font-bold text-lg leading-none">
                {tab === "home" && "Home"}
                {tab === "play" && "Play Live Chess"}
                {tab === "computer" && "Play vs Computer — Offline"}
                {tab === "analysis" && "Learn · Engine Analysis & Game Review"}
                {tab === "puzzles" && "Tactical Puzzles & Puzzle Rush"}
                {tab === "community" && "Leaderboards, Friends & Challenges"}
                {tab === "architecture" && "System Architecture & Live Telemetry"}
              </h1>
              <p className="text-xs text-stone-400 mt-1">
                {isOnline
                  ? `${liveCount} live game room(s) · ${users.length} players online${fromCache ? " · showing saved data" : ""}`
                  : "Offline mode — computer games, puzzles & analysis run on this device"}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setForceOfflineMode(!forceOffline)}
                className={`inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full border text-xs font-mono font-bold ${isOnline ? "bg-[#81B64C]/15 border-[#81B64C]/50 text-[#BCE08A]" : "bg-amber-500/15 border-amber-500/60 text-amber-300"}`}
                title={isOnline ? "Online — tap to test offline mode" : "Offline — tap to go back online"}
              >
                {isOnline ? <Wifi className="w-3.5 h-3.5" /> : <WifiOff className="w-3.5 h-3.5" />}
                {isOnline ? "Online" : "Offline"}
              </button>
              {currentUser && (
                <span className="hidden md:inline-flex items-center gap-1.5 px-2.5 py-1.5 rounded-full bg-[#2B2825] border border-[#3A3733] text-xs font-mono">
                  ⚡ Blitz <b className="text-emerald-400">{currentUser.blitzRating}</b> · 🧩 <b className="text-amber-400">{currentUser.puzzleRating}</b>
                </span>
              )}
              <button
                onClick={() => fetchOverview()}
                className="p-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-slate-300 hover:text-emerald-300"
                title="Refresh platform data"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            </div>
          </div>
        </header>

        {/* Offline banner — professional apps keep you playing, not blocked */}
        {!isOnline && (
          <div className="sticky top-[57px] z-30 px-4 py-2.5 bg-[#3A2E12]/95 backdrop-blur border-b border-amber-500/50 flex items-center justify-center gap-2 text-center flex-wrap">
            <WifiOff className="w-4 h-4 text-amber-400 shrink-0" />
            <span className="text-xs md:text-sm text-amber-100">
              You&apos;re <b>offline</b> — <b>Computer games, puzzles & analysis still work.</b> Live play, chat & sync are paused.
            </span>
            <button onClick={() => setTab("computer")} className="px-2.5 py-1 rounded-lg bg-[#81B64C] text-white text-xs font-bold shadow-[0_3px_0_#457A26]">
              Play offline
            </button>
            {forceOffline && (
              <button onClick={() => setForceOfflineMode(false)} className="px-2.5 py-1 rounded-lg bg-[#35312C] border border-[#4A463F] text-xs">
                Exit test mode
              </button>
            )}
          </div>
        )}
        {isOnline && fromCache && (
          <div className="px-4 py-2 bg-[#2B2825] border-b border-[#3A3733] text-center text-[11px] font-mono text-stone-400">
            Showing saved on-device data{snapshotSavedAt ? "" : ""} · tap refresh to sync the latest
          </div>
        )}

        <div className="p-4 md:p-5 pb-28 lg:pb-5 max-w-[1500px] mx-auto">
          {/* ================= HOME (professional app home) ================= */}
          {tab === "home" && currentUser && (
            <HomeDashboard
              currentUser={currentUser}
              users={users}
              games={games}
              puzzles={puzzles}
              challenges={challenges}
              isOnline={isOnline}
              forceOffline={forceOffline}
              snapshotSavedAt={snapshotSavedAt}
              puzzlePackCount={puzzlePackMeta.count}
              puzzlePackSavedAt={puzzlePackMeta.savedAt}
              offlineGamesCount={offlineGameStats.total}
              unsyncedCount={offlineGameStats.unsynced}
              canInstall={canInstall}
              onGoTab={(t) => setTab(t)}
              onQuickPlay={(tc) => {
                if (!isOnline) {
                  showToast("Offline quick game — paired with the computer 🤖");
                  setBotPick((p) => ({ rating: 1500, nonce: p.nonce + 1 }));
                  setTab("computer");
                } else {
                  setSelectedTc(tc);
                  setUseCustomTc(false);
                  setTab("play");
                  setTimeout(() => startGame({ tc }), 60);
                }
              }}
              onPlayBot={(rating) => {
                setBotPick((p) => ({ rating, nonce: p.nonce + 1 }));
                setTab("computer");
              }}
              onOpenGame={openGameInAnalysis}
              onDownloadOfflinePack={downloadOfflinePack}
              onToggleForceOffline={setForceOfflineMode}
              onInstall={promptInstall}
            />
          )}

          {/* ================= PLAY VS COMPUTER (offline) ================= */}
          {tab === "computer" && currentUser && (
            <OfflinePlay
              playerName={currentUser.username}
              playerAvatar={currentUser.avatar}
              playerTitle={currentUser.title}
              boardTheme={boardTheme}
              isOnline={isOnline}
              initialBotRating={botPick.rating}
              botPickNonce={botPick.nonce}
              onReviewGame={(pgn, w, b) => {
                loadPgnIntoAnalysis(pgn, w, b);
                runReview(pgn, w, b);
                refreshOfflineMeta();
              }}
              onToast={(m) => {
                showToast(m);
                refreshOfflineMeta();
              }}
            />
          )}

          {/* ================= PLAY ================= */}
          {tab === "play" && (
            <div className="grid grid-cols-1 xl:grid-cols-[1fr_420px] gap-5 items-start">
              {/* Board column */}
              <div className="space-y-2.5">
                {!liveGame ? (
                  <>
                    <PlayerHudBar
                      username={matchQuality?.opp.username || "Waiting for opponent…"}
                      title={matchQuality?.opp.title}
                      avatar={matchQuality?.opp.avatar || "♟️"}
                      rating={matchQuality?.opp.blitzRating || 1500}
                      rd={matchQuality?.opp.blitzRd}
                      isAi={matchQuality?.opp.isAi}
                      color="b"
                      isActiveTurn={false}
                      timeRemainingMs={useCustomTc ? customMins * 60000 : selectedTc === "daily" ? 86400000 : parseFloat(selectedTc) * 60000}
                      fen={START_FEN}
                    />
                    <ChessboardArena
                      fen={START_FEN}
                      interactive={false}
                      evalCp={20}
                      theme={boardTheme}
                    />
                    <PlayerHudBar
                      username={currentUser?.username || "You"}
                      title={currentUser?.title}
                      avatar={currentUser?.avatar}
                      rating={currentUser?.blitzRating || 1500}
                      rd={currentUser?.blitzRd}
                      color="w"
                      isActiveTurn={false}
                      timeRemainingMs={useCustomTc ? customMins * 60000 : selectedTc === "daily" ? 86400000 : parseFloat(selectedTc) * 60000}
                      fen={START_FEN}
                    />
                    <div className="max-w-[660px] mx-auto w-full p-4 rounded-2xl bg-gradient-to-r from-emerald-500/15 via-[#2B2825] to-amber-500/10 border border-emerald-500/30 text-center">
                      <div className="font-display font-bold">Ready when you are, {currentUser?.username} 👋</div>
                      <p className="text-xs text-slate-400 mt-1">
                        Pick a time control on the right and hit <b className="text-emerald-300">Play</b> — Glicko-2 matchmaking pairs you with a titled engine opponent near your rating. Drag or click-click to move, right-click to annotate, and premove while your opponent thinks.
                      </p>
                    </div>
                  </>
                ) : (
                  <>
                    {/* Opponent HUD (top) */}
                    <PlayerHudBar
                      username={(flippedPlay ? liveGame.whitePlayer : liveGame.blackPlayer).username}
                      title={(flippedPlay ? liveGame.whitePlayer : liveGame.blackPlayer).title}
                      avatar={(flippedPlay ? liveGame.whitePlayer : liveGame.blackPlayer).avatar}
                      rating={(flippedPlay ? liveGame.whitePlayer : liveGame.blackPlayer).rating}
                      rd={(flippedPlay ? liveGame.whitePlayer : liveGame.blackPlayer).rd}
                      ratingDelta={flippedPlay ? liveGame.ratingChange?.whiteDelta : liveGame.ratingChange?.blackDelta}
                      isAi={(flippedPlay ? liveGame.whitePlayer : liveGame.blackPlayer).isAi}
                      connected={socketConnected}
                      color={flippedPlay ? "w" : "b"}
                      isActiveTurn={liveGame.status === "active" && liveGame.turn === (flippedPlay ? "w" : "b")}
                      timeRemainingMs={flippedPlay ? displayTimes.w : displayTimes.b}
                      fen={liveGame.fen}
                    />

                    {resultBanner && (
                      <div className={`max-w-[660px] mx-auto w-full p-4 rounded-2xl border text-center ${
                        resultBanner.won
                          ? "bg-emerald-950/60 border-emerald-500/60"
                          : resultBanner.drew
                          ? "bg-slate-800/60 border-slate-500/50"
                          : "bg-rose-950/50 border-rose-500/50"
                      }`}>
                        <div className="font-display text-xl font-bold">
                          {resultBanner.won ? "🏆 Victory!" : resultBanner.drew ? "🤝 Draw" : "💔 Defeat"}{" "}
                          <span className="font-mono text-base">{liveGame.result}</span>
                        </div>
                        <p className="text-xs text-slate-300 mt-1 capitalize">
                          by {liveGame.termination.replace(/_/g, " ")}
                          {typeof resultBanner.myDelta === "number" && (
                            <> · Glicko-2: <b className={resultBanner.myDelta >= 0 ? "text-emerald-300" : "text-rose-300"}>
                              {resultBanner.myDelta >= 0 ? "+" : ""}{resultBanner.myDelta}
                            </b> → <b className="text-emerald-300">{resultBanner.myNew}</b></>
                          )}
                        </p>
                        <div className="flex justify-center gap-2 mt-3 flex-wrap">
                          <button
                            onClick={() => opponentPlayer && startGame({ opponentId: opponentPlayer.id, tc: liveGame.timeControl })}
                            className="px-4 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs"
                          >
                            ⟳ Rematch
                          </button>
                          <button
                            onClick={() => {
                              loadPgnIntoAnalysis(liveGame.pgn, liveGame.whitePlayer.username, liveGame.blackPlayer.username);
                              runReview(liveGame.pgn, liveGame.whitePlayer.username, liveGame.blackPlayer.username);
                            }}
                            className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs"
                          >
                            🔍 Game Review
                          </button>
                          <button
                            onClick={() => setLiveGame(null)}
                            className="px-4 py-2 rounded-xl bg-[#35312C] border border-[#4A463F] text-xs text-slate-200"
                          >
                            New opponent
                          </button>
                        </div>
                      </div>
                    )}

                    {liveGame.drawOfferedBy && liveGame.drawOfferedBy !== myColor && liveGame.status === "active" && (
                      <div className="max-w-[660px] mx-auto w-full p-3 rounded-xl bg-amber-500/15 border border-amber-500/50 flex items-center justify-between">
                        <span className="text-sm">🤝 {opponentPlayer?.username} offers a draw</span>
                        <div className="flex gap-2">
                          <button onClick={() => handleDraw("accept")} className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs">Accept</button>
                          <button onClick={() => setLiveGame({ ...liveGame, drawOfferedBy: null })} className="px-3 py-1.5 rounded-lg bg-[#35312C] text-xs">Decline</button>
                        </div>
                      </div>
                    )}

                    <ChessboardArena
                      fen={liveGame.fen}
                      flipped={flippedPlay}
                      interactive={liveGame.status === "active"}
                      playerColor={myColor || "both"}
                      onMove={doMove}
                      onPremove={(pm) => {
                        setPremove(pm);
                        if (pm) showToast(`Premove queued: ${pm.from.toUpperCase()}→${pm.to.toUpperCase()} ⚡`);
                      }}
                      activePremove={premove}
                      lastMove={liveLastMove ? { from: liveLastMove.from, to: liveLastMove.to } : null}
                      evalCp={liveEval}
                      theme={boardTheme}
                    />

                    {/* My HUD (bottom) */}
                    <PlayerHudBar
                      username={(flippedPlay ? liveGame.blackPlayer : liveGame.whitePlayer).username}
                      title={(flippedPlay ? liveGame.blackPlayer : liveGame.whitePlayer).title}
                      avatar={(flippedPlay ? liveGame.blackPlayer : liveGame.whitePlayer).avatar}
                      rating={(flippedPlay ? liveGame.blackPlayer : liveGame.whitePlayer).rating}
                      rd={(flippedPlay ? liveGame.blackPlayer : liveGame.whitePlayer).rd}
                      ratingDelta={flippedPlay ? liveGame.ratingChange?.blackDelta : liveGame.ratingChange?.whiteDelta}
                      isAi={(flippedPlay ? liveGame.blackPlayer : liveGame.whitePlayer).isAi}
                      connected={socketConnected}
                      color={flippedPlay ? "b" : "w"}
                      isActiveTurn={liveGame.status === "active" && liveGame.turn === (flippedPlay ? "b" : "w")}
                      timeRemainingMs={flippedPlay ? displayTimes.b : displayTimes.w}
                      fen={liveGame.fen}
                    />

                    {/* Controls */}
                    <div className="max-w-[660px] mx-auto w-full flex flex-wrap gap-2">
                      <button onClick={() => setPlayFlipped(!flippedPlay)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-xs">
                        <FlipVertical2 className="w-3.5 h-3.5" /> Flip board
                      </button>
                      {liveGame.status === "active" && (
                        <>
                          <button onClick={() => handleDraw("offer")} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-xs hover:border-amber-500/50">
                            <Handshake className="w-3.5 h-3.5 text-amber-400" /> Offer draw
                          </button>
                          <button onClick={handleResign} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500/10 border border-rose-500/40 text-rose-300 text-xs">
                            <Flag className="w-3.5 h-3.5" /> Resign
                          </button>
                          {premove && (
                            <button onClick={() => setPremove(null)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-500 text-white text-xs font-bold animate-pulse">
                              <X className="w-3.5 h-3.5" /> Cancel premove ({premove.from}→{premove.to})
                            </button>
                          )}
                        </>
                      )}
                      <span className="ml-auto font-mono text-[11px] text-slate-500 self-center">
                        {liveGame.timeControl} · {liveGame.category} · {liveGame.rated ? "Rated" : "Casual"} · {liveGame.status}
                      </span>
                    </div>
                  </>
                )}
              </div>

              {/* Right rail */}
              <div className="space-y-4">
                {/* Matchmaking card */}
                <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="font-display font-bold flex items-center gap-2">
                      <Swords className="w-4 h-4 text-emerald-400" /> New Game
                    </h3>
                    <label className="flex items-center gap-1.5 text-xs text-slate-300">
                      <input type="checkbox" checked={ratedGame} onChange={(e) => setRatedGame(e.target.checked)} className="accent-emerald-500" />
                      Rated (Glicko-2)
                    </label>
                  </div>

                  <div className="grid grid-cols-5 gap-1.5">
                    {TIME_CONTROLS.map((tc) => (
                      <button
                        key={tc.id}
                        onClick={() => { setSelectedTc(tc.id); setUseCustomTc(false); }}
                        className={`py-2 px-1 rounded-xl border text-center transition-all ${
                          !useCustomTc && selectedTc === tc.id
                            ? "bg-emerald-500/20 border-emerald-500 text-emerald-200"
                            : "bg-[#201D1B] border-[#3A3733] text-slate-300 hover:border-slate-600"
                        }`}
                      >
                        <div className="text-sm">{tc.icon}</div>
                        <div className="font-mono text-[11px] font-bold">{tc.label}</div>
                        <div className="text-[9px] text-slate-500">{tc.cat}</div>
                      </button>
                    ))}
                  </div>

                  <div className={`p-2.5 rounded-xl border ${useCustomTc ? "border-emerald-500/60 bg-emerald-500/10" : "border-[#3A3733] bg-[#201D1B]"}`}>
                    <label className="flex items-center justify-between text-xs text-slate-300 cursor-pointer">
                      <span>Custom time control</span>
                      <input type="checkbox" checked={useCustomTc} onChange={(e) => setUseCustomTc(e.target.checked)} className="accent-emerald-500" />
                    </label>
                    {useCustomTc && (
                      <div className="grid grid-cols-2 gap-2 mt-2">
                        <label className="text-[11px] text-slate-400">Minutes
                          <input type="number" min={1} max={60} value={customMins} onChange={(e) => setCustomMins(Number(e.target.value))} className="w-full mt-1 px-2 py-1.5 rounded-lg bg-[#2B2825] border border-[#3A3733] font-mono text-xs" />
                        </label>
                        <label className="text-[11px] text-slate-400">Increment (sec)
                          <input type="number" min={0} max={30} value={customInc} onChange={(e) => setCustomInc(Number(e.target.value))} className="w-full mt-1 px-2 py-1.5 rounded-lg bg-[#2B2825] border border-[#3A3733] font-mono text-xs" />
                        </label>
                      </div>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <label className="text-[11px] text-slate-400">Opponent
                      <select value={opponentPick} onChange={(e) => setOpponentPick(e.target.value)} className="w-full mt-1 px-2 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs text-slate-200">
                        <option value="auto">🎲 Auto (closest rating)</option>
                        {users.filter((u) => u.id !== currentUserId).map((u) => (
                          <option key={u.id} value={u.id}>{u.title ? `${u.title} ` : ""}{u.username} ({u.blitzRating})</option>
                        ))}
                      </select>
                    </label>
                    <label className="text-[11px] text-slate-400">Play as
                      <select value={colorPref} onChange={(e) => setColorPref(e.target.value as typeof colorPref)} className="w-full mt-1 px-2 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-xs text-slate-200">
                        <option value="random">Random</option>
                        <option value="white">⬜ White</option>
                        <option value="black">⬛ Black</option>
                      </select>
                    </label>
                  </div>

                  {matchQuality && (
                    <div className="p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] font-mono text-[11px] text-slate-300 flex justify-between">
                      <span>Match quality vs {matchQuality.opp.username}</span>
                      <span><b className="text-emerald-400">{matchQuality.qualityPercent}%</b> · Win exp {matchQuality.winProbWhite}%</span>
                    </div>
                  )}

                  {searching ? (
                    <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/50 text-center">
                      <div className="flex items-center justify-center gap-2 font-mono text-sm text-amber-300">
                        <Search className="w-4 h-4 animate-pulse" /> Searching ±{150 + searchSecs * 50} rating window… {searchSecs}s
                      </div>
                      <button onClick={cancelMatchmaking} className="mt-2 px-3 py-1.5 rounded-lg bg-[#35312C] text-xs">Cancel</button>
                    </div>
                  ) : (
                    <button
                      onClick={beginMatchmaking}
                      className="w-full py-3.5 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-display font-bold text-lg shadow-[0_6px_0_#457A26] active:translate-y-1 active:shadow-[0_2px_0_#457A26] transition-all"
                    >
                      ▶ {isOnline ? `Play ${useCustomTc ? `${customMins}+${customInc}` : selectedTc}` : "Offline — Play vs Computer"}
                    </button>
                  )}
                </div>

                {/* Move list */}
                <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400">
                      Moves {liveGame ? `(${Math.ceil(liveGame.moveHistory.length / 2)})` : ""}
                    </span>
                    {liveGame && (
                      <div className="flex gap-1.5">
                        <button onClick={() => copyText(liveGame.pgn || "—", "PGN")} className="px-2 py-1 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] font-mono flex items-center gap-1"><Copy className="w-3 h-3" /> PGN</button>
                        <button onClick={() => copyText(liveGame.fen, "FEN")} className="px-2 py-1 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] font-mono flex items-center gap-1"><Copy className="w-3 h-3" /> FEN</button>
                        <button onClick={() => downloadPgn(liveGame.pgn, `obsidian-${liveGame.id}.pgn`)} className="px-2 py-1 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] font-mono flex items-center gap-1"><Download className="w-3 h-3" /></button>
                      </div>
                    )}
                  </div>
                  {!liveGame || liveGame.moveHistory.length === 0 ? (
                    <div className="py-6 text-center text-xs text-slate-500 font-mono">No moves yet — your game notation will appear here.</div>
                  ) : (
                    <div className="grid grid-cols-[36px_1fr_1fr] gap-y-1 text-sm font-mono max-h-52 overflow-y-auto pr-1">
                      {Array.from({ length: Math.ceil(liveGame.moveHistory.length / 2) }).map((_, i) => {
                        const w = liveGame.moveHistory[i * 2];
                        const b = liveGame.moveHistory[i * 2 + 1];
                        return (
                          <React.Fragment key={i}>
                            <span className="text-slate-500 py-0.5">{i + 1}.</span>
                            <span className={`px-1.5 py-0.5 rounded ${w === liveLastMove ? "bg-emerald-500/20 text-emerald-300" : "text-slate-200"}`}>{w?.san}</span>
                            <span className={`px-1.5 py-0.5 rounded ${b === liveLastMove ? "bg-emerald-500/20 text-emerald-300" : "text-slate-200"}`}>{b?.san || ""}</span>
                          </React.Fragment>
                        );
                      })}
                    </div>
                  )}
                </div>

                {/* Chat */}
                <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                    💬 Game chat {liveGame ? `· vs ${opponentPlayer?.username}` : "· start a game to chat"}
                  </div>
                  <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                    {chatMessages.length === 0 ? (
                      <div className="py-5 text-center text-xs text-slate-500">
                        Say &quot;gl hf!&quot; — fair-play filter is on, emoji reactions welcome 🤝
                      </div>
                    ) : (
                      chatMessages.map((m) => {
                        let reactions: Record<string, number> = {};
                        try { reactions = JSON.parse(m.reactionsJson || "{}"); } catch { reactions = {}; }
                        const mine = m.senderId === currentUserId;
                        return (
                          <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
                            <div className={`max-w-[85%] px-3 py-2 rounded-2xl text-sm ${mine ? "bg-emerald-500/20 border border-emerald-500/40 rounded-br-sm" : "bg-[#201D1B] border border-[#3A3733] rounded-bl-sm"}`}>
                              <div className="text-[10px] font-mono text-slate-400">{m.senderName}{m.flagged ? " · filtered" : ""}</div>
                              <div>{m.text}</div>
                              <div className="flex gap-1 mt-1 flex-wrap items-center">
                                {Object.entries(reactions).map(([e, n]) => (
                                  <span key={e} className="text-[11px] px-1 rounded bg-white/5">{e} {n}</span>
                                ))}
                                {QUICK_REACTIONS.slice(0, 4).map((r) => (
                                  <button key={r.emoji} onClick={() => reactToMsg(m, r.emoji)} className="text-[11px] opacity-50 hover:opacity-100" title={r.label}>{r.emoji}</button>
                                ))}
                              </div>
                            </div>
                          </div>
                        );
                      })
                    )}
                    <div ref={chatEndRef} />
                  </div>
                  <div className="flex gap-1.5 mt-2 flex-wrap">
                    {QUICK_REACTIONS.map((r) => (
                      <button key={r.emoji} disabled={!liveGame} onClick={() => sendChat(`${r.emoji} ${r.label}!`)} className="px-2 py-1 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] disabled:opacity-40">
                        {r.emoji} {r.label}
                      </button>
                    ))}
                  </div>
                  <div className="flex gap-2 mt-2">
                    <input
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      onKeyDown={(e) => e.key === "Enter" && sendChat()}
                      disabled={!liveGame}
                      placeholder={liveGame ? "Message your opponent…" : "Start a game to chat"}
                      className="flex-1 px-3 py-2 rounded-xl bg-[#201D1B] border border-[#3A3733] text-sm disabled:opacity-40"
                    />
                    <button onClick={() => sendChat()} disabled={!liveGame} className="px-3 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold disabled:opacity-40">
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= ANALYSIS ================= */}
          {tab === "analysis" && (
            <div className="grid grid-cols-1 xl:grid-cols-[1fr_440px] gap-5 items-start">
              <div className="space-y-2.5">
                <PlayerHudBar
                  username={analysisFlipped ? reviewNames.w : reviewNames.b}
                  rating={2500}
                  avatar={analysisFlipped ? "♔" : "♚"}
                  color={analysisFlipped ? "w" : "b"}
                  isActiveTurn={false}
                  timeRemainingMs={0}
                  fen={displayAnalysisFen}
                  showClock={false}
                />

                {retry && (
                  <div className="max-w-[660px] mx-auto w-full p-3 rounded-xl bg-amber-500/15 border border-amber-500/60 flex items-center justify-between gap-2">
                    <span className="text-sm">🎯 <b>Retry this mistake</b> — find the engine&apos;s best move in this position.</span>
                    <button onClick={() => { setRetry(null); setRetryFeedback(null); }} className="px-2.5 py-1 rounded-lg bg-[#35312C] text-xs">Exit</button>
                  </div>
                )}
                {retryFeedback && (
                  <div className="max-w-[660px] mx-auto w-full p-3 rounded-xl bg-[#2B2825] border border-[#3A3733] text-sm">{retryFeedback}</div>
                )}
                {review && (
                  <div className="max-w-[660px] mx-auto w-full p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/40 flex items-center justify-between gap-2">
                    <span className="text-sm">
                      🔍 <b>Game Review</b> — {review.openingName} · White {review.whiteAccuracy}% / Black {review.blackAccuracy}%
                    </span>
                    <button onClick={() => { setReview(null); setViewPly(analysisSans.length); }} className="px-2.5 py-1 rounded-lg bg-[#35312C] text-xs shrink-0">✕ Exit review</button>
                  </div>
                )}

                <ChessboardArena
                  fen={displayAnalysisFen}
                  flipped={analysisFlipped}
                  interactive={!review || !!retry}
                  playerColor="both"
                  onMove={applyAnalysisMove}
                  lastMove={analysisLastMove}
                  classificationBadge={analysisBadge}
                  engineArrows={analysisArrows}
                  evalCp={review && viewPly > 0 ? review.plies[viewPly - 1]?.evalAfter ?? 0 : engineLines[0]?.scoreCp ?? 20}
                  mateIn={engineLines[0]?.mateIn ?? null}
                  theme={boardTheme}
                />

                <PlayerHudBar
                  username={analysisFlipped ? reviewNames.b : reviewNames.w}
                  rating={2500}
                  avatar={analysisFlipped ? "♚" : "♔"}
                  color={analysisFlipped ? "b" : "w"}
                  isActiveTurn={false}
                  timeRemainingMs={0}
                  fen={displayAnalysisFen}
                  showClock={false}
                />

                {/* Playback controls */}
                <div className="max-w-[660px] mx-auto w-full flex items-center gap-2">
                  <div className="flex gap-1">
                    <button onClick={() => setViewPly(0)} className="p-2 rounded-lg bg-[#2B2825] border border-[#3A3733]"><ChevronFirst className="w-4 h-4" /></button>
                    <button onClick={() => setViewPly((p) => Math.max(0, p - 1))} className="p-2 rounded-lg bg-[#2B2825] border border-[#3A3733]"><ChevronLeft className="w-4 h-4" /></button>
                    <button onClick={() => setViewPly((p) => Math.min(maxPly, p + 1))} className="p-2 rounded-lg bg-[#2B2825] border border-[#3A3733]"><ChevronRight className="w-4 h-4" /></button>
                    <button onClick={() => setViewPly(maxPly)} className="p-2 rounded-lg bg-[#2B2825] border border-[#3A3733]"><ChevronLast className="w-4 h-4" /></button>
                  </div>
                  <span className="font-mono text-xs text-slate-400">Ply {viewPly}/{maxPly} · ←/→ keys</span>
                  <button onClick={() => setAnalysisFlipped((f) => !f)} className="ml-auto flex items-center gap-1.5 px-3 py-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-xs">
                    <FlipVertical2 className="w-3.5 h-3.5" /> Flip
                  </button>
                  <button onClick={() => { setReview(null); setRetry(null); setAnalysisSans([]); setAnalysisFens([START_FEN]); setViewPly(0); setAnalysisPgn(""); }} className="px-3 py-2 rounded-xl bg-[#2B2825] border border-[#3A3733] text-xs">
                    Reset board
                  </button>
                </div>

                {/* Move list with classifications */}
                <div className="max-w-[660px] mx-auto w-full bg-[#2B2825] border border-[#3A3733] rounded-2xl p-3">
                  {maxPly === 0 ? (
                    <div className="py-4 text-center text-xs text-slate-500 font-mono">
                      Play moves freely, paste a PGN/FEN, or pick a game from your archive →
                    </div>
                  ) : (
                    <div className="grid grid-cols-[36px_1fr_1fr] gap-y-1 text-sm font-mono max-h-48 overflow-y-auto pr-1">
                      {Array.from({ length: Math.ceil(maxPly / 2) }).map((_, i) => {
                        const renderCell = (plyIdx: number) => {
                          if (plyIdx >= maxPly) return <span />;
                          const san = review ? review.plies[plyIdx].san : analysisSans[plyIdx];
                          const cls = review ? CLASSIFICATION_META[review.plies[plyIdx].classification] : null;
                          return (
                            <button
                              onClick={() => setViewPly(plyIdx + 1)}
                              className={`text-left px-1.5 py-0.5 rounded flex items-center gap-1.5 ${viewPly === plyIdx + 1 ? "bg-emerald-500/25 text-emerald-200" : "text-slate-200 hover:bg-[#35312C]"}`}
                            >
                              {san}
                              {cls && (
                                <span className="text-[9px] px-1 rounded-full font-extrabold" style={{ backgroundColor: cls.bgColor, color: cls.color, border: `1px solid ${cls.borderColor}` }}>
                                  {cls.symbol}
                                </span>
                              )}
                            </button>
                          );
                        };
                        return (
                          <React.Fragment key={i}>
                            <span className="text-slate-500 py-0.5">{i + 1}.</span>
                            {renderCell(i * 2)}
                            {renderCell(i * 2 + 1)}
                          </React.Fragment>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* Right rail */}
              <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl p-4 space-y-3">
                <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-[#201D1B] border border-[#3A3733]">
                  {(
                    [
                      { id: "engine", label: "♟ Engine" },
                      { id: "opening", label: "📖 Explorer" },
                      { id: "review", label: "🔍 Review" },
                    ] as const
                  ).map((t) => (
                    <button
                      key={t.id}
                      onClick={() => setAnalysisTab(t.id)}
                      className={`py-2 rounded-lg text-xs font-semibold ${analysisTab === t.id ? "bg-emerald-500 text-slate-950" : "text-slate-400"}`}
                    >
                      {t.label}
                    </button>
                  ))}
                </div>

                {analysisTab === "engine" && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                        Multi-PV Analysis {engineBusy && <Loader2 className="w-3 h-3 animate-spin" />}
                      </span>
                      <span className="font-mono text-xs text-slate-400">
                        Depth {engineLines[0]?.depth ?? 16} · {displayAnalysisFen.split(" ")[1] === "w" ? "White" : "Black"} to move
                      </span>
                    </div>
                    {engineLines.length === 0 ? (
                      <div className="py-6 text-center text-xs text-slate-500 font-mono">Terminal position — no legal continuations.</div>
                    ) : (
                      engineLines.map((line) => (
                        <button
                          key={line.multipv}
                          onClick={() => line.bestMoveSan && playSanOnAnalysis(line.bestMoveSan)}
                          className="w-full text-left p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-emerald-500/60 transition-all"
                        >
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded font-mono text-xs font-extrabold ${line.scoreCp >= 0 ? "bg-slate-100 text-slate-900" : "bg-[#35312C] text-slate-100 border border-slate-600"}`}>
                              {line.mateIn !== null ? `M${Math.abs(line.mateIn)}` : `${line.scoreCp > 0 ? "+" : ""}${(line.scoreCp / 100).toFixed(2)}`}
                            </span>
                            <span className="font-mono text-xs text-slate-200">{line.pvSan.join(" ")}</span>
                            <span className="ml-auto text-[10px] font-mono text-emerald-400">▶ play</span>
                          </div>
                        </button>
                      ))
                    )}
                    <p className="text-[11px] text-slate-500 leading-relaxed">
                      Green arrow = engine best move · Blue = second line · Red (in Review) = what should have been played. Click any line to play it.
                    </p>
                  </div>
                )}

                {analysisTab === "opening" && (
                  <OpeningExplorerPanel fen={displayAnalysisFen} onPlayBookMove={playSanOnAnalysis} />
                )}

                {analysisTab === "review" &&
                  (review ? (
                    <EvalGraphAndReview
                      review={review}
                      currentPly={viewPly}
                      onSelectPly={setViewPly}
                      whiteName={reviewNames.w}
                      blackName={reviewNames.b}
                      onRetryMistake={(ply) => {
                        const p = review.plies[ply - 1];
                        if (p) {
                          setRetry({ ply, bestSan: p.bestMoveSan, fenBefore: p.fenBefore });
                          setRetryFeedback(null);
                          showToast(`Retry: find a better move than ${p.san} (${p.classification})`);
                        }
                      }}
                    />
                  ) : (
                    <div className="py-8 text-center space-y-2">
                      <div className="text-3xl">🔍</div>
                      <p className="text-xs text-slate-400">
                        No review loaded yet. Paste a PGN below or choose a game from your archive, then run Game Review for accuracy %, move classifications (!! → ??) and key moments.
                      </p>
                    </div>
                  ))}

                {/* PGN / FEN Import-Export */}
                <div className="pt-2 border-t border-[#3A3733] space-y-2">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-amber-400" /> PGN / FEN Import & Export
                  </div>
                  <textarea
                    value={importText}
                    onChange={(e) => setImportText(e.target.value)}
                    rows={4}
                    className="w-full px-3 py-2 rounded-xl bg-[#201D1B] border border-[#3A3733] font-mono text-[11px] text-slate-200"
                    placeholder="Paste a PGN (1. e4 e5 …) or a FEN position…"
                  />
                  <div className="flex flex-wrap gap-2">
                    <button
                      onClick={() => {
                        if (importText.includes("/") && !/^\s*1\./.test(importText)) {
                          try {
                            const c = new Chess(importText.trim());
                            setReview(null);
                            setAnalysisSans([]);
                            setAnalysisFens([c.fen()]);
                            setViewPly(0);
                            setAnalysisFen(c.fen());
                            showToast("FEN position loaded ✓");
                          } catch {
                            showToast("Invalid FEN string");
                          }
                        } else {
                          loadPgnIntoAnalysis(importText);
                          showToast("PGN loaded on analysis board ✓");
                        }
                      }}
                      className="px-3 py-2 rounded-xl bg-[#35312C] border border-[#4A463F] text-xs font-semibold"
                    >
                      Load on board
                    </button>
                    <button
                      onClick={() => runReview(importText, "White (import)", "Black (import)")}
                      disabled={reviewBusy}
                      className="px-3 py-2 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold disabled:opacity-50 flex items-center gap-1.5"
                    >
                      {reviewBusy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                      Run Game Review
                    </button>
                    <button onClick={saveImportedGame} className="px-3 py-2 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-semibold">
                      Save to archive
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <button onClick={() => copyText(analysisPgn || liveGame?.pgn || importText, "PGN")} className="px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] font-mono flex items-center gap-1"><Copy className="w-3 h-3" /> Copy PGN</button>
                    <button onClick={() => copyText(displayAnalysisFen, "FEN")} className="px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] font-mono flex items-center gap-1"><Copy className="w-3 h-3" /> Copy FEN</button>
                    <button onClick={() => downloadPgn(analysisPgn || importText, "obsidian-analysis.pgn")} className="px-2.5 py-1.5 rounded-lg bg-[#201D1B] border border-[#3A3733] text-[11px] font-mono flex items-center gap-1"><Download className="w-3 h-3" /> Download .pgn</button>
                    {liveGame?.pgn && (
                      <button onClick={() => runReview(liveGame.pgn, liveGame.whitePlayer.username, liveGame.blackPlayer.username)} className="px-2.5 py-1.5 rounded-lg bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 text-[11px] font-mono">
                        Review my live game
                      </button>
                    )}
                  </div>
                  <div className="font-mono text-[10px] text-slate-500 break-all p-2 rounded-lg bg-[#201D1B] border border-[#33302C]">
                    FEN: {displayAnalysisFen}
                  </div>
                </div>

                {/* Archive */}
                <div className="pt-2 border-t border-[#3A3733]">
                  <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
                    📚 Game archive ({games.length}) — click to review
                  </div>
                  <div className="space-y-1.5 max-h-56 overflow-y-auto pr-1">
                    {games.map((g) => (
                      <button
                        key={g.id}
                        onClick={() => openGameInAnalysis(g)}
                        className="w-full text-left p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-emerald-500/50 transition-all"
                      >
                        <div className="flex justify-between text-xs">
                          <span className="font-semibold text-slate-200 truncate">
                            {g.whitePlayer.username} vs {g.blackPlayer.username}
                          </span>
                          <span className="font-mono font-bold text-emerald-400 shrink-0">{g.result}</span>
                        </div>
                        <div className="text-[11px] font-mono text-slate-400 truncate mt-0.5">
                          {g.timeControl} · {g.openingName} · Acc {g.whiteAccuracy ?? "—"}% / {g.blackAccuracy ?? "—"}%
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ================= PUZZLES ================= */}
          {tab === "puzzles" && currentUser && (
            <PuzzlesWorkspace
              puzzles={puzzles}
              userPuzzleRating={currentUser.puzzleRating}
              userPuzzleRd={currentUser.puzzleRd}
              puzzleRushBest={currentUser.puzzleRushBest}
              userId={currentUser.id}
              boardTheme={boardTheme}
              onPuzzleSolved={(newRating, delta) => {
                setUsers((prev) =>
                  prev.map((u) => (u.id === currentUser.id ? { ...u, puzzleRating: newRating } : u))
                );
                showToast(delta >= 0 ? `Puzzle rating +${delta} → ${newRating} 🎉` : `Puzzle rating ${delta} → ${newRating}`);
              }}
              onRushBestUpdated={(best) => {
                setUsers((prev) =>
                  prev.map((u) => (u.id === currentUser.id ? { ...u, puzzleRushBest: best } : u))
                );
                showToast(`🔥 New Puzzle Rush record: ${best}!`);
              }}
              onRefreshData={() => fetchOverview()}
            />
          )}

          {/* ================= COMMUNITY ================= */}
          {tab === "community" && currentUser && (
            <CommunityWorkspace
              currentUser={currentUser}
              users={users}
              games={games}
              challenges={challenges}
              friendIds={friendIds}
              onAcceptChallenge={handleAcceptChallenge}
              onDeclineChallenge={handleDeclineChallenge}
              onCreateChallenge={handleCreateChallenge}
              onToggleFriend={handleToggleFriend}
              onOpenGameInAnalysis={openGameInAnalysis}
              onDeleteGame={handleDeleteGame}
              onStartDirectMatch={(opponentId, tc) => startGame({ opponentId, tc })}
            />
          )}

          {/* ================= ARCHITECTURE ================= */}
          {tab === "architecture" && (
            <ArchitectureWorkspace
              wsLogs={wsLogs}
              activeLiveGamesCount={liveCount}
              onRefreshLogs={() => fetchOverview()}
            />
          )}
        </div>

        <footer className="px-5 pb-6 text-center text-[11px] font-mono text-slate-600">
          ObsidianChess.io — Next.js + Socket.io + Prisma (SQLite dev / PostgreSQL prod schema included) · Chess.js rules · Glicko-2 · Multi-PV engine with CAPS accuracy
        </footer>
      </main>

      {/* ============ MOBILE BOTTOM TAB BAR (professional app nav) ============ */}
      <nav className="lg:hidden fixed bottom-0 inset-x-0 z-50 bg-[#262321]/97 backdrop-blur border-t border-[#3A3733] pb-[env(safe-area-inset-bottom)]">
        <div className="grid grid-cols-5">
          {tabs
            .filter((t) => ["home", "play", "computer", "puzzles", "analysis"].includes(t.key))
            .map((t) => (
              <button
                key={t.key}
                onClick={() => setTab(t.key)}
                className={`relative flex flex-col items-center justify-center gap-0.5 py-2.5 text-[10px] font-semibold transition-colors ${
                  tab === t.key ? "text-[#BCE08A]" : "text-stone-400"
                }`}
              >
                {tab === t.key && <span className="absolute top-0 inset-x-6 h-0.5 rounded-full bg-[#81B64C]" />}
                <span className="[&_svg]:w-5 [&_svg]:h-5">{t.icon}</span>
                {t.short}
                {!isOnline && !t.offlineOk && <span className="absolute top-1.5 right-3 w-1.5 h-1.5 rounded-full bg-amber-500" title="Online only" />}
                {t.key === "play" && liveGame?.status === "active" && (
                  <span className="absolute top-1.5 right-3 w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
                )}
              </button>
            ))}
        </div>
        {/* Docked green Play CTA above the tab bar, Chess.com-style — Home only */}
        {tab === "home" && (
          <div className="absolute -top-[68px] inset-x-3">
            <button
              onClick={() => (isOnline ? startGame({ tc: "3+2" }) : setTab("computer"))}
              className="w-full py-3.5 rounded-2xl bg-[#81B64C] text-white font-display font-bold text-base shadow-[0_6px_0_#457A26,0_14px_28px_rgba(0,0,0,0.5)] active:translate-y-1 active:shadow-[0_2px_0_#457A26]"
            >
              ▶ {isOnline ? "New Game" : "Play vs Computer (offline)"}
            </button>
          </div>
        )}
      </nav>

      {/* ============ AUTH MODAL ============ */}
      {showAuth && <AuthModal users={users} onSignIn={signInAs} onClose={() => setShowAuth(false)} onRegistered={(id) => { fetchOverview(id); signInAs(id); }} signedIn={signedIn} />}

      {/* ============ PROFILE MODAL ============ */}
      {showProfile && currentUser && (
        <ProfileModal
          user={currentUser}
          onClose={() => setShowProfile(false)}
          onSaved={() => { setShowProfile(false); fetchOverview(); showToast("Profile updated ✅"); }}
        />
      )}

      {/* Toast */}
      {toast && (
        <div className="fixed bottom-5 left-1/2 -translate-x-1/2 z-[60] px-4 py-2.5 rounded-2xl bg-[#161E2C] border border-emerald-500/50 shadow-2xl text-sm text-slate-100 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-400 shrink-0" /> {toast}
        </div>
      )}
    </div>
  );
}

/* ================= Auth Modal ================= */
function AuthModal({
  users,
  onSignIn,
  onClose,
  onRegistered,
  signedIn,
}: {
  users: PlatformUser[];
  onSignIn: (id: string) => void;
  onClose: () => void;
  onRegistered: (id: string) => void;
  signedIn: boolean;
}) {
  const [mode, setMode] = useState<"signin" | "register">("signin");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [title, setTitle] = useState("");
  const [country, setCountry] = useState("NG");
  const [avatar, setAvatar] = useState("♔");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const register = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch("/api/users", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "register", username, email, title: title || undefined, country, avatar }),
      });
      const data = await res.json();
      if (!res.ok) setError(data.error || "Registration failed");
      else onRegistered(data.user.id);
    } catch {
      setError("Network error");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#2B2825] border border-[#3A3733] rounded-3xl max-w-lg w-full p-6 shadow-2xl">
        <div className="text-center">
          <div className="text-5xl">♔</div>
          <h2 className="font-display text-2xl font-bold mt-2">
            Obsidian<span className="text-emerald-400">Chess</span>.io
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Real-time chess with Glicko-2 ratings, engine Game Review, tactical puzzles & Puzzle Rush.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-[#201D1B] border border-[#3A3733] mt-4">
          <button onClick={() => setMode("signin")} className={`py-2 rounded-lg text-xs font-bold ${mode === "signin" ? "bg-emerald-500 text-slate-950" : "text-slate-400"}`}>Sign in</button>
          <button onClick={() => setMode("register")} className={`py-2 rounded-lg text-xs font-bold ${mode === "register" ? "bg-emerald-500 text-slate-950" : "text-slate-400"}`}>Create account</button>
        </div>

        {mode === "signin" ? (
          <div className="mt-4 space-y-2 max-h-72 overflow-y-auto pr-1">
            <p className="text-[11px] font-mono uppercase text-slate-500">One-click demo accounts (password-free sandbox auth)</p>
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => onSignIn(u.id)}
                className="w-full flex items-center justify-between p-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] hover:border-emerald-500/60 text-left transition-all"
              >
                <span className="flex items-center gap-2.5">
                  <span className="w-9 h-9 rounded-lg bg-[#35312C] flex items-center justify-center">{u.avatar}</span>
                  <span>
                    <span className="block text-sm font-semibold">{u.title ? `${u.title} ` : ""}{u.username}</span>
                    <span className="block text-[11px] text-slate-500 font-mono">Blitz {u.blitzRating} · Tactics {u.puzzleRating}</span>
                  </span>
                </span>
                <LogIn className="w-4 h-4 text-emerald-400" />
              </button>
            ))}
          </div>
        ) : (
          <form onSubmit={register} className="mt-4 space-y-2.5">
            <input required value={username} onChange={(e) => setUsername(e.target.value)} placeholder="Username (e.g. LagosKnight)" className="w-full px-3 py-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] text-sm" />
            <input required type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" className="w-full px-3 py-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] text-sm" />
            <div className="grid grid-cols-3 gap-2">
              <select value={title} onChange={(e) => setTitle(e.target.value)} className="px-2 py-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] text-sm">
                <option value="">No title</option>
                {["GM", "IM", "FM", "WGM", "NM", "CM"].map((t) => <option key={t}>{t}</option>)}
              </select>
              <input value={country} onChange={(e) => setCountry(e.target.value)} placeholder="Country (NG)" className="px-3 py-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] text-sm" />
              <select value={avatar} onChange={(e) => setAvatar(e.target.value)} className="px-2 py-2.5 rounded-xl bg-[#201D1B] border border-[#3A3733] text-lg">
                {["♔", "♕", "♜", "♗", "♘", "♙", "⚡", "👑", "🔥", "🎯"].map((a) => <option key={a}>{a}</option>)}
              </select>
            </div>
            <p className="text-[11px] text-slate-500">New accounts start at 1500 (Glicko-2, RD ±110) in Bullet/Blitz/Rapid and 1600 in Puzzles.</p>
            {error && <div className="p-2.5 rounded-lg bg-rose-950/60 border border-rose-500/50 text-xs text-rose-200">{error}</div>}
            <button disabled={busy} className="w-full py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-sm disabled:opacity-50">
              {busy ? "Creating…" : "Create account & play ♟️"}
            </button>
          </form>
        )}

        {signedIn && (
          <button onClick={onClose} className="w-full mt-3 py-2 rounded-xl bg-[#35312C] text-xs text-slate-300">Continue as current user</button>
        )}
      </div>
    </div>
  );
}

/* ================= Profile Modal ================= */
function ProfileModal({
  user,
  onClose,
  onSaved,
}: {
  user: PlatformUser;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [username, setUsername] = useState(user.username);
  const [title, setTitle] = useState(user.title || "");
  const [country, setCountry] = useState(user.country);
  const [avatar, setAvatar] = useState(user.avatar);
  const [bio, setBio] = useState(user.bio);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch("/api/users", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "update", userId: user.id, username, title, country, avatar, bio }),
    });
    onSaved();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#2B2825] border border-[#3A3733] rounded-2xl max-w-md w-full p-5 shadow-2xl">
        <div className="flex items-center justify-between border-b border-[#3A3733] pb-3">
          <h3 className="font-display font-bold flex items-center gap-2"><UserRound className="w-4 h-4 text-emerald-400" /> Edit profile</h3>
          <button onClick={onClose} className="text-xs text-slate-400">✕ Close</button>
        </div>
        <form onSubmit={save} className="space-y-3 mt-3">
          <label className="block text-xs text-slate-400">Username
            <input value={username} onChange={(e) => setUsername(e.target.value)} className="w-full mt-1 px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-sm text-slate-100" />
          </label>
          <div className="grid grid-cols-3 gap-2">
            <label className="block text-xs text-slate-400">Title
              <select value={title} onChange={(e) => setTitle(e.target.value)} className="w-full mt-1 px-2 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-sm">
                <option value="">None</option>
                {["GM", "IM", "FM", "WGM", "NM", "CM"].map((t) => <option key={t}>{t}</option>)}
              </select>
            </label>
            <label className="block text-xs text-slate-400">Country
              <input value={country} onChange={(e) => setCountry(e.target.value)} className="w-full mt-1 px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-sm" />
            </label>
            <label className="block text-xs text-slate-400">Avatar
              <select value={avatar} onChange={(e) => setAvatar(e.target.value)} className="w-full mt-1 px-2 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-lg">
                {["♔", "♕", "♜", "♗", "♘", "♙", "⚡", "👑", "🔥", "🎯"].map((a) => <option key={a}>{a}</option>)}
              </select>
            </label>
          </div>
          <label className="block text-xs text-slate-400">Bio
            <textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} className="w-full mt-1 px-3 py-2 rounded-lg bg-[#201D1B] border border-[#3A3733] text-sm" />
          </label>
          <div className="grid grid-cols-4 gap-2 text-center font-mono text-xs">
            <div className="p-2 rounded-lg bg-[#201D1B]">Bullet<br /><b className="text-emerald-400 text-base">{user.bulletRating}</b></div>
            <div className="p-2 rounded-lg bg-[#201D1B]">Blitz<br /><b className="text-emerald-400 text-base">{user.blitzRating}</b></div>
            <div className="p-2 rounded-lg bg-[#201D1B]">Rapid<br /><b className="text-emerald-400 text-base">{user.rapidRating}</b></div>
            <div className="p-2 rounded-lg bg-[#201D1B]">Puzzles<br /><b className="text-amber-400 text-base">{user.puzzleRating}</b></div>
          </div>
          <div className="flex justify-end gap-2">
            <button type="button" onClick={onClose} className="px-4 py-2 rounded-lg bg-[#35312C] text-xs">Cancel</button>
            <button className="px-4 py-2 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs">Save profile</button>
          </div>
        </form>
      </div>
    </div>
  );
}
