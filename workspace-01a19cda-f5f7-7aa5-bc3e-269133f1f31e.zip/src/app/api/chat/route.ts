import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { moderateChatMessage } from "@/lib/moderation";

export async function GET(req: NextRequest) {
  const gameId = req.nextUrl.searchParams.get("gameId");
  if (!gameId) {
    return NextResponse.json({ messages: [] });
  }
  const messages = await prisma.chatMessage.findMany({
    where: { gameId },
    orderBy: { createdAt: "asc" },
  });
  return NextResponse.json({ messages });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action = "send" } = body;

    if (action === "send") {
      const { gameId, senderId, senderName, text, opponentName, opponentIsAi } = body;
      const mod = moderateChatMessage(text || "");
      if (!mod.cleanText) {
        return NextResponse.json({ error: "Empty message" }, { status: 400 });
      }

      const userMsg = await prisma.chatMessage.create({
        data: {
          gameId,
          senderId,
          senderName,
          text: mod.cleanText,
          flagged: mod.flagged,
          reactionsJson: "{}",
        },
      });

      const messages = [userMsg];

      // If playing against a titled AI opponent, generate a contextual grandmaster reply!
      if (opponentIsAi && opponentName) {
        const lower = mod.cleanText.toLowerCase();
        let replyText = " Sharp position! Let's calculate carefully. ♟️";
        if (lower.includes("gg") || lower.includes("good game")) {
          replyText = "Good game! Well fought on both sides 🤝";
        } else if (lower.includes("gl") || lower.includes("luck") || lower.includes("hi") || lower.includes("hello")) {
          replyText = `Have a great game! May the sharpest tactics win 🔥`;
        } else if (lower.includes("blunder") || lower.includes("mistake")) {
          replyText = "Chess is a game of who makes the second-to-last mistake 😅";
        } else if (opponentName.includes("Gotham") || opponentName.includes("Levy")) {
          replyText = "Watch out for the Rook sacrifice on move 20! ♜🔥";
        } else if (opponentName.includes("Hikaru")) {
          replyText = "Takes, takes, takes, and then we centralize the knight ⚡";
        } else if (opponentName.includes("DrNykterstein")) {
          replyText = "The endgame is where the truth of the position emerges 👑";
        }

        const aiMsg = await prisma.chatMessage.create({
          data: {
            gameId,
            senderId: "ai-opponent",
            senderName: opponentName,
            text: replyText,
            flagged: false,
            reactionsJson: JSON.stringify({ "🔥": 1 }),
          },
        });
        messages.push(aiMsg);
      }

      return NextResponse.json({
        messages,
        moderationNotice: mod.reason,
      });
    }

    if (action === "react") {
      const { messageId, emoji } = body;
      const msg = await prisma.chatMessage.findUnique({
        where: { id: messageId },
      });
      if (!msg) {
        return NextResponse.json(
          { error: "Message not found" },
          { status: 404 }
        );
      }

      let reactions: Record<string, number> = {};
      try {
        reactions = JSON.parse(msg.reactionsJson || "{}");
      } catch {
        reactions = {};
      }
      reactions[emoji] = (reactions[emoji] || 0) + 1;

      const updated = await prisma.chatMessage.update({
        where: { id: messageId },
        data: { reactionsJson: JSON.stringify(reactions) },
      });

      return NextResponse.json({ message: updated });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: unknown) {
    console.error("Chat API error:", err);
    return NextResponse.json(
      { error: "Failed to process chat message" },
      { status: 500 }
    );
  }
}
