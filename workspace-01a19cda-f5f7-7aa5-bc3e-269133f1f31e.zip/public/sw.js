/* ObsidianChess.io — offline service worker (hand-written, no build deps)
 *
 * Strategy (mirrors professional chess PWAs):
 *  - App shell & hashed Next.js chunks ... CacheFirst (immutable)
 *  - Page navigations ..................... NetworkFirst -> cached shell
 *  - /api/overview, /api/puzzles (GET) .... NetworkFirst -> last response
 *  - Google Fonts ......................... StaleWhileRevalidate
 *  - Socket.io / POST mutations ........... NetworkOnly (online-only)
 */
const VERSION = "obsidian-chess-v2";
const SHELL_CACHE = VERSION + "-shell";
const STATIC_CACHE = VERSION + "-static";
const API_CACHE = VERSION + "-api";
const FONT_CACHE = VERSION + "-fonts";

const APP_SHELL = ["/", "/manifest.webmanifest", "/icons/icon-192.png", "/icons/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(SHELL_CACHE)
      .then((cache) => cache.addAll(APP_SHELL))
      .then(() => self.skipWaiting())
      .catch(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys
            .filter((k) => k.indexOf(VERSION) !== 0)
            .map((k) => caches.delete(k))
        )
      )
      .then(() => self.clients.claim())
  );
});

function putInCache(cacheName, request, response) {
  if (!response || response.status !== 200) return response;
  const clone = response.clone();
  caches.open(cacheName).then((cache) => cache.put(request, clone)).catch(() => {});
  return response;
}

self.addEventListener("fetch", (event) => {
  const request = event.request;
  const url = new URL(request.url);

  // Online-only: mutations, websockets, chrome extensions
  if (request.method !== "GET") return;
  if (url.pathname.startsWith("/socket.io")) return;
  if (url.protocol !== "http:" && url.protocol !== "https:") return;

  // Google Fonts — stale while revalidate so typography survives offline
  if (url.hostname === "fonts.googleapis.com" || url.hostname === "fonts.gstatic.com") {
    event.respondWith(
      caches.open(FONT_CACHE).then((cache) =>
        cache.match(request).then((cached) => {
          const network = fetch(request)
            .then((res) => {
              if (res && (res.status === 200 || res.type === "opaque")) {
                cache.put(request, res.clone()).catch(() => {});
              }
              return res;
            })
            .catch(() => cached);
          return cached || network;
        })
      )
    );
    return;
  }

  if (url.origin !== self.location.origin) return;

  // Hashed Next.js build assets — immutable, cache first
  if (
    url.pathname.startsWith("/_next/static/") ||
    url.pathname.startsWith("/icons/") ||
    /\.(?:png|svg|ico|woff2?)$/.test(url.pathname)
  ) {
    event.respondWith(
      caches.match(request).then(
        (cached) => cached || fetch(request).then((res) => putInCache(STATIC_CACHE, request, res))
      )
    );
    return;
  }

  // Read APIs that power offline data — network first, cache fallback
  if (url.pathname === "/api/overview" || url.pathname === "/api/puzzles" || url.pathname === "/api/games") {
    event.respondWith(
      fetch(request)
        .then((res) => putInCache(API_CACHE, request, res))
        .catch(() =>
          caches
            .match(request)
            .then(
              (cached) =>
                cached ||
                new Response(JSON.stringify({ offline: true, error: "offline" }), {
                  status: 503,
                  headers: { "Content-Type": "application/json" },
                })
            )
        )
    );
    return;
  }

  // Page navigations / RSC payloads — network first, then cached app shell
  if (request.mode === "navigate" || url.search.indexOf("_rsc") !== -1) {
    event.respondWith(
      fetch(request)
        .then((res) => {
          if (request.mode === "navigate") putInCache(SHELL_CACHE, "/", res.clone());
          return res;
        })
        .catch(() =>
          caches
            .match(request)
            .then((cached) => cached || caches.match("/"))
            .then((shell) => shell || new Response("Offline", { status: 503 }))
        )
    );
    return;
  }

  // Everything else same-origin — stale while revalidate
  event.respondWith(
    caches.match(request).then((cached) => {
      const network = fetch(request)
        .then((res) => putInCache(STATIC_CACHE, request, res))
        .catch(() => cached);
      return cached || network;
    })
  );
});
