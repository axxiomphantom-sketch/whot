import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "ObsidianChess.io — Play, Puzzles & Engine Review",
    short_name: "ObsidianChess",
    description:
      "Play live chess online, or offline against the computer. Tactical puzzles, Puzzle Rush, engine Game Review and opening explorer.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    orientation: "portrait",
    background_color: "#201D1B",
    theme_color: "#81B64C",
    categories: ["games", "entertainment", "education"],
    icons: [
      {
        src: "/icons/icon-192.png",
        sizes: "192x192",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "any",
      },
      {
        src: "/icons/icon-512.png",
        sizes: "512x512",
        type: "image/png",
        purpose: "maskable",
      },
    ],
  };
}
