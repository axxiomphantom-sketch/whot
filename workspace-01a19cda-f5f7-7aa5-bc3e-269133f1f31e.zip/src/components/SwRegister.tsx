"use client";

import { useEffect } from "react";

/**
 * Registers the hand-written service worker (/sw.js) that precaches the
 * app shell so ObsidianChess.io installs as a PWA and boots fully offline.
 * Registration is production-only and fails silently on unsupported
 * browsers / insecure contexts (offline then degrades gracefully).
 */
export default function SwRegister() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    if (!("serviceWorker" in navigator)) return;
    if (process.env.NODE_ENV !== "production") return;

    const register = () => {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .then((reg) => {
          // Check for a fresher shell whenever the user returns online.
          const onOnline = () => reg.update().catch(() => undefined);
          window.addEventListener("online", onOnline);
        })
        .catch(() => undefined);
    };

    if (document.readyState === "complete") register();
    else window.addEventListener("load", register, { once: true });
  }, []);

  return null;
}
