"use client";

import React, { useMemo } from "react";
import { Chess } from "chess.js";
import { Wifi, Bot } from "lucide-react";

interface PlayerHudBarProps {
  username: string;
  title?: string | null;
  avatar?: string;
  rating: number;
  rd?: number;
  ratingDelta?: number;
  isAi?: boolean;
  connected?: boolean;
  color: "w" | "b";
  isActiveTurn: boolean;
  timeRemainingMs: number;
  fen: string;
  showClock?: boolean;
}

const PIECE_SYMBOLS: Record<string, string> = {
  q: "♛",
  r: "♜",
  b: "♝",
  n: "♞",
  p: "♟",
};

const PIECE_VALS: Record<string, number> = {
  q: 9,
  r: 5,
  b: 3,
  n: 3,
  p: 1,
};

export function formatChessClock(ms: number): string {
  const clamped = Math.max(0, ms);
  if (clamped >= 3600 * 1000) {
    const hrs = Math.floor(clamped / (3600 * 1000));
    const mins = Math.floor((clamped % (3600 * 1000)) / 60000);
    return `${hrs}h ${mins}m`;
  }
  const totalSeconds = Math.floor(clamped / 1000);
  const mins = Math.floor(totalSeconds / 60);
  const secs = totalSeconds % 60;
  if (clamped < 20000 && clamped > 0) {
    const tenths = Math.floor((clamped % 1000) / 100);
    return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}.${tenths}`;
  }
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}

export const PlayerHudBar: React.FC<PlayerHudBarProps> = ({
  username,
  title,
  avatar = "♔",
  rating,
  rd,
  ratingDelta,
  isAi = false,
  connected = true,
  color,
  isActiveTurn,
  timeRemainingMs,
  fen,
  showClock = true,
}) => {
  // Calculate captured pieces and material advantage from current FEN
  const { capturedIcons, advantage } = useMemo(() => {
    try {
      const chess = new Chess(fen);
      const board = chess.board();
      const counts = {
        w: { q: 0, r: 0, b: 0, n: 0, p: 0 },
        b: { q: 0, r: 0, b: 0, n: 0, p: 0 },
      };
      for (let r = 0; r < 8; r++) {
        for (let c = 0; c < 8; c++) {
          const p = board[r][c];
          if (p && p.type !== "k") {
            counts[p.color][p.type as "q" | "r" | "b" | "n" | "p"]++;
          }
        }
      }

      const startCounts = { q: 1, r: 2, b: 2, n: 2, p: 8 };
      const oppColor = color === "w" ? "b" : "w";
      const icons: string[] = [];

      (["q", "r", "b", "n", "p"] as const).forEach((t) => {
        const missing = Math.max(0, startCounts[t] - counts[oppColor][t]);
        for (let i = 0; i < missing; i++) {
          icons.push(PIECE_SYMBOLS[t]);
        }
      });

      const wMat = (["q", "r", "b", "n", "p"] as const).reduce(
        (acc, t) => acc + counts.w[t] * PIECE_VALS[t],
        0
      );
      const bMat = (["q", "r", "b", "n", "p"] as const).reduce(
        (acc, t) => acc + counts.b[t] * PIECE_VALS[t],
        0
      );

      const diff = color === "w" ? wMat - bMat : bMat - wMat;
      return {
        capturedIcons: icons.slice(0, 12),
        advantage: diff > 0 ? diff : 0,
      };
    } catch {
      return { capturedIcons: [], advantage: 0 };
    }
  }, [fen, color]);

  const isLowTime = timeRemainingMs > 0 && timeRemainingMs < 20000;

  return (
    <div
      className={`flex items-center justify-between px-3.5 py-2.5 rounded-xl border transition-all max-w-[660px] w-full mx-auto ${
        isActiveTurn
          ? "bg-[#161C28] border-emerald-500/50 shadow-[0_0_20px_rgba(16,185,129,0.12)]"
          : "bg-[#2B2825] border-[#3A3733]"
      }`}
    >
      {/* Left: Avatar + Name + Title + Rating + Captured Pieces */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="relative">
          <div
            className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg font-bold border ${
              color === "w"
                ? "bg-slate-100 text-slate-900 border-slate-300"
                : "bg-[#35312C] text-slate-100 border-[#4A463F]"
            }`}
          >
            {avatar}
          </div>
          <span
            className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-[#2B2825] ${
              connected ? "bg-emerald-500" : "bg-amber-500 animate-ping"
            }`}
            title={connected ? "Connected via WebSocket (0ms jitter)" : "Reconnecting..."}
          />
        </div>

        <div className="min-w-0">
          <div className="flex items-center gap-1.5 flex-wrap">
            {title && (
              <span className="px-1.5 py-0.5 text-[10px] font-mono font-extrabold uppercase rounded bg-amber-500/20 text-amber-400 border border-amber-500/40 leading-none">
                {title}
              </span>
            )}
            <span className="font-semibold text-sm text-slate-100 truncate">
              {username}
            </span>
            <span className="font-mono text-xs text-slate-400">
              ({rating}
              {rd ? ` ±${Math.round(rd)}` : ""})
            </span>
            {typeof ratingDelta === "number" && ratingDelta !== 0 && (
              <span
                className={`font-mono text-xs font-bold ${
                  ratingDelta > 0 ? "text-emerald-400" : "text-rose-400"
                }`}
              >
                {ratingDelta > 0 ? `+${ratingDelta}` : ratingDelta}
              </span>
            )}
            {isAi ? (
              <span className="inline-flex items-center gap-0.5 px-1.5 py-0.5 rounded text-[10px] font-mono bg-indigo-500/15 text-indigo-300 border border-indigo-500/30">
                <Bot className="w-2.5 h-2.5" /> Engine
              </span>
            ) : (
              <Wifi className="w-3 h-3 text-emerald-400/80" />
            )}
          </div>

          {/* Captured Pieces & Material Differential */}
          <div className="flex items-center gap-1.5 mt-0.5 h-4">
            {capturedIcons.length > 0 ? (
              <span className="text-xs tracking-tighter text-slate-300 font-sans">
                {capturedIcons.join("")}
              </span>
            ) : (
              <span className="text-[11px] text-slate-500 font-mono">
                Equal material
              </span>
            )}
            {advantage > 0 && (
              <span className="px-1.5 py-0.2 rounded bg-emerald-500/15 text-emerald-400 font-mono text-[10px] font-bold">
                +{advantage}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Right: High-Precision Tabular-Nums Digital Chess Clock */}
      {showClock && (
        <div
          className={`px-3.5 py-1.5 rounded-lg font-mono text-xl font-bold tracking-tight tabular-nums border transition-all ${
            isActiveTurn
              ? isLowTime
                ? "bg-rose-950/80 border-rose-500 text-rose-300 animate-pulse shadow-[0_0_15px_rgba(244,63,94,0.35)]"
                : "bg-emerald-950/50 border-emerald-500/60 text-emerald-300"
              : "bg-[#201D1B] border-[#3A3733] text-slate-400"
          }`}
        >
          {formatChessClock(timeRemainingMs)}
        </div>
      )}
    </div>
  );
};
