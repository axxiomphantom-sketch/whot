import { NextRequest, NextResponse } from "next/server";
import { Chess } from "chess.js";
import { prisma } from "@/lib/prisma";
import { redisStore } from "@/lib/redisStore";
import {
  createLiveGameSession,
  processMoveInGame,
  finalizeGameSession,
  triggerBotReplyIfNeeded,
} from "@/lib/gameManager";
import { runFullGameReview } from "@/lib/engine";

export async function GET(req: NextRequest) {
  const gameId = req.nextUrl.searchParams.get("gameId");
  if (gameId) {
    const live = redisStore.liveGames.get(gameId);
    const dbGame = await prisma.game.findUnique({
      where: { id: gameId },
      include: {
        whitePlayer: true,
        blackPlayer: true,
        messages: { orderBy: { createdAt: "asc" } },
      },
    });
    return NextResponse.json({ live, dbGame });
  }

  const games = await prisma.game.findMany({
    orderBy: { createdAt: "desc" },
    take: 30,
    include: { whitePlayer: true, blackPlayer: true },
  });
  return NextResponse.json({ games });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { action } = body;

    // 1. Start a new live game
    if (action === "create") {
      const {
        userId = "user-ademola",
        opponentId,
        timeControl = "3+2",
        rated = true,
        colorPref = "random",
        customFen,
      } = body;

      let chosenOpponentId = opponentId;
      if (!chosenOpponentId) {
        const user = await prisma.user.findUnique({ where: { id: userId } });
        const candidates = await prisma.user.findMany({
          where: { id: { not: userId } },
        });
        if (user && candidates.length > 0) {
          candidates.sort(
            (a, b) =>
              Math.abs(a.blitzRating - user.blitzRating) -
              Math.abs(b.blitzRating - user.blitzRating)
          );
          chosenOpponentId = candidates[0].id;
        } else {
          chosenOpponentId = "user-levy";
        }
      }

      const playWhite =
        colorPref === "white"
          ? true
          : colorPref === "black"
          ? false
          : Math.random() >= 0.5;

      const liveSession = await createLiveGameSession({
        whiteUserId: playWhite ? userId : chosenOpponentId,
        blackUserId: playWhite ? chosenOpponentId : userId,
        timeControl,
        rated,
        customFen,
      });

      // If White is an AI bot, let it make the opening move immediately
      if (liveSession.whitePlayer.isAi) {
        await triggerBotReplyIfNeeded(liveSession.id);
      }

      return NextResponse.json({
        gameState: redisStore.liveGames.get(liveSession.id) || liveSession,
      });
    }

    // 2. Make a move via REST fallback / sync
    if (action === "move") {
      const { gameId, from, to, promotion } = body;
      const res = await processMoveInGame(gameId, { from, to, promotion });
      if (!res.success || !res.gameState) {
        return NextResponse.json(
          { error: res.error || "Illegal move" },
          { status: 400 }
        );
      }

      // If opponent is AI and game is still active, also compute bot reply if requested
      if (body.autoBotReply && res.gameState.status === "active") {
        const botState = await triggerBotReplyIfNeeded(gameId);
        if (botState) {
          return NextResponse.json({ gameState: botState });
        }
      }

      return NextResponse.json({ gameState: res.gameState });
    }

    // 3. Import a PGN or FEN into persistent Game Archive for Review
    if (action === "import") {
      const {
        userId = "user-ademola",
        opponentId = "user-magnus",
        pgn,
        fen,
        openingName = "Imported Custom Analysis Game",
        timeControl = "10+0",
      } = body;

      const chess = new Chess();
      if (pgn && pgn.trim()) {
        try {
          chess.loadPgn(pgn.trim());
        } catch {
          const tokens = pgn
            .trim()
            .split(/\s+/)
            .filter((t: string) => t && !/^\d+\./.test(t));
          for (const t of tokens) {
            try {
              chess.move(t);
            } catch {
              break;
            }
          }
        }
      } else if (fen && fen.trim()) {
        chess.load(fen.trim());
      }

      const review = runFullGameReview(chess.pgn() || pgn || "");
      const evalHistory = review.plies.map((p) => p.evalAfter);

      const importedGame = await prisma.game.create({
        data: {
          whitePlayerId: userId,
          blackPlayerId: opponentId,
          pgn: chess.pgn() || pgn || "",
          fen: chess.fen(),
          result: chess.isCheckmate()
            ? chess.turn() === "w"
              ? "0-1"
              : "1-0"
            : "1/2-1/2",
          termination: "imported_analysis",
          timeControl,
          category: "rapid",
          rated: false,
          whiteAccuracy: review.whiteAccuracy,
          blackAccuracy: review.blackAccuracy,
          openingEco: review.openingEco,
          openingName,
          evalHistoryJson: JSON.stringify(evalHistory),
        },
        include: {
          whitePlayer: true,
          blackPlayer: true,
        },
      });

      return NextResponse.json({ game: importedGame, review });
    }

    // 4. Resign active game
    if (action === "resign") {
      const { gameId, color } = body;
      const state = redisStore.liveGames.get(gameId);
      if (!state) {
        return NextResponse.json({ error: "Game not found" }, { status: 404 });
      }
      const result = color === "w" ? "0-1" : "1-0";
      const updated = await finalizeGameSession(state, result, "resignation");
      return NextResponse.json({ gameState: updated });
    }

    // 5. Offer / Accept Draw
    if (action === "draw") {
      const { gameId, color, subAction } = body;
      const state = redisStore.liveGames.get(gameId);
      if (!state) {
        return NextResponse.json({ error: "Game not found" }, { status: 404 });
      }
      if (subAction === "accept") {
        const updated = await finalizeGameSession(
          state,
          "1/2-1/2",
          "draw_agreement"
        );
        return NextResponse.json({ gameState: updated });
      }
      state.drawOfferedBy = color;
      return NextResponse.json({ gameState: state });
    }

    return NextResponse.json({ error: "Unknown action" }, { status: 400 });
  } catch (err: unknown) {
    console.error("Games API error:", err);
    return NextResponse.json(
      { error: "Failed to process game request" },
      { status: 500 }
    );
  }
}

export async function DELETE(req: NextRequest) {
  try {
    const gameId = req.nextUrl.searchParams.get("gameId");
    if (!gameId) {
      return NextResponse.json({ error: "Missing gameId" }, { status: 400 });
    }
    redisStore.liveGames.delete(gameId);
    await prisma.game.delete({ where: { id: gameId } });
    return NextResponse.json({ success: true });
  } catch (err: unknown) {
    console.error("Delete game error:", err);
    return NextResponse.json(
      { error: "Failed to delete game" },
      { status: 500 }
    );
  }
}
