"use client";

import React from "react";
import {
  CLASSIFICATION_META,
  FullGameReview,
  MoveClassification,
} from "@/lib/engine";
import { Sparkles, RotateCcw, Crosshair } from "lucide-react";

interface EvalGraphAndReviewProps {
  review: FullGameReview;
  currentPly: number;
  onSelectPly: (ply: number) => void;
  whiteName: string;
  blackName: string;
  onRetryMistake?: (plyIndex: number) => void;
}

const ORDERED_CLASSES: MoveClassification[] = [
  "Brilliant",
  "Great",
  "Best",
  "Excellent",
  "Good",
  "Book",
  "Inaccuracy",
  "Mistake",
  "Blunder",
  "Miss",
];

export const EvalGraphAndReview: React.FC<EvalGraphAndReviewProps> = ({
  review,
  currentPly,
  onSelectPly,
  whiteName,
  blackName,
  onRetryMistake,
}) => {
  const plies = review.plies;
  const width = 380;
  const height = 96;
  const midY = height / 2;

  // Build SVG path for centipawn evaluation curve
  const points = plies.map((p, idx) => {
    const x =
      plies.length <= 1
        ? width / 2
        : (idx / (plies.length - 1)) * (width - 16) + 8;
    const clampedCp = Math.max(-600, Math.min(600, p.evalAfter));
    const y = midY - (clampedCp / 600) * (midY - 8);
    return { x, y, ply: p.ply, cp: p.evalAfter, classification: p.classification };
  });

  const linePath =
    points.length > 0
      ? points
          .map((pt, i) => `${i === 0 ? "M" : "L"} ${pt.x.toFixed(1)} ${pt.y.toFixed(1)}`)
          .join(" ")
      : `M 0 ${midY} L ${width} ${midY}`;

  const areaPath =
    points.length > 0
      ? `${linePath} L ${points[points.length - 1].x.toFixed(1)} ${height} L ${points[0].x.toFixed(1)} ${height} Z`
      : "";

  const activePoint =
    currentPly > 0 && currentPly <= points.length
      ? points[currentPly - 1]
      : null;

  return (
    <div className="space-y-3">
      {/* CAPS Accuracy Comparison Banner */}
      <div className="grid grid-cols-2 gap-2.5 p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
        <div className="flex flex-col items-center p-2 rounded-lg bg-[#2B2825] border border-[#3A3733]">
          <span className="text-[11px] text-slate-400 truncate max-w-full">
            ⬜ {whiteName}
          </span>
          <span className="font-mono text-2xl font-extrabold text-emerald-400 mt-0.5">
            {review.whiteAccuracy.toFixed(1)}%
          </span>
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">
            CAPS Accuracy
          </span>
        </div>

        <div className="flex flex-col items-center p-2 rounded-lg bg-[#2B2825] border border-[#3A3733]">
          <span className="text-[11px] text-slate-400 truncate max-w-full">
            ⬛ {blackName}
          </span>
          <span className="font-mono text-2xl font-extrabold text-sky-400 mt-0.5">
            {review.blackAccuracy.toFixed(1)}%
          </span>
          <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">
            CAPS Accuracy
          </span>
        </div>
      </div>

      {/* Interactive Centipawn Evaluation Area Chart */}
      <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
            Evaluation Advantage Graph
          </span>
          <span className="text-[11px] font-mono text-slate-400">
            Click graph to scrub plies
          </span>
        </div>

        <svg
          viewBox={`0 0 ${width} ${height}`}
          className="w-full h-24 rounded-lg bg-[#141821] border border-[#3A3733] cursor-pointer overflow-visible"
          onClick={(e) => {
            if (plies.length === 0) return;
            const rect = e.currentTarget.getBoundingClientRect();
            const relX = e.clientX - rect.left;
            const ratio = Math.max(0, Math.min(1, relX / rect.width));
            const targetPly = Math.max(
              1,
              Math.min(plies.length, Math.round(ratio * plies.length))
            );
            onSelectPly(targetPly);
          }}
        >
          <defs>
            <linearGradient id="evalFillGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#81B64C" stopOpacity="0.45" />
              <stop offset="50%" stopColor="#81B64C" stopOpacity="0.1" />
              <stop offset="100%" stopColor="#EF4444" stopOpacity="0.35" />
            </linearGradient>
          </defs>

          {/* Zero Equilibrium Line */}
          <line
            x1="0"
            y1={midY}
            x2={width}
            y2={midY}
            stroke="#57534C"
            strokeDasharray="3 3"
            strokeWidth="1"
          />

          {/* Area under Eval Curve */}
          {areaPath && <path d={areaPath} fill="url(#evalFillGrad)" />}

          {/* Eval Line */}
          <path
            d={linePath}
            fill="none"
            stroke="#81B64C"
            strokeWidth="2"
            strokeLinecap="round"
          />

          {/* Key Moment Dots (Brilliant / Blunder) */}
          {points.map((pt) => {
            if (
              pt.classification !== "Brilliant" &&
              pt.classification !== "Blunder" &&
              pt.classification !== "Great"
            )
              return null;
            const meta = CLASSIFICATION_META[pt.classification];
            return (
              <circle
                key={pt.ply}
                cx={pt.x}
                cy={pt.y}
                r="3.2"
                fill={meta.color}
                stroke="#201D1B"
                strokeWidth="1"
              />
            );
          })}

          {/* Current Ply Cursor Line */}
          {activePoint && (
            <>
              <line
                x1={activePoint.x}
                y1={0}
                x2={activePoint.x}
                y2={height}
                stroke="#F59E0B"
                strokeWidth="1.5"
              />
              <circle
                cx={activePoint.x}
                cy={activePoint.y}
                r="4.2"
                fill="#F59E0B"
                stroke="#FFFFFF"
                strokeWidth="1.5"
              />
            </>
          )}
        </svg>
      </div>

      {/* 10-Category Move Classification Breakdown Table */}
      <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
        <div className="text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-2">
          Move Classification Breakdown
        </div>
        <div className="space-y-1">
          {ORDERED_CLASSES.map((cls) => {
            const meta = CLASSIFICATION_META[cls];
            const wCount = review.whiteCounts[cls] || 0;
            const bCount = review.blackCounts[cls] || 0;
            return (
              <div
                key={cls}
                className="grid grid-cols-[1fr_auto_1fr] items-center text-xs py-1 px-2 rounded hover:bg-[#2B2825] transition-colors"
              >
                <span className="font-mono font-bold text-slate-200 text-left">
                  {wCount}
                </span>
                <div className="flex items-center gap-1.5 justify-center min-w-[130px]">
                  <span
                    className="inline-flex items-center justify-center w-5 h-5 rounded-full text-[10px] font-mono font-extrabold"
                    style={{
                      backgroundColor: meta.bgColor,
                      color: meta.color,
                      border: `1px solid ${meta.borderColor}`,
                    }}
                  >
                    {meta.symbol}
                  </span>
                  <span
                    className="font-medium text-xs"
                    style={{ color: meta.color }}
                  >
                    {cls}
                  </span>
                </div>
                <span className="font-mono font-bold text-slate-200 text-right">
                  {bCount}
                </span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Key Tactical Moments & "Retry Mistake" Interactive Trainer */}
      {review.keyMoments.length > 0 && (
        <div className="p-3 rounded-xl bg-[#201D1B] border border-[#3A3733]">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Crosshair className="w-3.5 h-3.5 text-amber-400" />
              Critical Turning Points ({review.keyMoments.length})
            </span>
          </div>
          <div className="space-y-1.5 max-h-40 overflow-y-auto pr-1">
            {review.keyMoments.map((km) => {
              const meta = CLASSIFICATION_META[km.classification];
              const isError =
                km.classification === "Blunder" ||
                km.classification === "Mistake" ||
                km.classification === "Miss";
              return (
                <div
                  key={km.ply}
                  onClick={() => onSelectPly(km.ply)}
                  className={`flex items-center justify-between p-2 rounded-lg border cursor-pointer transition-all ${
                    currentPly === km.ply
                      ? "bg-[#35312C] border-emerald-500/50"
                      : "bg-[#2B2825] border-[#3A3733] hover:border-slate-600"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="px-1.5 py-0.5 rounded font-mono text-[10px] font-bold"
                      style={{
                        backgroundColor: meta.bgColor,
                        color: meta.color,
                        border: `1px solid ${meta.borderColor}`,
                      }}
                    >
                      {km.moveNumber}
                      {km.color === "w" ? "." : "..."} {km.san} {meta.symbol}
                    </span>
                    <span className="text-xs text-slate-300 truncate">
                      {isError
                        ? `Best was ${km.bestMoveSan}`
                        : `${km.classification} find!`}
                    </span>
                  </div>

                  {isError && onRetryMistake && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRetryMistake(km.ply);
                      }}
                      className="inline-flex items-center gap-1 px-2 py-1 rounded bg-amber-500/15 hover:bg-amber-500/25 text-amber-300 border border-amber-500/30 text-[11px] font-mono font-semibold shrink-0"
                    >
                      <RotateCcw className="w-3 h-3" /> Retry
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
